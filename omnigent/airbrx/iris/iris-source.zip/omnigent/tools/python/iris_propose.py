"""iris_propose.

One tool per file, because the runner gates local dispatch on
`local_tools[].name == tool_name` (runner/tool_dispatch.py) and the spec
parser names each entry after its file. A single module exporting four
tools produced one entry named `iris_tools`, so every call fell through
to the spec-callable route and returned "not in local dispatch table".
"""

from omnigent_client import tool
from omnigent_client.tools import ToolState
from iris.host import invoke


@tool
def iris_propose(
    finding_id: str,
    requested_change: str,
    tool_state: ToolState,
    rule_id: str | None = None,
) -> dict:
    """Draft one change for a session finding. requested_change is JSON with ttl_seconds and optional new_rule. Never applies."""
    return invoke(
        tool_state,
        "propose",
        finding_id=finding_id,
        requested_change=requested_change,
        rule_id=rule_id,
    )
