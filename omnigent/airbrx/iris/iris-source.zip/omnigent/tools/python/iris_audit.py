"""iris_audit.

One tool per file, because the runner gates local dispatch on
`local_tools[].name == tool_name` (runner/tool_dispatch.py) and the spec
parser names each entry after its file. A single module exporting four
tools produced one entry named `iris_tools`, so every call fell through
to the spec-callable route and returned "not in local dispatch table".
"""

from omnigent_client import tool
from omnigent_client.tools import ToolState
from iris.host import invoke


@tool
def iris_audit(
    tool_state: ToolState,
    sensitive_tables: list[str] | None = None,
    never_cache_tables: list[str] | None = None,
) -> dict:
    """Audit configuration intent using optional operator-supplied table classifications; no runtime safety claim."""
    return invoke(
        tool_state,
        "audit",
        sensitive_tables=sensitive_tables,
        never_cache_tables=never_cache_tables,
    )
