"""iris_overview.

One tool per file, because the runner gates local dispatch on
`local_tools[].name == tool_name` (runner/tool_dispatch.py) and the spec
parser names each entry after its file. A single module exporting four
tools produced one entry named `iris_tools`, so every call fell through
to the spec-callable route and returned "not in local dispatch table".
"""

from omnigent_client import tool
from omnigent_client.tools import ToolState
from iris.host import invoke


@tool
def iris_overview(
    tool_state: ToolState, start_date: str | None = None, end_date: str | None = None
) -> dict:
    """Read selected tenant overview; optional dates bound completed UTC days, end exclusive."""
    return invoke(tool_state, "overview", start_date=start_date, end_date=end_date)
