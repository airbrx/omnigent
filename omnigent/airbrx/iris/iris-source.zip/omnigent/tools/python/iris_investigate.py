"""iris_investigate.

One tool per file, because the runner gates local dispatch on
`local_tools[].name == tool_name` (runner/tool_dispatch.py) and the spec
parser names each entry after its file. A single module exporting four
tools produced one entry named `iris_tools`, so every call fell through
to the spec-callable route and returned "not in local dispatch table".
"""

from omnigent_client import tool
from omnigent_client.tools import ToolState
from iris.host import invoke


@tool
def iris_investigate(
    question: str,
    tool_state: ToolState,
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict:
    """Compare adjacent periods. question must be outcomes, repeated_misses, per_rule, per_user or gateway_failures; never SQL. gateway_failures reviews recorded SQL refusals and errors over one completed UTC hour when the store's schema supports it; authentication and malformed-request coverage is incomplete, and an empty result is not evidence that no failures occurred."""
    return invoke(
        tool_state,
        "investigate",
        question=question,
        start_date=start_date,
        end_date=end_date,
    )
