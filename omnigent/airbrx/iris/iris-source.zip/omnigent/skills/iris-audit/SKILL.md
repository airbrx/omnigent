---
name: iris-audit
description: Audit cache configuration intent without claiming runtime or data-sensitivity verification.
---
Call iris_audit with operator-supplied sensitive_tables and never_cache_tables when available.
Without classification, report unknown sensitivity. Do not infer permission to remove user isolation.
Explain every finding with its evidence IDs and confidence. Static matching concerns are candidates, not runtime proof.
For a bounded proposal use airbrx-rule-author, the sole bundled schema reference.
