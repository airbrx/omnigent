---
name: airbrx-rule-author
description: Draft and server-validate one bounded cache proposal without applying changes.
---
Product adaptation of the preserved research skills/airbrx-rule-author/SKILL.md.
The discovered upstream inventory has 26 tools; Iris exposes only its four purpose-built functions.
Use iris_propose with a current session finding. requested_change is JSON with positive integer ttl_seconds
and optional new_rule. Supply rule_id. Existing edits change cache TTL only.

The full envelope has tenantId, version, optional defaults, and ordered rules. Preserve its actual version,
all unknown fields, defaults, order, and unrelated rules. Version is a cache-bust value, not a literal 2.0 requirement.
A narrow addition needs a unique id, name, priority, enabled:true, mode:all, conditions.statementType.equals:SELECT,
conditions.tables.includes (one nonempty table) or includesAny (nonempty table list), and actions.cache.ttlSeconds.
Preserve existing cacheKeyElements; do not reduce isolation. Cache key elements may include standardizedSql,
statement, userId, userRole, tenantId, warehouse, catalog, schema, tables, columns.
No deny/deleteCache/invalidateRules changes, OR matching, broad SELECT additions, or unknown proposal shapes.
Domain checks are conservative; authoritative validate_rules lint and preview_rule_change run inside the adapter.
Failed lint, unavailable validation, and baseline drift cannot be described as validated.
Always state: proposal not applied; preview compares configuration; historical impact has not been simulated.
In the operator-facing proposal answer, explain full-envelope preservation explicitly: the candidate is the complete freshly fetched envelope, not just the displayed diff; the supported edit preserves version, defaults, unknown fields, order and unrelated rules. Show the bounded change and validation status, and keep this separate from any unproven benefit or attribution.
