// The host's system theme is the default; an explicit choice belongs to this UI.
(() => {
  const key = "iris.theme";
  const allowed = ["system", "light", "dark"];
  const system = window.matchMedia("(prefers-color-scheme: dark)");
  let preference = "system";
  try {
    const saved = localStorage.getItem(key);
    if (allowed.includes(saved)) preference = saved;
  } catch {
    /* Embedded hosts may disable storage; the session still works. */
  }
  function apply() {
    document.documentElement.dataset.theme =
      preference === "system"
        ? system.matches
          ? "dark"
          : "light"
        : preference;
  }
  apply();
  system.addEventListener("change", apply);
  document.addEventListener("DOMContentLoaded", () => {
    const picker = document.querySelector("#theme");
    picker.value = preference;
    picker.addEventListener("change", () => {
      preference = allowed.includes(picker.value) ? picker.value : "system";
      try {
        localStorage.setItem(key, preference);
      } catch {
        /* Session-only. */
      }
      apply();
    });
  });
})();
