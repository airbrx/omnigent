"use strict";
const $ = (s) => document.querySelector(s);
const esc = (v) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const finite = (v) => typeof v === "number" && Number.isFinite(v);
const num = (v) =>
  finite(v)
    ? v.toLocaleString(undefined, { maximumFractionDigits: 1 })
    : "Not measured";
const percent = (v) =>
  finite(v) ? `${(v * 100).toFixed(1)}%` : "Not measured";
// "1 findings are ready for review" was a number formatted without regard to
// what it says. Counts that reach a sentence go through here.
const countLabel = (n, noun) => `${num(n)} ${noun}${n === 1 ? "" : "s"}`;
const title = (v) =>
  String(v || "Review evidence")
    .replace(/_/g, " ")
    .replace(/^./, (s) => s.toUpperCase());
let state = null,
  baseline = null,
  followup = null,
  filePurpose = "snapshot",
  reviews = new Map();
const names = {
  overview: "Overview",
  improvements: "Improvements",
  rules: "Rules",
  results: "Results",
  skills: "Iris’s skills",
};
const overview = () => state?.overview || {};
const metrics = () => overview().metrics || {};
const tenant = (o) => o.tenant_id || o.tenantId || "";
// Whether a capture's numbers are invented. Mode, and only mode — this says
// nothing about where the report came from, which is provenance and is
// carried separately by the badge label.
const isSynthetic = (o = overview()) =>
  String(o.mode || "").includes("synthetic");
function normalize(raw) {
  const d = raw?.overview ? raw : { overview: raw };
  if (!d.overview || !d.overview.metrics || !tenant(d.overview))
    throw Error(
      "Choose an Iris overview report or an iris-state.json snapshot with metrics and a tenant ID.",
    );
  const m = d.overview.metrics;
  if (
    !Array.isArray(d.overview.evidence) ||
    !Array.isArray(d.overview.findings)
  )
    throw Error("Report evidence and findings must be arrays.");
  for (const k of [
    "requests",
    "cache_hits",
    "cache_misses",
    "covered_days",
    "requested_days",
  ])
    if (m[k] != null && (!finite(m[k]) || m[k] < 0))
      throw Error(`Invalid ${k} in report.`);
  if (
    m.hit_rate != null &&
    (!finite(m.hit_rate) || m.hit_rate < 0 || m.hit_rate > 1)
  )
    throw Error("Invalid hit rate.");
  // The same conditions comparisonProblem() refuses by name, applied at ingest
  // instead of only when two captures meet. A capture whose own hits, requests,
  // denominator and coverage disagree rendered as a confident headline —
  // 80.0% captioned "120 hits / 700 requests" beside "Requests observed 1,000"
  // — and the product already knew that set was incoherent.
  //
  // Note what is deliberately *not* lifted: comparisonProblem() also requires
  // requests > 0, but that is a precondition for dividing, not an ingest
  // invariant. A window with no traffic is a measured zero, and this codebase
  // distinguishes a measured zero from an absent measurement on purpose —
  // refusing it would turn "nobody queried this week" into an error.
  if (finite(m.cache_hits) && finite(m.requests) && m.cache_hits > m.requests)
    throw Error("Report metrics disagree: more hits than requests.");
  if (
    finite(m.hit_rate_denominator) &&
    finite(m.requests) &&
    m.hit_rate_denominator !== m.requests
  )
    throw Error(
      "Report metrics disagree: the hit-rate denominator is not the request count.",
    );
  if (
    m.period_complete === true &&
    finite(m.covered_days) &&
    finite(m.requested_days) &&
    m.covered_days !== m.requested_days
  )
    throw Error(
      "Report metrics disagree: the period is marked complete but not every requested day is covered.",
    );
  if (
    finite(m.hit_rate) &&
    finite(m.cache_hits) &&
    finite(m.hit_rate_denominator) &&
    m.hit_rate_denominator > 0 &&
    Math.abs(m.hit_rate - m.cache_hits / m.hit_rate_denominator) > 0.0005
  )
    throw Error(
      "Report metrics disagree: the stated hit rate is not its own hits over its own denominator.",
    );
  if (d.audit && tenant(d.audit) && tenant(d.audit) !== tenant(d.overview))
    throw Error("Audit and overview must belong to the same tenant.");
  if (d.audit && !Array.isArray(d.audit.findings))
    throw Error("Audit findings must be an array.");
  if (d.rules && !Array.isArray(d.rules))
    throw Error("Rules must be an array.");
  for (const report of [d.overview, d.audit].filter(Boolean)) {
    for (const f of report.findings)
      if (
        !f ||
        typeof f !== "object" ||
        typeof f.id !== "string" ||
        (f.evidence_ids && !Array.isArray(f.evidence_ids))
      )
        throw Error("Malformed finding in report.");
    for (const e of report.evidence || [])
      if (!e || typeof e !== "object")
        throw Error("Malformed evidence in report.");
    if (
      report.findings.some(
        (f) => f.tenant_id && f.tenant_id !== tenant(d.overview),
      )
    )
      throw Error("Finding tenant does not match the overview.");
  }
  if ((d.rules || []).some((r) => !r || typeof r !== "object"))
    throw Error("Malformed rule summary.");
  if (
    m.latency?.response_time_ms != null &&
    (!finite(m.latency.response_time_ms) || m.latency.response_time_ms < 0)
  )
    throw Error("Invalid response time.");
  return d;
}
function findings() {
  const all = [
    ...(overview().findings || []),
    ...(state?.audit?.findings || []),
  ];
  return all.filter((f, i) => all.findIndex((x) => x.id === f.id) === i);
}
function toast(s) {
  $("#toast").textContent = s;
  $("#toast").style.display = "block";
  setTimeout(() => ($("#toast").style.display = "none"), 5500);
}

/** A host call that failed, carrying a reason chosen here and its status. */
function hostError(reason, status) {
  const error = Error(status ? `${reason} (HTTP ${status})` : reason);
  error.hostReason = error.message;
  return error;
}

/**
 * Why a call failed, in words that are safe to show a user.
 *
 * Deliberately never a reason the host chose. `ui_bridge.py` and the hosted
 * routes both refuse to reflect execution diagnostics because they can carry
 * credential material, and this file must not become the hole in that. The
 * only strings that reach a surface are the ones written above, the browser's
 * own transport failures, and the exception's class name.
 *
 * The alternative this replaces was `catch {}` with no binding at all, which
 * threw the reason away and then answered the question anyway.
 */
function whyFailed(error) {
  if (error && error.hostReason) return error.hostReason;
  // Compared by name, never `instanceof`. This page runs inside an iframe on
  // the hosted mount and inside a `vm` context under its own tests, and a
  // TypeError raised in another realm is not an instance of this realm's
  // TypeError — so `instanceof` silently fell through to the generic branch
  // and reported a transport failure we had recognised as an unknown one.
  if (error && error.name === "TimeoutError") return "the host did not respond in time";
  if (error && error.name === "TypeError") return "the host could not be reached";
  return `the request failed (${(error && error.name) || "unknown error"})`;
}
function period(o = overview()) {
  const m = o.metrics || {};
  return `${m.start_date || "Unknown start"} → ${m.end_date || "Unknown end"} · UTC, end exclusive`;
}
function navigate() {
  const page = location.hash.slice(1) || "overview";
  const key = names[page] ? page : "overview";
  $("#page-label").textContent = names[key];
  document.querySelectorAll("nav a").forEach((a) => {
    const active = a.hash === `#${key}`;
    a.classList.toggle("active", active);
    if (active) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
  $("#count").textContent = findings().length;
  $("#main").innerHTML = state
    ? views[key]()
    : `<div class="empty"><h1>Bring Iris your first report.</h1><p>Import an Iris overview JSON to explore cache performance and review findings.</p><button data-action="import" class="primary">Import report</button></div>`;
}
const heading = (eyebrow, name, description, action = "") =>
  `<div class="page-title"><div><div class="eyebrow">${eyebrow}</div><h1>${name}</h1><p>${description}</p></div>${action}</div>`;
function metricCards() {
  const m = metrics();
  return `<div class="metrics"><div class="metric"><label>Cache hit rate</label><div class="value">${percent(m.hit_rate)}</div><small>${num(m.cache_hits)} hits / ${num(m.hit_rate_denominator)} requests</small></div><div class="metric"><label>Requests observed</label><div class="value">${num(m.requests)}</div><small>${num(m.cache_misses)} cache misses</small></div><div class="metric"><label>Response-time proxy</label><div class="value">${finite(m.latency?.response_time_ms) ? (m.latency.response_time_ms / 1000).toFixed(2) + "s" : "—"}</div><small>${finite(m.latency?.response_time_ms) ? "Request-weighted · covered days" : "Not measured in this report"}</small></div></div>`;
}
function findingRows(limit = 100) {
  return (
    findings()
      .slice(0, limit)
      .map(
        (f, i) =>
          `<div class="finding"><div class="symbol">↗</div><div class="finding-content"><h3>${esc(title(f.kind))}</h3><small>${esc(f.rule_id || "Tenant-wide")} · ${esc(f.confidence || "Unknown")} confidence</small><p>${esc(f.next_step || f.explanation)}</p><span class="badge ${f.severity === "warning" ? "warning" : ""}">${esc(reviews.get(f.id)?.status || "Needs investigation")}</span></div><button data-review="${i}">Review →</button></div>`,
      )
      .join("") ||
    "<p>No findings in this capture. Import a fresh audit to assess rule risks.</p>"
  );
}
function coverage() {
  const m = metrics();
  const days = (overview().evidence || [])
    .filter((e) => e.source_tool === "get_summary")
    .slice(0, 31);
  return `<div class="card"><div class="section-head" style="margin:0"><h2>Evidence coverage</h2><span class="badge ${m.period_complete ? "" : "warning"}">${num(m.covered_days)} / ${num(m.requested_days)} days</span></div><div class="coverage">${days.map((e) => `<div class="day ${e.status === "complete" ? "" : "missing"}" title="${esc(e.start_date)}: ${esc(e.status)}"><i></i>${esc(String(e.start_date || "").slice(5))}</div>`).join("")}</div><div class="legend">Orange: available daily summary · Hatched: unavailable. This is coverage, not traffic volume.</div>${m.period_complete ? "" : `<p style="font-size:11px;margin-bottom:0">Partial capture. Metrics describe covered days only.</p>`}</div>`;
}
function monitoringHtml() {
  // Status must come from the authenticated host, never an imported report.
  const m =
    !primaryImported &&
    !state?.stale &&
    !isSynthetic() &&
    state?.monitoring;
  if (!m || m.tenant_id !== tenant(overview()) || m.configured !== true)
    return `<div class="note"><strong>Monitoring unavailable</strong><br>On-demand analyst. No verified scheduled gateway watch is configured. Captured panels do not provide continuous security coverage.</div>`;
  const status = [
    "disabled",
    "delayed",
    "failed",
    "partial",
    "complete",
  ].includes(m.status)
    ? m.status
    : "unknown";
  return `<div class="card"><h2>Scheduled watch · ${esc(status)}</h2><p>Host-reported hourly observation; not real-time protection.</p><p>Last attempt: ${esc(m.last_attempt || "Unknown")}<br>Last successful covered window: ${esc(m.last_successful_window || "Unknown")}<br>Next run: ${esc(m.next_run || "Unknown")}</p><p>Coverage: ${esc(m.coverage || "Unknown — no security verdict")}</p></div>`;
}
const views = {
  overview() {
    const fs = findings();
    return (
      heading(
        "OBSERVE. UNDERSTAND. IMPROVE.",
        "A clearer view of your cache.",
        esc(period()),
        '<button data-action="baseline">Save as baseline</button>',
      ) +
      `<section class="hero"><div class="eyebrow">YOUR NEXT BEST STEP</div><h2>${fs.length ? "Start with the rules that need a closer look." : "Build a reliable baseline before changing rules."}</h2><p>${fs.length ? `${countLabel(fs.length, "finding")} ready for review. Investigate the evidence, document the intended change, then measure a later capture.` : "Use this capture to understand performance. Bring in an audit to identify opportunities and a later report to observe results."}</p><div class="hero-bottom"><button class="primary" data-go="improvements">Review improvements →</button><span class="muted" style="font-size:11px">You stay in control.</span></div><div class="orbit"></div></section><div class="workflow"><div class="step current"><span>01</span>Understand</div><div class="step"><span>02</span>Investigate</div><div class="step"><span>03</span>Review proposal</div><div class="step"><span>04</span>Measure results</div></div>` +
      metricCards() +
      monitoringHtml() +
      coverage() +
      `<div class="section-head"><h2>Where to focus next</h2><button class="text-button" data-go="improvements">View all →</button></div><div class="card">${findingRows(2)}</div><p class="tenant">Tenant: ${esc(tenant(overview()))} · Captured evidence; not a live monitor.</p>`
    );
  },
  improvements() {
    return (
      heading(
        "CONTINUOUS IMPROVEMENT",
        "Make every change reviewable.",
        "Investigate → document intent → validate with Iris → measure later.",
      ) +
      `<div class="note">These are investigation findings, not approved configuration changes. Reviews and notes stay in this browser session; export a handoff to keep them.</div><div class="card">${findingRows()}</div><div class="section-head"><h2>Proposal workflow</h2></div><div class="card"><h3>Turn evidence into a bounded change.</h3><p>Document the rule, freshness requirements, and expected outcome. Iris’s rule-author skill can then retrieve the full baseline, lint a candidate, and preview it. This snapshot workspace does not run validation or apply rules.</p><button data-ask="How do I prepare a rule change proposal?">Explore the rule-author skill ↗</button></div>`
    );
  },
  rules() {
    const rows = state.rules || [];
    return (
      heading(
        "CONFIGURATION CONTEXT",
        "Know what your rules are doing.",
        "Annual effectiveness is a separate window from the daily overview.",
      ) +
      `<div class="note">Effectiveness summaries are not a complete ruleset. TTL, table scope, and invalidation behavior require the source configuration. Do not infer them from these counts.</div><div class="card table-wrap"><table><thead><tr><th>RULE</th><th>MATCHED QUERIES</th><th>HITS</th><th>MISSES</th></tr></thead><tbody>${rows.map((r) => `<tr><td><strong>${esc(r.ruleName || r.ruleId)}</strong><small>${esc(r.ruleId)}</small></td><td class="mono">${num(r.queriesMatched)}</td><td class="mono">${num(r.cacheHits)}</td><td class="mono">${num(r.cacheMisses)}</td></tr>`).join("") || '<tr><td colspan="4">No rule-effectiveness summary in this capture.</td></tr>'}</tbody></table></div><div class="section-head"><h2>Configuration findings</h2></div><div class="card">${findingRows()}</div>`
    );
  },
  results() {
    return (
      heading(
        "CLOSE THE LOOP",
        "Did the next change help?",
        "Compare two captures from the same tenant. Observed differences are not proof of causation.",
      ) +
      `<div class="comparison"><div class="card"><div class="eyebrow">01 / BASELINE</div><h3 style="margin-top:12px">${baseline ? "Baseline saved" : "Choose your starting point"}</h3><p>${baseline ? esc(period(baseline.overview)) : "Save the current capture before making a change."}</p><button data-action="baseline">${baseline ? "Replace with current capture" : "Use current capture"}</button></div><div class="card"><div class="eyebrow">02 / FOLLOW-UP</div><h3 style="margin-top:12px">${followup ? "Follow-up imported" : "Bring the next observation"}</h3><p>${followup ? esc(period(followup.overview)) : "Import a later Iris overview report after observation."}</p><button data-action="followup">Import follow-up ↑</button></div></div>${comparisonHtml()}<div class="note">No warehouse or dollar savings are inferred from response time. Changes in workload, rule versions, and coverage can affect the result.</div>`
    );
  },
  skills() {
    return (
      heading(
        "MEET YOUR SPECIALIST",
        "Three skills. One improvement loop.",
        "Iris’s packaged skills help turn evidence into a reviewable decision.",
      ) +
      `<div class="skill-grid">${[
        [
          "◉",
          "Understand performance",
          "Overview & investigate",
          "Explore request counts, coverage, repeated misses, and the evidence behind a finding.",
          "Explain this capture’s cache performance.",
          "iris_overview · iris_investigate",
        ],
        [
          "▤",
          "Audit configuration",
          "Rule audit",
          "Inspect rule scope, sensitive tables, bypass behavior, and invalidation assumptions.",
          "Summarize the audit findings and their risks.",
          "iris_audit",
        ],
        [
          "✧",
          "Prepare a proposal",
          "Rule author",
          "Draft one bounded change against a complete baseline, with lint and preview evidence.",
          "How do I prepare a rule change proposal?",
          "iris_propose",
        ],
      ]
        .map(
          ([icon, name, sub, desc, ask, tools]) =>
            `<div class="card skill-card"><span class="orange">${icon}</span><div><div class="eyebrow">${sub}</div><h2 style="margin:8px 0">${name}</h2><p>${desc}</p><small class="mono">${tools}</small><button data-ask="${ask}">Explore this skill ↗</button></div></div>`,
        )
        .join(
          "",
        )}</div><div class="note">The skills run in the Iris agent host. Here, the snapshot explorer explains the captured evidence and prepares a handoff. A configured host can connect the conversation and refresh these panels. Captured reports remain available when the host is unavailable.</div>`
    );
  },
};
function comparisonProblem(a, b) {
  if (tenant(a) !== tenant(b))
    return "The captures belong to different tenants.";
  if ((a.mode || "") !== (b.mode || ""))
    return "Capture modes differ; synthetic and live evidence cannot be compared.";
  const x = a.metrics,
    y = b.metrics;
  if (x.period_complete !== true || y.period_complete !== true)
    return "Both captures need complete daily coverage before a comparison is shown.";
  const duration = (o) =>
    Date.parse(o.metrics.end_date) - Date.parse(o.metrics.start_date);
  if (
    !finite(duration(a)) ||
    duration(a) <= 0 ||
    duration(a) !== duration(b) ||
    x.requested_days !== y.requested_days
  )
    return "Choose observation windows of equal duration.";
  if (Date.parse(y.start_date) < Date.parse(x.end_date))
    return "The follow-up must start after the baseline ends, without overlap.";
  for (const m of [x, y])
    if (
      m.covered_days !== m.requested_days ||
      m.covered_days !== duration(a) / 86400000 ||
      !finite(m.cache_hits) ||
      !finite(m.requests) ||
      m.requests <= 0 ||
      m.cache_hits > m.requests ||
      m.hit_rate_denominator !== m.requests
    )
      return "Both captures need consistent measured hits and positive request denominators.";
  return "";
}
function comparisonHtml() {
  if (!baseline || !followup)
    return `<div class="card empty" style="margin-top:20px"><div class="orange">◷</div><h2>Your results start with a baseline.</h2><p>Save a capture, review and validate a change outside this workspace, then import a later report. Iris will show what actually moved.</p></div>`;
  const a = baseline.overview,
    b = followup.overview,
    problem = comparisonProblem(a, b);
  if (problem)
    return `<div class="card empty" style="margin-top:20px"><h2>Comparison needs more evidence.</h2><p>${esc(problem)}</p></div>`;
  const rate = (o) => o.metrics.cache_hits / o.metrics.requests;
  const delta = (rate(b) - rate(a)) * 100;
  return `<div class="section-head"><h2>Observed change</h2><span class="badge">${esc(a.mode || "Imported reports")}</span></div><div class="comparison"><div class="card"><small>Cache hit rate</small><div class="value">${percent(rate(a))} → ${percent(rate(b))}</div><span class="orange">${delta > 0 ? "+" : ""}${delta.toFixed(1)} percentage points</span></div><div class="card"><small>Request volume</small><div class="value">${num(a.metrics.requests)} → ${num(b.metrics.requests)}</div><small>Review workload differences before attribution.</small></div></div>`;
}
function review(index) {
  const f = findings()[index];
  if (!f) return;
  const prior = reviews.get(f.id) || {};
  $("#review-content").innerHTML =
    `<div class="eyebrow">INVESTIGATION REVIEW</div><h2>${esc(title(f.kind))}</h2><span class="badge">${esc(f.rule_id || "Tenant-wide")}</span><p>${esc(f.explanation)}</p><h3>Next evidence to collect</h3><p>${esc(f.next_step || "Inspect source evidence before drafting a change.")}</p><details><summary>Source references (${(f.evidence_ids || []).length})</summary><pre>${esc((f.evidence_ids || []).join("\n") || "No evidence references supplied.")}</pre></details><label class="field-label" for="review-note">Review notes and intended outcome</label><textarea id="review-note" rows="4" maxlength="4000" placeholder="What should change? What freshness or table-scope constraints must hold?">${esc(prior.note || "")}</textarea><div class="actions"><button class="primary" id="save-review">Save investigation notes</button><button id="export-review">Export handoff ↓</button></div><small>This records investigation intent only. No ruleset is generated, validated, or applied.</small>`;
  $("#save-review").onclick = () => {
    reviews.set(f.id, {
      note: $("#review-note").value,
      status: "Investigation noted",
    });
    navigate();
    toast("Notes saved for this session.");
  };
  $("#export-review").onclick = () => {
    const data = {
      kind: "iris-investigation-handoff",
      status: "unvalidated-intent",
      tenant_id: tenant(overview()),
      finding: f,
      notes: $("#review-note").value,
      baseline_period: metrics(),
      next_step:
        "Use iris_investigate / iris_propose in the Iris host; retrieve the full rules baseline and validate before any external approval.",
    };
    download(data, "iris-investigation-handoff.json");
  };
  $("#review").showModal();
}
function download(data, name) {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  // Inside the hosted iframe a blocked download and a saved one look
  // identical. Say which file was offered. The browser may still refuse it,
  // but the page no longer implies a success it cannot observe.
  toast(`Download offered: ${name}. Check your browser's downloads.`);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function answer(q) {
  const m = metrics();
  if (/\b(apply|deploy|delete|execute)\b/i.test(q))
    return "This workspace can review findings and export investigation notes. It has no rule-apply connection. A proposed change still needs the complete baseline, validation, preview evidence, and external approval.";
  if (/dollar|\$|cost|saving/i.test(q))
    return "This capture does not establish dollar savings. Response time is an end-to-end proxy, not warehouse time saved. A supported cost calculation needs measured warehouse work and a verified cost basis.";
  // Past-tense outcome questions are about results, not authoring. This is
  // tested before the proposal branch because that branch's bare `change`
  // alternative otherwise swallows "what changed?" — the question step 04 of
  // the workflow explicitly invites, and the one a person asks first of a
  // cache product.
  if (
    /\b(changed|improve[sd]?|improving|improvement|worse|better|moved|regress\w*|compar\w*|results?|baseline|impact)\b/i.test(
      q,
    ) &&
    !/\b(propose|proposal|prepare|author|draft|ttl)\b/i.test(q)
  ) {
    if (!baseline || !followup)
      return "No comparison is available yet. Results need two captures: save this one as a baseline, validate a change outside this workspace, then import a later report. Until both exist, this page cannot say what moved.";
    const a = baseline.overview,
      b = followup.overview,
      problem = comparisonProblem(a, b);
    if (problem) return `A comparison is not supported here: ${problem}`;
    const rate = (o) => o.metrics.cache_hits / o.metrics.requests;
    const delta = (rate(b) - rate(a)) * 100;
    return `Cache hit rate moved ${percent(rate(a))} → ${percent(rate(b))}, a change of ${delta > 0 ? "+" : ""}${delta.toFixed(1)} percentage points. Request volume moved ${num(a.metrics.requests)} → ${num(b.metrics.requests)}; review workload differences before attributing the change to a rule.`;
  }
  if (/proposal|propose|ttl|prepare|author|draft|new rule|make a change/i.test(q))
    return "The rule-author skill prepares one bounded change against the complete current ruleset. Start by reviewing a finding and exporting your notes. Capture the intended outcome, table sensitivity, freshness requirements, and rollback expectations. Run iris_propose in the host for lint and preview; this explorer cannot validate a proposal.";
  if (/audit|risk|rule|invalidation/i.test(q))
    return findings().length
      ? findings()
          .map(
            (f) =>
              `${title(f.kind)} (${f.confidence || "unknown"} confidence): ${f.explanation}\nNext: ${f.next_step || "Inspect evidence."}`,
          )
          .join("\n\n")
      : "This capture contains no audit findings. Run iris_audit in the host, then import the resulting combined snapshot.";
  if (/performance|overview|hit|miss|coverage|request|latency/i.test(q))
    return `This capture reports ${percent(m.hit_rate)} cache hits across ${num(m.hit_rate_denominator)} requests: ${num(m.cache_hits)} hits and ${num(m.cache_misses)} misses.\n\nCoverage: ${num(m.covered_days)} of ${num(m.requested_days)} requested days. ${m.period_complete ? "The period is complete." : "The period is incomplete; these totals cover available days only."}\n\nResponse-time proxy: ${num(m.latency?.response_time_ms)}${finite(m.latency?.response_time_ms) ? " ms" : ""}. Warehouse savings are not established by that figure.`;
  return "I’m a snapshot explorer in this preview, not a connected language model. I can explain performance, summarize audit findings, or describe proposal preparation. Use one of the skill buttons, or import another report to explore its evidence.";
}
// A configured host may expose these relative endpoints at its mount path.
const history = [];
let liveAgent = null;
let chatBusy = false;
let refreshBusy = true;
let primaryImported = false;
// The tenant this session is bound to, established by a host capture. Null
// until a host answers, so a purely offline session can still explore any
// report it is handed.
let hostBoundTenant = null;
// This IS an agent turn, and 45s was wrong.
//
// It looks like a snapshot fetch from here, and the first version of this
// change cut the deadline on exactly that reasoning. On the hosted mount the
// adapter rewrites `api/state?fresh=1` into `POST api/refresh`, which runs a
// real turn calling iris_overview AND iris_audit against the warehouse, with
// a server-side deadline of 300s. Driven in production it was still working
// at 45s when the timer aborted it, and the page reported "Refresh cancelled"
// — blaming the operator for a deadline this file chose.
//
// So: match the server's deadline, the same way the chat turn does. What Q26
// actually asked for was a way OUT of the wait, not a shorter wait, and
// cancelRefresh() below is that.
const REFRESH_TIMEOUT_MS = 330000;
let refreshAbort = null;
// Which of the two abort paths fired. A timeout and a cancellation are not
// the same event and must not read the same to whoever is waiting.
let refreshTimedOut = false;

function resetConversation() {
  history.length = 0;
  setAgentStatus(false);
  $("#chat").replaceChildren();
}

function bubble(role, text, tools) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.textContent = text;
  if (tools && tools.length) {
    const note = document.createElement("small");
    note.className = "tool-note";
    note.textContent = `tools used: ${tools.join(", ")}`;
    div.append(note);
  }
  $("#chat").append(div);
  $("#chat").scrollTop = $("#chat").scrollHeight;
  return div;
}

function setAgentStatus(live) {
  // Only a completed turn earns the live label. A page that claims live and
  // then serves snapshot answers is worse than one that admits it is offline.
  if (liveAgent === live) return;
  liveAgent = live;
  const dot = $("#agent-dot"),
    mode = $("#agent-mode"),
    note = $("#agent-note");
  if (!dot || !mode || !note) return;
  dot.className = live ? "dot ok" : "dot neutral";
  mode.textContent = live ? "Live agent" : "Snapshot explorer";
  note.textContent = live
    ? "Connected host · evidence depends on each answer"
    : "Live agent not connected";
}

async function ask(q) {
  if (chatBusy || refreshBusy) {
    toast("Wait for the current answer before sending another question.");
    return;
  }
  if (!state) {
    toast("Import a report first.");
    return;
  }
  bubble("user", q);
  // Imported and demo captures must never send their conversation to a tenant-bound host.
  if (primaryImported || isSynthetic()) {
    setAgentStatus(false);
    // A legitimate offline answer — the operator imported this capture and is
    // asking about it — but it is computed here, not by Iris, and the label
    // has to carry that on every line rather than in a chip above the fold.
    bubble(
      "assistant",
      "Computed on this page from the loaded capture, not an answer from Iris — " +
        answer(q),
    );
    return;
  }
  chatBusy = true;
  const submit = $("#composer button");
  submit.disabled = true;
  const pending = bubble(
    "assistant",
    "Connecting to the configured Iris host…",
  );
  try {
    const check = await fetch("api/state", {
      cache: "no-store",
      signal: AbortSignal.timeout(30000),
    });
    if (!check.ok) throw hostError("the host has no evidence for this session", check.status);
    const raw = await check.json();
    const serverState = normalize(raw);
    if (
      raw.stale ||
      tenant(serverState.overview) !== tenant(overview()) ||
      serverState.overview.mode !== overview().mode
    )
      throw hostError("the host is holding a different capture than this page", 0);
    const res = await fetch("api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        history: [...history, { role: "user", content: q }],
        deadline: 300,
      }),
      signal: AbortSignal.timeout(330000),
    });
    if (!res.ok) throw hostError("the host refused the turn", res.status);
    const { text, tools, failed } = await res.json();
    if (
      failed ||
      typeof text !== "string" ||
      !text.trim() ||
      (tools != null &&
        (!Array.isArray(tools) || tools.some((t) => typeof t !== "string")))
    )
      throw hostError("the host returned an incomplete turn", 0);
    pending.remove();
    bubble("assistant", text, tools);
    history.push(
      { role: "user", content: q },
      { role: "assistant", content: text },
    );
    // Bound client history to the bridge's 24-message contract.
    if (history.length > 22) history.splice(0, history.length - 22);
    setAgentStatus(true);
  } catch (error) {
    // Bound, and answered honestly. This used to be `catch {}` followed by
    // "Snapshot answer — " and a sentence computed from the captured report —
    // so a question about live evidence got stale data in the same visual
    // channel as a real answer, and why the host failed was unrecoverable
    // because the exception was never bound. A question that could not be
    // asked does not get an answer.
    pending.remove();
    setAgentStatus(false);
    bubble(
      "assistant",
      `No answer from Iris: ${whyFailed(error)}. Nothing has been computed in ` +
        "her place. The panels still show what they showed before, and this " +
        "question was not answered from them.",
    );
  } finally {
    chatBusy = false;
    submit.disabled = false;
  }
}
async function hostSnapshot(fresh = false, signal) {
  const response = await fetch(fresh ? "api/state?fresh=1" : "api/state", {
    cache: "no-store",
    signal: signal || AbortSignal.timeout(REFRESH_TIMEOUT_MS),
  });
  if (!response.ok) throw hostError("the host has no evidence for this session", response.status);
  const raw = await response.json();
  if (raw.stale) throw hostError("the host's capture is stale", 0);
  return normalize(raw);
}

/**
 * Abort a refresh in flight. Returns whether there was one to abort.
 *
 * The host bar's "Cancel current turn" cancelled the agent turn and left this
 * fetch running, so the page stayed locked behind a button that claimed to
 * have stopped it.
 */
function cancelRefresh() {
  if (!refreshAbort) return false;
  refreshTimedOut = false;
  refreshAbort.abort();
  refreshAbort = null;
  return true;
}
async function refreshSnapshot() {
  if (chatBusy || refreshBusy) {
    toast("Wait for the current request before refreshing reports.");
    return;
  }
  refreshBusy = true;
  const button = $("#refresh");
  button.disabled = true;
  button.textContent = "Refreshing…";
  try {
    refreshAbort = new AbortController();
    refreshTimedOut = false;
    const timer = setTimeout(() => {
      refreshTimedOut = true;
      refreshAbort?.abort();
    }, REFRESH_TIMEOUT_MS);
    let next;
    try {
      next = await hostSnapshot(true, refreshAbort.signal);
    } finally {
      clearTimeout(timer);
    }
    // A refresh of an established host capture cannot silently switch tenants.
    if (
      state &&
      !primaryImported &&
      !isSynthetic() &&
      (tenant(next.overview) !== tenant(overview()) ||
        next.overview.mode !== overview().mode)
    )
      throw Error("Host tenant or mode changed");
    if (
      primaryImported ||
      tenant(next.overview) !== tenant(overview()) ||
      next.overview.mode !== overview().mode
    ) {
      baseline = null;
      followup = null;
    }
    state = next;
    hostBoundTenant = tenant(next.overview);
    primaryImported = false;
    reviews.clear();
    resetConversation();
    setSource("Refreshed host capture");
    navigate();
    toast("Panels refreshed. A new conversation starts with this capture.");
  } catch (error) {
    // A cancellation is not a failure, and must not be reported as one.
    // Compared by name, never `instanceof` — this file runs in an iframe and
    // in a `vm` realm, where cross-realm `instanceof` silently falls through.
    if (error && error.name === "AbortError")
      toast(
        refreshTimedOut
          ? `The host did not finish collecting within ${Math.round(REFRESH_TIMEOUT_MS / 1000)} seconds. Your current report is unchanged; the turn may still be running in the native session.`
          : "Refresh cancelled. Your current report is unchanged.",
      );
    else
      toast(
        `The host could not refresh this capture: ${whyFailed(error)}. ` +
          "Your current report is unchanged.",
      );
  } finally {
    refreshAbort = null;
    refreshBusy = false;
    button.disabled = false;
    button.textContent = "Refresh from host";
  }
}

function pick(purpose) {
  if (chatBusy || refreshBusy) {
    toast("Wait for the current answer before changing reports.");
    return;
  }
  filePurpose = purpose;
  $("#file").value = "";
  $("#file").click();
}
/**
 * Refuse an import that would repoint a host-bound workspace at another tenant.
 *
 * normalize() checks tenant identity three times *within* a report — audit
 * against overview, finding against overview — and never once against the
 * session. So a file drop silently retargeted every panel, and the
 * investigation handoff then carried the imported tenant onto a document
 * that reaches a human approver.
 */
/**
 * Parse a report file with a message of our own.
 *
 * The import catch reflects `error.message`, and every other throw on this
 * path carries a sentence written in this file — except the parse, which
 * handed the browser's own parser text straight to a user. So the one error
 * path with no written message was also the only one that echoed raw V8.
 */
function readReport(text) {
  try {
    return JSON.parse(text);
  } catch {
    throw Error(
      "That file is not valid JSON. Choose an Iris overview report or an iris-state.json snapshot.",
    );
  }
}
function guardImportTenant(d) {
  const incoming = tenant(d.overview);
  if (hostBoundTenant && incoming !== hostBoundTenant)
    throw Error(
      `This session is bound to ${hostBoundTenant}; that report belongs to ${incoming}. Open that tenant’s own session to explore it.`,
    );
}
$("#file").onchange = async (e) => {
  if (chatBusy || refreshBusy) {
    toast("Wait for the current answer before changing reports.");
    return;
  }
  const file = e.target.files[0];
  if (!file) return;
  refreshBusy = true;
  try {
    if (file.size > 10 * 1024 * 1024)
      throw Error("Choose a report smaller than 10 MB.");
    const d = normalize(readReport(await file.text()));
    guardImportTenant(d);
    if (filePurpose === "followup") {
      followup = d;
      location.hash = "results";
    } else {
      state = d;
      baseline = null;
      followup = null;
      reviews.clear();
      primaryImported = true;
      resetConversation();
      setSource("Imported capture");
    }
    navigate();
    toast("Report imported locally.");
  } catch (error) {
    toast(error.message);
  } finally {
    refreshBusy = false;
  }
};
/**
 * Label what is on screen, and — when it is not what was asked for — why.
 *
 * `because` is not decoration. The boot chain below demotes live evidence to a
 * captured report to a synthetic demo, and each step used to be a bare
 * `catch {}`: the badge changed and nothing said that a demotion had happened
 * or what caused it. A reader who did not already know the chain existed had
 * no way to tell a live report from a fallback. The reason rides on the badge
 * itself, so it stays on screen rather than passing in a toast.
 */
function setSource(label, because) {
  const badge = $("#source");
  // Mode is not provenance. This used to overwrite `label` outright whenever
  // mode contained "synthetic", so a fixture tenant could never show where its
  // report actually came from — a reader lost the one fact that distinguishes
  // an imported fixture from a host one, and the warning was the only thing
  // left. Say both: where it came from, and that its numbers are invented.
  // "not this tenant's data" is the disclosure and always appears when the
  // mode is synthetic; the "· Synthetic" prefix is dropped when the label
  // already says it. The demo rung's label is literally "Synthetic demo", and
  // an unconditional marker produced "Synthetic demo · Synthetic — not this
  // tenant's data — not this tenant's data — …" in a browser. The unit test
  // matched /Synthetic/ and passed, because it matched twice.
  badge.textContent = isSynthetic()
    ? label +
      (/synthetic/i.test(label) ? "" : " · Synthetic") +
      " — not this tenant's data"
    : label;
  if (because) {
    // The chip carries the proximate reason; the whole chain is one hover
    // away. Putting three clauses in a header chip pushed the controls off
    // a phone, and a reason nobody can read is not a reason.
    badge.textContent += " — " + because.split("; ")[0];
    badge.title = because;
  } else {
    badge.removeAttribute("title");
  }
}
/**
 * Save the current capture as this session's baseline.
 *
 * Refuses a synthetic capture. A baseline is the thing every later number is
 * judged against; letting invented figures become one turns a fixture into the
 * definition of "before", and the unconditional success toast made that look
 * like a deliberate choice rather than an accident. Returns whether it saved.
 */
function saveBaseline() {
  if (!state) {
    toast("Import a report before saving a baseline.");
    return false;
  }
  if (isSynthetic()) {
    toast(
      "This capture is synthetic — its numbers are invented and belong to no tenant. Refresh from the host or import a real report before saving a baseline.",
    );
    return false;
  }
  baseline = structuredClone(state);
  followup = null;
  toast("Baseline saved for this session.");
  return true;
}
document.addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.go) location.hash = b.dataset.go;
  if (b.dataset.ask) ask(b.dataset.ask);
  if (b.dataset.review !== undefined) review(Number(b.dataset.review));
  switch (b.dataset.action) {
    case "import":
      pick("snapshot");
      break;
    case "followup":
      pick("followup");
      break;
    case "baseline":
      if (saveBaseline()) navigate();
      break;
  }
});
$("#import").onclick = () => pick("snapshot");
$("#refresh").onclick = refreshSnapshot;
$("#composer").onsubmit = (e) => {
  e.preventDefault();
  const q = $("#question").value.trim();
  if (q) {
    ask(q);
    $("#question").value = "";
  }
};
$("#question").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    if (!chatBusy) $("#composer").requestSubmit();
  }
});
window.addEventListener("hashchange", navigate);
// Boot: live host evidence, then a captured report, then a synthetic demo,
// then nothing. Every step of that chain was a bare `catch {}` — it degraded
// silently, and a page showing a demo looked like a page showing a tenant.
// Each rung now records why it fell through, and the badge says so.
(async () => {
  const demotions = [];
  try {
    state = await hostSnapshot();
    hostBoundTenant = tenant(state.overview);
    setSource("Host capture");
  } catch (live) {
    demotions.push(`live host evidence unavailable (${whyFailed(live)})`);
    try {
      const r = await fetch("iris-state.json", { cache: "no-store" });
      if (!r.ok) throw hostError("no captured report on this host", r.status);
      state = normalize(await r.json());
      // This file is served from this session's own mount, so it establishes
      // the binding just as a live host capture does. The synthetic rung below
      // deliberately does not: a fixture belongs to no tenant, and binding to
      // one would refuse the real report a person imports to replace it.
      hostBoundTenant = tenant(state.overview);
      setSource("Captured report", demotions[0]);
    } catch (captured) {
      demotions.push(`no captured report (${whyFailed(captured)})`);
      try {
        const r = await fetch("demo-state.json");
        if (!r.ok) throw hostError("no demo capture on this host", r.status);
        state = normalize(await r.json());
        // Two rungs down and showing invented numbers. This one says so in
        // the badge, in a toast, and in the conversation, because a reader
        // who mistakes it for a tenant's cache is the whole failure mode.
        // setSource says whose data this is not; `because` carries only the
        // chain that got us here, or the badge repeats itself.
        setSource("Synthetic demo", demotions.join("; "));
        toast("Showing a synthetic demo capture. These numbers are invented.");
        bubble(
          "assistant",
          "Heads up: no report could be loaded, so this page is showing a " +
            "synthetic demo capture. The numbers and findings on it are " +
            "invented and belong to no tenant. " +
            demotions.join("; ") +
            ".",
        );
      } catch (demo) {
        demotions.push(`no demo capture (${whyFailed(demo)})`);
        setSource("No report loaded", demotions.join("; "));
      }
    }
  }
  refreshBusy = false;
  navigate();
})();
