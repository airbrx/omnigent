# Iris artwork

`iris-portrait.png` was produced with Codex's built-in image generator using the user-supplied `Downloads/IRIS.png` identity reference. No external API key or image CLI was used. The original reference remains unchanged. `airbrx-logo.png` is the existing user asset from Downloads, copied unchanged.

Initial prompt: Preserve the adult woman's facial structure, fair freckled skin, gray-green eyes, copper-red long wavy hair, and white clothing with a subtle orange seam. Remove all poster text, logos, charts, interface elements, and scenery. Produce a shoulders-up photorealistic editorial portrait, full crown and hair visible, calm attentive expression, natural skin texture, soft studio light, square composition.

Correction prompt used on the generated portrait: "Edit this portrait: replace the entire checkerboard background with a uniform solid very dark charcoal #11151b. NO transparency and NO checkerboard. Preserve this exact woman, facial identity, copper red hair, freckles, white clothing, expression, framing, and photorealistic style. Clean hair edges naturally against dark charcoal. No text or other elements."

The first output rendered a checkerboard rather than alpha transparency. Only the corrected dark-background output ships. No metrics or claims from the reference poster are used.
