"""Local HTTP bridge: the chat UI talks to the real agent, on your subscription.

This is a **local development server**, and the repo rule it bends is worth
naming rather than hiding: `CLAUDE.md` says every command is invoke → work →
write → exit, and that the dashboard is generated static HTML, not a service.
A chat UI cannot be static — something has to hold the conversation and call the
model — so this exists as the thinnest possible bridge for local use. It is not
part of the shipped product, and hosting is Omnigent's job, not this file's.

What it does:

* serves whatever is in `ui/` as static files (that directory is Codex's)
* `POST /api/chat` runs one real agent turn through `ClaudeSDKExecutor` — the
  same native executor Omnigent uses, the same four read-only Iris tools, the
  same policy boundary — and returns the model's text plus the tools it called
* `GET /api/state` returns a freshly collected overview/audit snapshot for the
  side panels, or the captured file if a live read is unavailable

Authentication is the subscription: `CLAUDE_CODE_OAUTH_TOKEN` from the host
environment. No API key is involved, and none is read.

Stdlib only, single-threaded on purpose: one conversation, one turn at a time,
no pool that outlives a request beyond the executor itself.

    export PYTHONPATH="$PWD"
    HOST=~/.local/share/uv/tools/omnigent/bin/python
    set -a && . ./.env && set +a
    "$HOST" -m iris.ui_bridge       # then open http://127.0.0.1:8765
"""

from __future__ import annotations

import argparse
import asyncio
import copy
import json
import math
import os
import sys
import threading
import time
from contextlib import suppress
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
UI_DIR = REPO / "ui"

MAX_BODY = 64 * 1024
DEFAULT_PORT = 8765

# A loopback bind is not an access control. Any page in the operator's browser
# can POST to 127.0.0.1, and a hostile name resolving to loopback (DNS
# rebinding) can reach a Host-agnostic server, so a page they merely visited
# could spend their subscription and read their tenant's evidence through this
# bridge. Both are checked before a turn runs.
LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
# Populated at bind time. An origin is scheme + host + port: a different local
# port is a different origin, and comparing hostnames alone would accept a page
# served by any other process on this machine.
ALLOWED_ORIGINS = set()
ALLOWED_AUTHORITIES = set()
MIN_DEADLINE, MAX_DEADLINE = 10.0, 600.0
# Ceiling on turns per process, so a runaway page cannot spend unbounded
# subscription tokens. Restart to reset; deliberately not resettable over HTTP.
MAX_TURNS_PER_PROCESS = int(os.environ.get("IRIS_UI_MAX_TURNS", "200"))
# Conversation resets are triggered by the shape of a client-supplied history,
# which is a development convenience and NOT request identity. A caller that
# always sends a single-message history would otherwise clear the upstream
# budget on every question and spend without limit. Bounding resets means the
# per-conversation budget can still be renewed by an operator and cannot be
# renewed indefinitely by a page. A hosted path must replace this with identity
# the host injects and trusts; it must never promote this heuristic.
MAX_RESETS_PER_PROCESS = int(os.environ.get("IRIS_UI_MAX_RESETS", "40"))
_turns_served = 0
_resets_served = 0


def configure_origins(host, port):
    """Record exactly which origins and authorities this process answers for."""
    ALLOWED_ORIGINS.clear()
    ALLOWED_AUTHORITIES.clear()
    for name in LOOPBACK_HOSTS:
        bracketed = f"[{name}]" if ":" in name else name
        ALLOWED_AUTHORITIES.add(f"{bracketed}:{port}".lower())
        ALLOWED_AUTHORITIES.add(bracketed.lower())
        for scheme in ("http", "https"):
            ALLOWED_ORIGINS.add(f"{scheme}://{bracketed}:{port}".lower())
    return ALLOWED_ORIGINS

# The UI checks /api/state before every turn to confirm it is talking to the
# host it thinks it is. A full collection is ~13s and a dozen upstream calls, so
# doing that per message would add that cost to every question and hammer a
# tenant's API for an answer that does not change minute to minute. Serve a
# recent collection instead, and say how old it is rather than implying it is
# instantaneous.
STATE_TTL_SECONDS = 90
_state_cache = None  # (collected_at_monotonic, payload)

_lock = threading.Lock()
_loop_lock = threading.RLock()
_state_lock = threading.Lock()
_session = None

# One event loop for the whole process, on its own thread.
#
# The executor holds a CLI client bound to the loop that created it, so
# `asyncio.run` per request would hand the second request an executor whose
# transport belongs to a loop that has already closed. The first turn succeeds
# and every later one fails — which is exactly what it did before this existed.
_loop = None
_loop_thread = None
_session_root = None


def _loop_once():
    """The shared loop, created once even if two threads ask at the same time."""
    global _loop, _loop_thread
    with _loop_lock:
        if _loop is None:
            _loop = asyncio.new_event_loop()
            _loop_thread = threading.Thread(
                target=_loop.run_forever, name="iris-agent", daemon=True
            )
            _loop_thread.start()
        return _loop


def _run(coro, timeout):
    """Run a coroutine on the shared loop and wait for it from this thread.

    Cancels on timeout. Giving up on the future without cancelling leaves the
    coroutine running on the shared loop: the caller sees a timeout while the
    turn keeps going, still holding the executor and still spending budget, and
    the next request queues behind work nobody is waiting for.
    """
    future = asyncio.run_coroutine_threadsafe(coro, _loop_once())
    try:
        return future.result(timeout)
    except BaseException:
        future.cancel()
        raise


def stop_loop(timeout=5.0):
    """Stop and close the shared loop. Returns True if it was running."""
    global _loop, _loop_thread
    with _loop_lock:
        loop, thread = _loop, _loop_thread
        _loop, _loop_thread = None, None
    if loop is None:
        return False
    with suppress(Exception):
        loop.call_soon_threadsafe(loop.stop)
    if thread is not None:
        thread.join(timeout)
    with suppress(Exception):
        loop.close()
    return True


def new_conversation():
    """Clear the tool state so a fresh conversation gets a fresh budget.

    Budgets are durable and scoped to a conversation, which is the right rule:
    it is what stops a runaway session spending without limit. But the bridge
    held one state root for the life of the process, so an operator asking a
    seventh question hit "budget exhausted" and had to restart the server. The
    UI already clears its transcript; this is the server side of the same act.

    Recursive on purpose: the durable files are not at the session root, they
    are under the host's tool-state directory (`.tool_state/iris/`). A
    non-recursive glob here matched nothing, deleted nothing and still returned
    True, so the caller counted a reset that never happened and the budget's
    persisted `started_epoch` survived -- every turn past the deadline then
    failed as "budget exhausted" with most of the call budget unspent.
    """
    root = _session_root
    if root is None or not Path(root).is_dir():
        return False
    for path in Path(root).rglob("iris-*.json"):
        try:
            path.unlink()
        except OSError:
            return False
    return True


def _session_once():
    """Build the executor once and reuse it; connecting is the expensive part."""
    global _session, _session_root
    if _session is None:
        sys.path.insert(0, str(REPO))
        from iris.local_host import _build

        work = (REPO / ".iris-local").resolve()
        work.mkdir(mode=0o700, exist_ok=True)
        run = work / "ui-session"
        run.mkdir(mode=0o700, exist_ok=True)
        spec, executor, tools, registry, model, auth = _build(REPO / "omnigent", run)
        _session_root = run
        _session = {
            "executor": executor,
            "schemas": [t.get_schema()["function"] for t in tools],
            "instructions": spec.instructions or "Read-only Airbrx operations agent.",
            "model": model,
            "registry": registry,
            "auth": auth,
        }
    return _session


def discard_session():
    """Forget the cached executor so the next request builds a fresh one.

    The executor holds a CLI subprocess. When that dies — a crash, an auth
    expiry, an OS signal — the cached object keeps being handed out and every
    later turn fails identically until someone restarts the server. That is the
    same shape as the closed-event-loop bug: one broken thing cached forever.
    Dropping it is deliberate and not a retry: the failed turn stays failed and
    is reported, because silently re-running it could spend a second turn the
    operator never asked for.
    """
    global _session
    session, _session = _session, None
    if session is not None:
        executor = session.get("executor")
        closer = getattr(executor, "close", None)
        if closer is not None:
            with suppress(Exception):
                _run(closer(), 20)
    return session is not None


async def _turn(history, deadline):
    from omnigent.inner.executor import ExecutorConfig

    s = _session_once()
    used, failed = [], None
    final_response = None
    try:
        async with asyncio.timeout(deadline):
            async for event in s["executor"].run_turn(
                history, s["schemas"], s["instructions"], ExecutorConfig(model=s["model"])
            ):
                kind = type(event).__name__
                if kind == "ToolCallRequest":
                    used.append(getattr(event, "name", "?"))
                elif kind == "TurnComplete":
                    if not getattr(event, "continue_turn", False):
                        response = getattr(event, "response", None)
                        if isinstance(response, str):
                            final_response = response
                elif kind == "ExecutorError":
                    # The raw SDK error can carry source text; report the fact only.
                    failed = "the turn did not complete"
    except TimeoutError:
        failed = f"the turn passed its {deadline:.0f}s deadline"
    if final_response is None:
        failed = failed or "the executor did not confirm a completed response"
    # The final response includes output-policy modifications. Streamed chunks
    # are provisional and must never bypass that final decision.
    return final_response if final_response is not None else "", used, failed


def _fresh_enough(max_age):
    """A private copy of the cached payload, or None if it is too old.

    Deep, not shallow: a shallow copy shares every nested object, so a caller
    editing `overview` would edit what the next caller receives. The cache would
    then serve a value nobody collected.
    """
    if _state_cache is None:
        return None
    collected_at, payload = _state_cache
    age = time.monotonic() - collected_at
    if age >= max_age:
        return None
    payload = copy.deepcopy(payload)
    payload["cache_age_seconds"] = round(age, 1)
    return payload


def _cached_state(max_age=STATE_TTL_SECONDS):
    """A recent collection, re-collecting only once it is older than max_age.

    One collection at a time. Without the lock, concurrent misses each start
    their own ~13-second collection against the tenant's API — the duplicate
    upstream load the cache exists to prevent.
    """
    global _state_cache
    payload = _fresh_enough(max_age)
    if payload is not None:
        return payload
    with _state_lock:
        # Another thread may have collected while we waited for the lock.
        payload = _fresh_enough(max_age)
        if payload is not None:
            return payload
        payload = _collect_state()
        payload["cache_age_seconds"] = 0.0
        _state_cache = (time.monotonic(), payload)
        return copy.deepcopy(payload)


def _collect_state():
    """A fresh overview + audit for the side panels, falling back to the capture."""
    sys.path.insert(0, str(REPO))
    from iris.config import Config
    from iris.tools import Iris

    async def run():
        iris = await Iris(Config.from_env()).start()
        return {"overview": await iris.overview(), "audit": await iris.audit()}

    state = _run(run(), 300)
    # Annual counts are withheld from the model view on purpose; the operator UI
    # is a different audience and can show them, so read the full report artifact.
    rules, meta = [], {}
    report_path = (state["overview"].get("artifacts") or {}).get("report.json")
    full = state["overview"]
    if report_path and Path(report_path).is_file():
        try:
            full = json.loads(Path(report_path).read_text())
        except (OSError, ValueError):
            full = state["overview"]
    for e in full.get("evidence", []):
        if e.get("source_tool") == "get_rule_effectiveness" and isinstance(e.get("data"), dict):
            rules = e["data"].get("rules") or []
            meta = {k: e["data"].get(k) for k in ("year", "generatedAt", "totalQueries")}
    state["rules"] = rules
    state["rule_effectiveness_meta"] = meta
    captured = UI_DIR / "iris-state.json"
    if captured.exists():
        state["capabilities"] = json.loads(captured.read_text()).get("capabilities", {})
    return state


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(UI_DIR), **kw)

    def end_headers(self):
        # A development bridge serving files someone is actively editing: a
        # cached app.js means testing the previous version and drawing the wrong
        # conclusion from it, which cost a round trip before this existed.
        self.send_header("Cache-Control", "no-store, must-revalidate")
        super().end_headers()

    def log_message(self, fmt, *args):  # quieter, and never echo a body
        sys.stderr.write("  %s %s\n" % (self.command, self.path.split("?")[0]))

    def _origin_ok(self):
        """Reject callers this process does not answer for.

        Applied to every route, not just the API: the served directory holds
        captured tenant evidence, so a rebound Host reading `iris-state.json`
        leaks the same data a chat turn would.

        Origins are compared whole. A different local port is a different
        origin, and matching on hostname alone would accept any other process
        on this machine.
        """
        host = (self.headers.get("Host") or "").strip()
        if host:
            if host.count(":") > 1 and not host.startswith("["):
                host = f"[{host}]"  # bare IPv6 literal
            if host.lower() not in ALLOWED_AUTHORITIES:
                return "unexpected Host header"
        origin = (self.headers.get("Origin") or "").strip()
        if origin and origin.lower() not in ALLOWED_ORIGINS:
            return "cross-origin request"
        return None

    def _json(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        refusal = self._origin_ok()
        if refusal:
            return self._json(403, {"error": f"refused: {refusal}"})
        if self.path.split("?")[0] == "/api/state":
            try:
                # ?fresh=1 forces a re-collection; the UI's pre-turn check does
                # not need one, but an operator refreshing the panels might.
                fresh = "fresh=1" in (self.path.split("?", 1)[1] if "?" in self.path else "")
                return self._json(200, _cached_state(0 if fresh else STATE_TTL_SECONDS))
            except Exception as exc:
                captured = UI_DIR / "iris-state.json"
                if captured.exists():
                    payload = json.loads(captured.read_text())
                    payload["stale"] = f"live collection failed ({type(exc).__name__}); showing the captured run"
                    return self._json(200, payload)
                return self._json(503, {"error": f"no state available ({type(exc).__name__})"})
        return super().do_GET()

    def do_POST(self):
        if self.path.split("?")[0] != "/api/chat":
            return self._json(404, {"error": "no such endpoint"})
        refusal = self._origin_ok()
        if refusal:
            return self._json(403, {"error": f"refused: {refusal}"})
        if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
            return self._json(415, {"error": "Content-Type must be application/json"})
        global _turns_served, _resets_served
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._json(400, {"error": "bad Content-Length"})
        if length <= 0 or length > MAX_BODY:
            return self._json(413, {"error": "request body missing or too large"})
        try:
            payload = json.loads(self.rfile.read(length))
        except ValueError:
            return self._json(400, {"error": "body is not JSON"})
        if not isinstance(payload, dict):
            return self._json(400, {"error": "body must be a JSON object"})

        history = payload.get("history")
        if not isinstance(history, list) or not history:
            return self._json(400, {"error": "history must be a non-empty list"})
        clean = []
        for item in history[-24:]:
            if not isinstance(item, dict):
                continue
            role = item.get("role")
            content = item.get("content")
            if role in ("user", "assistant") and isinstance(content, str) and content.strip():
                clean.append({"role": role, "content": content[:8000]})
        if not clean or clean[-1]["role"] != "user":
            return self._json(400, {"error": "the last message must be from the user"})

        raw_deadline = payload.get("deadline")
        if raw_deadline is None:
            deadline = 300.0
        elif isinstance(raw_deadline, bool) or not isinstance(raw_deadline, (int, float)):
            return self._json(400, {"error": "deadline must be a number of seconds"})
        else:
            deadline = float(raw_deadline)
            # Reject NaN and infinities before they reach a scheduler, where a
            # non-finite timeout means a turn that never returns.
            if not math.isfinite(deadline) or not (MIN_DEADLINE <= deadline <= MAX_DEADLINE):
                return self._json(400, {
                    "error": f"deadline must be between {MIN_DEADLINE:.0f} and {MAX_DEADLINE:.0f} seconds"
                })
        # One turn at a time: the executor holds a single CLI session.
        with _lock:
            # The client owns the transcript, so a history of exactly one user
            # message is a conversation that just started — which is when a
            # fresh budget is due.
            if len(clean) == 1 and _resets_served < MAX_RESETS_PER_PROCESS:
                _session_once()
                if new_conversation():
                    _resets_served += 1
            # Checked and taken together: two in-flight requests reading the
            # count before either increments would both pass the ceiling.
            if _turns_served >= MAX_TURNS_PER_PROCESS:
                return self._json(429, {
                    "error": f"turn ceiling of {MAX_TURNS_PER_PROCESS} reached for this "
                             "process; restart the bridge to continue"
                })
            _turns_served += 1
            try:
                # A little headroom over the turn deadline so the turn reports
                # its own timeout rather than being cut off mid-sentence.
                text, used, failed = _run(_turn(clean, deadline), deadline + 30)
            except Exception as exc:
                discard_session()
                return self._json(500, {
                    "error": f"{type(exc).__name__}: the turn failed before completing; "
                             "the next request will start a new session"
                })
            if failed:
                # A turn the executor could not complete may have left the CLI
                # session unusable. Rebuild next time rather than handing the
                # same broken one to every later question.
                discard_session()
        return self._json(200, {"text": text, "tools": used, "failed": failed})


def main(argv=None):
    parser = argparse.ArgumentParser(description="Local bridge for the Iris chat UI.")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--host", default="127.0.0.1", help="bind address (loopback by default)")
    args = parser.parse_args(argv)

    sys.path.insert(0, str(REPO))
    from iris.model_auth import resolve as resolve_model_auth

    auth = resolve_model_auth(os.environ)
    print(auth.describe(), file=sys.stderr)
    for note in auth.notes:
        print("  note: " + note, file=sys.stderr)
    if not os.environ.get("IRIS_TENANT_ID"):
        print("  note: IRIS_TENANT_ID is unset; tool calls will fail until it is bound", file=sys.stderr)

    if args.host not in LOOPBACK_HOSTS:
        raise SystemExit(
            f"refusing to bind {args.host!r}: this bridge runs real agent turns on the "
            f"operator's subscription and is loopback-only ({sorted(LOOPBACK_HOSTS)})"
        )
    configure_origins(args.host, args.port)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(
        f"Iris chat UI on http://{args.host}:{args.port}  (Ctrl-C to stop)\n"
        f"  same-origin only, JSON bodies to {MAX_BODY // 1024} KiB, "
        f"{MAX_TURNS_PER_PROCESS} turns and {MAX_RESETS_PER_PROCESS} budget resets per process\n"
        f"  development bridge: conversations are derived from client-supplied history shape, "
        f"not trusted identity",
        file=sys.stderr,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped", file=sys.stderr)
    finally:
        # Close the CLI subprocess, then stop and close the loop it ran on,
        # rather than leaving either to a daemon thread and process exit.
        # Drain active HTTP handlers while their shared loop is still alive.
        # Otherwise a state request can be stranded on the closed loop.
        server.server_close()
        discard_session()
        stop_loop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
