"""Private, atomic, tenant/run-namespaced artifacts; no model-controlled paths."""

from datetime import datetime, timezone, timedelta
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import tempfile
import uuid

SECRET = re.compile(
    r"(?i)(?:bearer\s+\S+|(?:sk-|airbrx_(?:pat|refresh)_)[A-Za-z0-9_\-]+|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)"
)
PRIVATE_KEY = re.compile(
    r"(?i)(password|secret|token|authorization|credential|connectionstring|cookie|headers|statement$|^standardizedsql$|^sql$|^query$)"
)
PERSONAL = re.compile(r"(?i)(email|username|userid|^user$)")


def sanitize(value, key=""):
    if PRIVATE_KEY.search(key):
        return "[redacted]"
    if PERSONAL.search(key) and value is not None:
        return "identity-" + hashlib.sha256(str(value).encode()).hexdigest()[:12]
    if isinstance(value, dict):
        return {
            SECRET.sub("[redacted-key]", str(k)): sanitize(v, str(k))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [sanitize(v, key) for v in value[:1000]]
    if isinstance(value, str):
        value = SECRET.sub("[redacted]", value)
        value = re.sub(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", "[identity]", value)
        value = re.sub(r"'(?:''|[^'])*'", "'[literal]'", value)
        return value[:2000]
    return value


def contains_credentials(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if (
                re.search(
                    r"(?i)(password|secret|token|authorization|api.?key|connectionstring|cookie|httpheaders)",
                    str(key),
                )
                and item
            ):
                return True
            if contains_credentials(item):
                return True
    elif isinstance(value, list):
        return any(contains_credentials(item) for item in value)
    elif isinstance(value, str):
        return bool(SECRET.search(value))
    return False


def now():
    return datetime.now(timezone.utc).isoformat()


def atomic(path, data):
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix=".iris-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class Artifacts:
    def __init__(self, root, tenant, *, run_id=None):
        self.root = Path(root).absolute()
        self.tenant = tenant
        self.run_id = run_id or uuid.uuid4().hex
        if not re.fullmatch(r"[0-9a-f]{32}", self.run_id):
            raise ValueError("Invalid internal run ID")
        self.path = (
            self.root / hashlib.sha256(tenant.encode()).hexdigest() / self.run_id
        )
        # Refuse symlink components, including pre-existing root parents.
        for component in [self.path, *self.path.parents]:
            if component.is_symlink():
                raise ValueError("Artifact paths cannot contain symlinks")
        self.path.mkdir(parents=True, mode=0o700, exist_ok=True)
        os.chmod(self.path.parent, 0o700)
        os.chmod(self.path, 0o700)

    def write(self, report, proposal=None):
        if proposal is not None and contains_credentials(
            proposal.get("candidate", proposal)
        ):
            raise ValueError(
                "Credential-like content prevents proposal artifact export"
            )
        envelope = {
            "schemaVersion": 1,
            "generatedAt": now(),
            "owner": "iris-v1",
            "tenantId": self.tenant,
            "runId": self.run_id,
            **report,
        }
        atomic(
            self.path / "report.json", json.dumps(envelope, indent=2, allow_nan=False)
        )
        from iris.reporting import render_report
        text = render_report(report)
        atomic(self.path / "report.md", text)
        names = ["report.json", "report.md"]
        if proposal is not None:
            encoded = json.dumps(proposal, indent=2, allow_nan=False)
            if SECRET.search(encoded):
                raise ValueError(
                    "Credential-like content prevents proposal artifact export"
                )
            atomic(
                self.path / "proposal.json",
                json.dumps(
                    {"schemaVersion": 1, "generatedAt": now(), **proposal}, indent=2
                ),
            )
            names.append("proposal.json")
        atomic(
            self.path / "manifest.json",
            json.dumps(
                {
                    "schemaVersion": 1,
                    "generatedAt": now(),
                    "owner": "iris-v1",
                    "tenantId": self.tenant,
                    "runId": self.run_id,
                    "files": names,
                }
            ),
        )
        return {name: str(self.path / name) for name in names}


def cleanup(root, *, days=30, current=None):
    """Only delete expired, structurally valid Iris-owned run directories."""
    cutoff = (current or datetime.now(timezone.utc)) - timedelta(days=days)
    removed = []
    root = Path(root)
    if root.is_symlink():
        raise ValueError("Retention root cannot be a symlink")
    for tenant in root.glob("*"):
        if tenant.is_symlink() or not re.fullmatch(r"[0-9a-f]{64}", tenant.name):
            continue
        for run in tenant.glob("*"):
            if run.is_symlink() or not re.fullmatch(r"[0-9a-f]{32}", run.name):
                continue
            manifest = run / "manifest.json"
            if not manifest.is_file() or manifest.is_symlink():
                continue
            data = json.loads(manifest.read_text())
            if (
                data.get("owner") == "iris-v1"
                and data.get("runId") == run.name
                and hashlib.sha256(data["tenantId"].encode()).hexdigest() == tenant.name
                and datetime.fromisoformat(data["generatedAt"]) < cutoff
            ):
                shutil.rmtree(run)
                removed.append(run.name)
    return removed
