"""Explicit synthetic fixture transport; never presented as live evidence."""

from copy import deepcopy
from types import SimpleNamespace
from iris.mcp_client import ALLOWED, REQUIRED


class FixtureAuth:
    async def token(self, *, force=False):
        return "fixture-only"


class FixtureWire:
    def __init__(self, tenant):
        self.tenant = tenant
        self.calls = []
        self.baseline = {
            "tenantId": tenant,
            "version": "cache-bust-17",
            "custom": {"preserve": True},
            "defaults": {
                "ttlSeconds": 0,
                "cacheKeyElements": ["standardizedSql", "userId"],
            },
            "rules": [
                {
                    "id": "report-cache",
                    "name": "Report cache",
                    "priority": 40,
                    "enabled": True,
                    "mode": "all",
                    "conditions": {
                        "statementType": {"equals": "SELECT"},
                        "tables": {"includes": "analytics.reports"},
                    },
                    "actions": {
                        "cache": {"ttlSeconds": 60},
                        "cacheKeyElements": ["standardizedSql", "userId"],
                    },
                }
            ],
        }

    async def request(self, token, method, args):
        self.calls.append((method, deepcopy(args)))
        if method == "tools/list":
            return SimpleNamespace(
                tools=[
                    SimpleNamespace(
                        name=n,
                        inputSchema={
                            "type": "object",
                            "properties": {
                                k: {"type": "object" if k == "rules" else "string"}
                                for k in REQUIRED.get(n, {"tenantid"})
                            },
                            "required": [
                                k
                                for k in REQUIRED.get(n, {"tenantid"})
                                if k not in ("year", "month", "day")
                            ],
                        },
                    )
                    for n in sorted(ALLOWED)
                ],
                nextCursor=None,
            )
        if method == "get_summary":
            value = {
                "totalCacheHits": 80,
                "totalCacheMisses": 20,
                "totalHits": 100,
                "totalQueries": 12,
            }
        elif method == "get_tenant_rules":
            value = deepcopy(self.baseline)
        elif method == "get_rule_effectiveness":
            value = {
                "rules": [
                    {
                        "ruleId": "report-cache",
                        "cacheHits": 80,
                        "cacheMisses": 20,
                        "totalExecutions": 100,
                    }
                ]
            }
        elif method == "get_cache_opportunities":
            value = {
                "repeatMisses": [
                    {
                        "queryHash": "synthetic-001",
                        "executionCount": 20,
                        "matchedRule": "report-cache",
                    }
                ]
            }
        elif method == "describe_log_schema":
            value = {
                "table": "proxy_logs",
                "columns": [
                    {"name": n, "type": "VARCHAR"}
                    for n in ("day", "cacheStatus", "queryHash", "ruleId", "userName")
                ],
            }
        elif method == "query_logs":
            value = {
                "columns": ["cacheStatus", "executions"],
                "rows": [{"cacheStatus": "MISS", "executions": 20}],
                "rowCount": 1,
                "truncated": False,
            }
        elif method == "validate_rules":
            value = {"valid": True, "errors": [], "warnings": [], "fixture": True}
        elif method == "preview_rule_change":
            value = {
                "written": False,
                "validation": {"valid": True, "errors": [], "warnings": []},
                "diff": {"summary": {"destructive": False}},
                "warning": None,
                "fixture": True,
            }
        else:
            value = {}
        return SimpleNamespace(isError=False, structuredContent=value, content=[])
