"""PAT exchange and renewal. Token material remains in memory."""

import asyncio
import time
import math
import httpx


class UpstreamError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


class Auth:
    def __init__(self, api_url, pat, *, client=None, clock=time.monotonic):
        if not pat:
            raise UpstreamError(
                "authentication", "AIRBRX_PAT is required for live mode"
            )
        self.api_url, self._pat = api_url, pat
        self._client, self._clock = client, clock
        self._access, self._refresh, self._expires = None, None, 0
        self._lock = asyncio.Lock()

    async def token(self, *, force=False):
        async with self._lock:
            if not force and self._access and self._clock() < self._expires - 60:
                return self._access
            payload = (
                {"grant_type": "refresh_token", "refresh_token": self._refresh}
                if self._refresh
                else {"grant_type": "pat_exchange", "pat": self._pat}
            )
            if self._client is None:
                async with httpx.AsyncClient(
                    timeout=20, follow_redirects=False
                ) as client:
                    response = await client.post(
                        self.api_url + "/oauth/token", json=payload
                    )
            else:
                response = await self._client.post(
                    self.api_url + "/oauth/token", json=payload
                )
            if response.status_code != 200:
                raise UpstreamError(
                    "authentication",
                    "PAT exchange/renewal rejected (HTTP %s)" % response.status_code,
                )
            try:
                data = response.json()
                access, expiry = data["access_token"], data["expires_in"]
                if (
                    not isinstance(access, str)
                    or not access
                    or type(expiry) not in (int, float)
                    or not math.isfinite(expiry)
                    or expiry <= 0
                ):
                    raise ValueError()
            except (ValueError, KeyError, TypeError):
                raise UpstreamError(
                    "authentication", "Malformed token response"
                ) from None
            self._access = access
            self._refresh = data.get("refresh_token", self._refresh)
            self._expires = self._clock() + expiry
            return access
