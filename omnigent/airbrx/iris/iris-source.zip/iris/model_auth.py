"""Which credential the Claude CLI runs on, and why the obvious one does not work.

Iris runs on the Claude subscription. That is not a preference here, it is what
the runtime does: the Omnigent `claude_sdk` executor removes `ANTHROPIC_API_KEY`
from the child environment before spawning the CLI, deliberately, so the session
bills the subscription rather than a developer key (see
`omnigent/inner/claude_sdk_executor.py`, around the `_unset_env_var` call in
`_get_or_create_client`).

That has a consequence worth stating plainly, because it is a silent trap:
**setting `ANTHROPIC_API_KEY` has no effect.** It is not read, not preferred, not
merged — it is deleted. Someone who sets it and waits for the bill to move would
be waiting on a variable that never reaches the process.

So a real key, when there is one, goes through the mechanism the CLI does honour:
an `apiKeyHelper` command that prints the key. The helper references
`IRIS_ANTHROPIC_API_KEY` — a name the executor does not strip — so the secret
travels in the environment rather than being baked into a settings file or a
process argument list.

Two modes, chosen by `IRIS_ANTHROPIC_AUTH`:

- `subscription` (default): no helper. The CLI uses `CLAUDE_CODE_OAUTH_TOKEN`
  when the host provides one, and otherwise whatever credentials the local CLI
  has stored. A remote host has no local keychain, so a host needs the token:
  `claude setup-token` mints one.
- `api_key`: the helper path above, with `IRIS_ANTHROPIC_API_KEY` set.

Nothing here logs, returns or interpolates a secret value. `repr` and `describe`
are safe to print.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = [
    "SUBSCRIPTION",
    "API_KEY",
    "MODES",
    "KEY_ENV",
    "OAUTH_ENV",
    "DISCARDED_ENV",
    "ModelAuth",
    "resolve",
]

SUBSCRIPTION = "subscription"
API_KEY = "api_key"
MODES = (SUBSCRIPTION, API_KEY)

MODE_ENV = "IRIS_ANTHROPIC_AUTH"
KEY_ENV = "IRIS_ANTHROPIC_API_KEY"
OAUTH_ENV = "CLAUDE_CODE_OAUTH_TOKEN"
DISCARDED_ENV = "ANTHROPIC_API_KEY"

# Prints the key on stdout for the CLI. The variable is referenced, never
# expanded here, so the secret stays out of the settings payload.
API_KEY_HELPER = f'printf %s "${KEY_ENV}"'

_SETUP_TOKEN_NOTE = (
    f"No {OAUTH_ENV} is set, so the CLI will fall back to credentials stored "
    "locally by `claude`. That works on a developer machine and not on a remote "
    "host, which has no keychain: run `claude setup-token` and set the result as "
    f"{OAUTH_ENV} in the host's secret store."
)
_DISCARDED_NOTE = (
    f"{DISCARDED_ENV} is set and will be discarded. The Omnigent executor removes "
    "it from the child environment so the session bills the subscription; it is "
    f"not a fallback. Set {MODE_ENV}={API_KEY} and {KEY_ENV} to use a real key."
)
_STALE_OAUTH_NOTE = (
    f"{OAUTH_ENV} is set but {MODE_ENV}={API_KEY} was selected, so it is removed from the "
    "child environment. An ambient subscription token must not outrank an explicitly chosen "
    "credential, or the bill lands on the wrong account with nothing in the output to show it."
)
_UNSUPPORTED_LAUNCH = (
    f"{MODE_ENV}={API_KEY} is not wired through the normal native launcher: it forwards the "
    "environment but not the executor's apiKeyHelper setting, so the CLI would fall back to "
    "subscription auth and the run would look successful while billing the wrong account. Use "
    "the explicit smoke path, which passes executor kwargs, until that wiring exists and is "
    "proven."
)
_BILLING_NOTE = (
    "Billing leaves the subscription: requests authenticate with the supplied "
    "key and are charged to its account."
)


@dataclass(frozen=True)
class ModelAuth:
    """A resolved model-auth decision. Holds secret values; never prints them."""

    mode: str
    api_key_helper: str | None = None
    provisioned: bool = False
    notes: tuple[str, ...] = ()
    _secrets: dict = field(default_factory=dict, repr=False)
    _unset: tuple[str, ...] = ()

    @property
    def native_launch_supported(self) -> bool:
        """Whether the ordinary native launcher can honour this mode.

        Subscription needs nothing but the environment, which the launcher
        already forwards. Key mode needs the executor's `apiKeyHelper` setting,
        which it does not forward — so key mode fails closed there rather than
        running on the subscription and reporting success.
        """
        return self.mode != API_KEY

    def unsupported_launch_reason(self) -> str | None:
        return None if self.native_launch_supported else _UNSUPPORTED_LAUNCH

    def unset_env(self) -> tuple[str, ...]:
        """Environment names the launcher must delete before spawning."""
        return self._unset

    def executor_kwargs(self) -> dict:
        """Keyword arguments for `ClaudeSDKExecutor`."""
        return {"api_key_helper": self.api_key_helper} if self.api_key_helper else {}

    def passthrough_env(self) -> dict:
        """Environment entries that must reach the CLI subprocess.

        Returns a fresh copy each call so a caller cannot mutate the resolved
        decision, and so nothing holds a second reference to the values.
        """
        return dict(self._secrets)

    def describe(self) -> str:
        """A one-line summary safe to log or print in a preflight report."""
        state = "provisioned" if self.provisioned else "not provisioned"
        helper = "apiKeyHelper" if self.api_key_helper else "no helper"
        return f"model auth: {self.mode} ({state}, {helper})"

    def __repr__(self) -> str:
        return (
            f"ModelAuth(mode={self.mode!r}, provisioned={self.provisioned!r}, "
            f"api_key_helper={'set' if self.api_key_helper else None}, "
            f"secrets=<{len(self._secrets)} redacted>)"
        )


def _clean(environ: dict, name: str) -> str:
    value = environ.get(name) or ""
    return value.strip() if isinstance(value, str) else ""


def resolve(environ: dict) -> ModelAuth:
    """Resolve the model-auth mode from an environment mapping.

    Raises ValueError for an unknown mode, or for `api_key` mode with no usable
    key: asking for key auth without a key is a configuration mistake, and
    falling back to the subscription silently would bill the wrong account.
    """
    mode = _clean(environ, MODE_ENV).lower() or SUBSCRIPTION
    if mode not in MODES:
        raise ValueError(f"{MODE_ENV} must be one of {list(MODES)}, got {mode!r}")

    notes: list[str] = []
    discarded = _clean(environ, DISCARDED_ENV)

    if mode == SUBSCRIPTION:
        token = _clean(environ, OAUTH_ENV)
        if not token:
            notes.append(_SETUP_TOKEN_NOTE)
        if discarded:
            notes.append(_DISCARDED_NOTE)
        return ModelAuth(
            mode=SUBSCRIPTION,
            api_key_helper=None,
            provisioned=bool(token),
            notes=tuple(notes),
            _secrets={OAUTH_ENV: token} if token else {},
        )

    key = _clean(environ, KEY_ENV)
    if not key:
        if discarded:
            raise ValueError(
                f"{MODE_ENV}={API_KEY} requires {KEY_ENV}. {DISCARDED_ENV} is set, but the "
                "Omnigent executor strips that variable before spawning the CLI, so it would "
                f"never be read. Copy the key to {KEY_ENV}."
            )
        raise ValueError(f"{MODE_ENV}={API_KEY} requires a non-empty {KEY_ENV}")

    notes.append(_BILLING_NOTE)
    if discarded:
        notes.append(_DISCARDED_NOTE)
    stale_oauth = _clean(environ, OAUTH_ENV)
    if stale_oauth:
        notes.append(_STALE_OAUTH_NOTE)
    return ModelAuth(
        mode=API_KEY,
        api_key_helper=API_KEY_HELPER,
        provisioned=True,
        notes=tuple(notes),
        _secrets={KEY_ENV: key},
        _unset=(OAUTH_ENV,) if stale_oauth else (),
    )
