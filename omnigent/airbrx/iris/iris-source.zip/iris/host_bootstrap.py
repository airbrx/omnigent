"""Opt-in process-local compatibility adapter for the inspected Omnigent build."""

import hashlib
import inspect
from pathlib import Path

# Reviewed for omnigent c1759674 (0.13.0) — a same-version rebuild of the
# previously reviewed b30937b4, so the version string does not distinguish
# them and only this hash does. `ToolManager.__init__` keeps its signature,
# `shutdown()` and `_tools`, so the adapter's contract still holds.
#
# The whole diff is one 13-line hunk: upstream now implements the Iris tool
# boundary natively. On `is_iris(spec)` it validates the spec, refuses client
# tools and OS environments, loads only `spec.local_tools`, and RETURNS before
# `_register_skill_tools()` / `_register_builtin_tools()` /
# `_register_sub_agent_tools()`. The scheduled-task and session-rename tools
# flagged in the b30937b4 review are therefore unreachable on the Iris path by
# construction, rather than registered and then wiped as this adapter does.
#
# That makes this adapter redundant on the native path, and possibly worse:
# `omnigent.airbrx.iris.package.source_root()` imports its own pinned `iris`
# and raises "Another Iris package is already loaded" when a different one was
# imported first — which is exactly what `scripts/iris_host.py` arranges via
# PYTHONPATH. Read from source, not reproduced; the bootstrap guard fires
# first. This re-pin is a keep-moving measure for local development, not a
# decision to keep the adapter. See docs/build/BOARD.md.
#
# Preflight remains the proof, and it must keep asserting exactly four tools.
MANAGER_SHA256 = "3a90fecee0f319ad8c43ee834b04b2ae8a365fc4475d69330c5f3340688d6c40"


def install(bundle):
    from omnigent.tools.manager import ToolManager
    from omnigent.spec.parser import parse
    from iris.omnigent_runtime import assert_bundle_boundary, build_tools

    if getattr(ToolManager, "_iris_bootstrap", False):
        return
    source = Path(inspect.getfile(ToolManager))
    if hashlib.sha256(source.read_bytes()).hexdigest() != MANAGER_SHA256:
        raise RuntimeError("Unreviewed Omnigent ToolManager revision; rerun compatibility review")
    bundle = Path(bundle).resolve(strict=True)
    selected = parse(bundle)
    if selected.name != "iris":
        raise ValueError("Iris launcher requires a bundle named iris")
    assert_bundle_boundary(selected)
    original = ToolManager.__init__

    def initialize(self, spec, client_tool_specs=None, workdir=None,
                   sandbox_enabled=True, os_env=None):
        if spec.name != "iris":
            return original(self, spec, client_tool_specs, workdir, sandbox_enabled, os_env)
        assert_bundle_boundary(spec)
        if client_tool_specs or os_env is not None:
            raise ValueError("Iris does not accept extra client tools or OS environments")
        original(self, spec, None, workdir, sandbox_enabled, None)
        self.shutdown()
        self._tools = {}
        # Schema-only construction also needs the four local schemas. The
        # explicit bundle root supplies them when the host omits workdir.
        tools = build_tools(spec, workdir or bundle)
        self._tools = {tool.name(): tool for tool in tools}

    ToolManager.__init__ = initialize
    ToolManager._iris_bootstrap = True
