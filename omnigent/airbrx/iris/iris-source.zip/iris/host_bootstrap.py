"""Opt-in process-local compatibility adapter for the inspected Omnigent build."""

import hashlib
import inspect
from pathlib import Path

# Reviewed for omnigent b30937b4 (0.13.0). `ToolManager.__init__` keeps its
# signature, `shutdown()` and `_tools`, so the adapter's contract holds. The
# substantive change is that it now auto-registers four scheduled-task tools
# and session-rename "without the spec opting in" — write-capable surface the
# spec never asked for. The adapter replaces `_tools` wholesale after calling
# the original, so they do not reach the model; preflight is what proves it,
# and it must keep asserting exactly four tools.
MANAGER_SHA256 = "818c9e66158b276bcbfdcc4cd8fecafb4ab43dfa64ec52f7031b46feedeb984d"


def install(bundle):
    from omnigent.tools.manager import ToolManager
    from omnigent.spec.parser import parse
    from iris.omnigent_runtime import assert_bundle_boundary, build_tools

    if getattr(ToolManager, "_iris_bootstrap", False):
        return
    source = Path(inspect.getfile(ToolManager))
    if hashlib.sha256(source.read_bytes()).hexdigest() != MANAGER_SHA256:
        raise RuntimeError("Unreviewed Omnigent ToolManager revision; rerun compatibility review")
    bundle = Path(bundle).resolve(strict=True)
    selected = parse(bundle)
    if selected.name != "iris":
        raise ValueError("Iris launcher requires a bundle named iris")
    assert_bundle_boundary(selected)
    original = ToolManager.__init__

    def initialize(self, spec, client_tool_specs=None, workdir=None,
                   sandbox_enabled=True, os_env=None):
        if spec.name != "iris":
            return original(self, spec, client_tool_specs, workdir, sandbox_enabled, os_env)
        assert_bundle_boundary(spec)
        if client_tool_specs or os_env is not None:
            raise ValueError("Iris does not accept extra client tools or OS environments")
        original(self, spec, None, workdir, sandbox_enabled, None)
        self.shutdown()
        self._tools = {}
        # Schema-only construction also needs the four local schemas. The
        # explicit bundle root supplies them when the host omits workdir.
        tools = build_tools(spec, workdir or bundle)
        self._tools = {tool.name(): tool for tool in tools}

    ToolManager.__init__ = initialize
    ToolManager._iris_bootstrap = True
