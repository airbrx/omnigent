"""Maintained MCP Streamable HTTP client behind a closed read-only surface."""

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
import httpx
from iris.auth import UpstreamError

ALLOWED = frozenset(
    {
        "list_tenants",
        "get_tenant_rules",
        "get_tenant_config",
        "get_summary",
        "get_rule_effectiveness",
        "get_cache_opportunities",
        "describe_log_schema",
        "query_logs",
        "get_cache_key",
        "list_invalidation_markers",
        "validate_rules",
        "preview_rule_change",
    }
)
REQUIRED = {
    "get_tenant_rules": {"tenantid"},
    "get_summary": {"tenantid", "year", "month", "day"},
    "get_rule_effectiveness": {"tenantid", "year"},
    "get_cache_opportunities": {"tenantid", "year"},
    "describe_log_schema": {"tenantid"},
    "query_logs": {"tenantid", "sql"},
    "validate_rules": {"rules"},
    "preview_rule_change": {"tenantid", "rules"},
}


def import_mcp():
    """Import the MCP SDK, not a module that merely shares its name.

    Omnigent runs a local tool by executing
    ``site-packages/omnigent/tools/_runner.py`` as a script, so Python puts that
    directory at ``sys.path[0]`` for the whole tool subprocess. It contains
    ``mcp.py``, which means a plain ``import mcp`` there resolves to Omnigent's
    helper rather than the SDK; that helper's own ``from mcp import
    ClientSession`` then raises a partially-initialized circular import.

    The effect was live evidence collection failing on its very first upstream
    call while the identical call succeeded from the CLI in the same
    interpreter, reported as an opaque transport error. So resolve the SDK by
    looking past any directory that carries a competing ``mcp`` module, and put
    ``sys.path`` back exactly as it was found.
    """
    import importlib
    import sys
    from pathlib import Path

    existing = sys.modules.get("mcp")
    if existing is not None and hasattr(existing, "ClientSession"):
        return existing

    original_path = list(sys.path)
    shadowed = sys.modules.pop("mcp", None)
    try:
        sys.path[:] = [
            entry
            for entry in original_path
            if not (entry and (Path(entry) / "mcp.py").is_file())
        ]
        module = importlib.import_module("mcp")
        if not hasattr(module, "ClientSession"):
            raise ImportError(
                "resolved an 'mcp' module without ClientSession at "
                f"{getattr(module, '__file__', 'unknown')}; the MCP SDK is shadowed"
            )
        return module
    except Exception:
        if shadowed is not None:
            sys.modules["mcp"] = shadowed
        raise
    finally:
        sys.path[:] = original_path


@dataclass
class Budget:
    max_calls: int = 60
    max_logs: int = 15
    seconds: float = 300
    calls: int = 0
    logs: int = 0
    started: float = field(default_factory=time.monotonic)

    def take(self, name):
        # Time and requests are different budgets and have different remedies.
        # Collapsing them told an operator with 50 of 60 calls unused that the
        # request budget was exhausted, so the limit they would raise is not
        # the one they hit. Name the resource that actually ran out.
        if self.remaining <= 0:
            raise UpstreamError(
                "deadline", "Investigation incomplete: deadline exceeded"
            )
        if self.calls >= self.max_calls or (
            name == "query_logs" and self.logs >= self.max_logs
        ):
            raise UpstreamError(
                "budget", "Investigation incomplete: request budget exhausted"
            )
        self.calls += 1
        self.logs += int(name == "query_logs")

    @property
    def remaining(self):
        return max(0, self.seconds - (time.monotonic() - self.started))


def decode(result):
    if result.isError:
        # Upstream error text may contain tokens/SQL/tenant data; never forward it.
        texts = "\n".join(
            getattr(b, "text", "") for b in getattr(result, "content", [])
        )
        if re.search(r"API request failed: 403\b", texts):
            raise UpstreamError("capability", "Read capability restricted (403)")
        if re.search(r"API request failed: 404\b", texts):
            # A 404 here is the upstream saying it holds no summary for that
            # tenant and day. Reporting it as "tool_error" put it in the same
            # bucket as a 502, so a week with four quiet days and one genuinely
            # broken call read as five failures. Measured on tenant f65d9135
            # for 2026-09-14..21: four 404s, one 502.
            #
            # It is still UNAVAILABLE, never zero. A missing summary is not a
            # day with no traffic -- it is a day we cannot speak for, and
            # folding it in as 0 would put a number where there is no
            # measurement.
            raise UpstreamError(
                "no_summary", "No summary is recorded upstream for this period (404)"
            )
        raise UpstreamError("tool_error", "Upstream MCP tool returned an error")
    if result.structuredContent is not None:
        return result.structuredContent
    blocks = [b.text for b in result.content if b.type == "text"]
    if len(blocks) != 1:
        raise UpstreamError("protocol", "Expected one JSON tool result")
    try:
        return json.loads(blocks[0])
    except (TypeError, ValueError):
        raise UpstreamError("protocol", "Upstream tool result is not JSON") from None


class MCPWire:
    def __init__(self, url, *, http_transport=None):
        self.url = url
        self.http_transport = http_transport

    async def request(self, token, method, arguments):
        ClientSession = import_mcp().ClientSession
        from mcp.client.streamable_http import streamable_http_client

        async with httpx.AsyncClient(
            headers={"Authorization": "Bearer " + token},
            timeout=30,
            follow_redirects=False,
            transport=self.http_transport,
        ) as client:
            async with streamable_http_client(self.url, http_client=client) as (
                read,
                write,
                _,
            ):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    if method == "tools/list":
                        return await session.list_tools(cursor=arguments.get("cursor"))
                    return await session.call_tool(method, arguments)


def http_status(error):
    if isinstance(error, httpx.HTTPStatusError):
        return error.response.status_code
    for child in getattr(error, "exceptions", []):
        status = http_status(child)
        if status:
            return status
    return None


class Adapter:
    def __init__(self, tenant, auth, wire, budget):
        self.tenant, self.auth, self.wire, self.budget = tenant, auth, wire, budget
        self.schemas = {}

    async def _request(self, name, args):
        for attempt in range(2):
            self.budget.take(name)
            try:
                async with asyncio.timeout(self.budget.remaining):
                    token = await self.auth.token(force=bool(attempt))
                    return await self.wire.request(token, name, args)
            except TimeoutError:
                raise UpstreamError(
                    "deadline", "Investigation incomplete: deadline exceeded"
                ) from None
            except Exception as exc:
                status = http_status(exc)
                if status == 401 and attempt == 0:
                    continue
                if status in (401, 403):
                    raise UpstreamError(
                        "authentication" if status == 401 else "capability",
                        "Authentication failed"
                        if status == 401
                        else "Read capability restricted (403)",
                    ) from None
                if isinstance(exc, UpstreamError):
                    raise
                raise UpstreamError(
                    "transport", "MCP request failed; no upstream error content exposed"
                ) from None

    async def discover(self):
        cursor, seen = None, set()
        while True:
            page = await self._request(
                "tools/list", {"cursor": cursor} if cursor else {}
            )
            for tool in page.tools:
                if tool.name in self.schemas:
                    raise UpstreamError("schema", "Duplicate upstream tool")
                if tool.name in ALLOWED:
                    self.schemas[tool.name] = tool.inputSchema
            cursor = page.nextCursor
            if not cursor:
                break
            if cursor in seen:
                raise UpstreamError("pagination", "Repeated inventory cursor")
            seen.add(cursor)
        for name, keys in REQUIRED.items():
            schema = self.schemas.get(name, {})
            if not keys <= schema.get("properties", {}).keys():
                raise UpstreamError(
                    "schema", "Missing/incompatible upstream tool: " + name
                )
            for key in keys:
                expected = "object" if key == "rules" else "string"
                if schema["properties"][key].get("type") != expected:
                    raise UpstreamError(
                        "schema", "Changed upstream argument type: " + name
                    )

    async def call(self, name, **args):
        if name not in ALLOWED:
            raise UpstreamError("forbidden", "Tool is outside Iris read-only allowlist")
        if "tenantid" in args and args["tenantid"] != self.tenant:
            raise UpstreamError("tenant", "Cross-tenant access rejected")
        if name not in ("list_tenants", "validate_rules"):
            args["tenantid"] = self.tenant
        if "rules" in args and args["rules"].get("tenantId") != self.tenant:
            raise UpstreamError(
                "tenant", "Candidate tenant does not match selected tenant"
            )
        schema = self.schemas.get(name)
        if schema is None:
            raise UpstreamError("schema", "Tool unavailable before validated discovery")
        if (
            set(args) - schema.get("properties", {}).keys()
            or not set(schema.get("required", [])) <= args.keys()
        ):
            raise UpstreamError(
                "schema", "Arguments do not match discovered tool schema"
            )
        from jsonschema import Draft202012Validator

        if next(Draft202012Validator(schema).iter_errors(args), None) is not None:
            raise UpstreamError("schema", "Arguments fail discovered JSON schema")
        result = decode(await self._request(name, args))
        try:
            encoded = json.dumps(result, allow_nan=False)
        except (TypeError, ValueError):
            raise UpstreamError("protocol", "Evidence is not finite JSON") from None
        if len(encoded) > 2_000_000:
            raise UpstreamError("size", "Evidence exceeds bounded response size")
        if name == "get_tenant_rules" and (
            not isinstance(result, dict) or result.get("tenantId") != self.tenant
        ):
            raise UpstreamError("tenant", "Returned rules do not match selected tenant")
        if name != "list_tenants" and isinstance(result, dict):
            for key in ("tenantId", "tenantid", "tenant_id"):
                if key in result and result[key] != self.tenant:
                    raise UpstreamError(
                        "tenant", "Returned evidence does not match selected tenant"
                    )
        if name == "get_cache_key":
            if not isinstance(result, dict):
                raise UpstreamError("shape", "Cache metadata is not an object")
            return {
                key: result[key]
                for key in (
                    "version",
                    "cacheKey",
                    "createdAt",
                    "expiresAt",
                    "lastAccessed",
                    "hitCount",
                    "size",
                )
                if key in result
            }
        if name == "get_tenant_config":
            return {
                k: result[k]
                for k in ("tenantId", "adapter")
                if k in result and isinstance(result[k], str)
            }
        if name == "list_tenants":
            rows = result if isinstance(result, list) else result.get("tenants", [])
            return [
                {"tenantId": self.tenant}
                for row in rows
                if row.get("tenantId", row.get("tenantid")) == self.tenant
            ]
        return result
