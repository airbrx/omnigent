"""Parent-side integration for a host with an explicit tool-manager factory.

Stock 0.6.0.dev0 has no bundle-level factory hook: its preflight fails. The
opt-in Iris host bootstrap installs this factory only in its process tree.
This uses Omnigent lifecycle/SDK; it does not create a second agent loop.
"""

import json
from pathlib import Path
from iris.config import Config
from iris.policy import IRIS_TOOLS


def assert_bundle_boundary(spec):
    expected_skills = {"iris-overview", "iris-audit", "airbrx-rule-author"}
    if (
        spec.executor.type != "claude_sdk"
        or spec.os_env is not None
        or spec.mcp_servers
        or spec.sub_agents
        or spec.tools.builtins
        or spec.async_enabled
        or spec.spawn
        or spec.timers
        or spec.skills_filter != "none"
        or {skill.name for skill in spec.skills} != expected_skills
    ):
        raise ValueError("Bundle violates the Iris native executor/tool/skill boundary")


def build_tools(spec, workdir):
    assert_bundle_boundary(spec)
    from omnigent.tools.local import load_local_python_tools
    from omnigent.tools.base import Tool

    class DeliveredIrisTool(Tool):
        def __init__(self, wrapped):
            self.wrapped = wrapped

        def name(self):
            return self.wrapped.name()

        @classmethod
        def description(cls):
            return "Bounded Iris domain operation with session-owned artifacts."

        def get_schema(self):
            return self.wrapped.get_schema()

        def cancel(self):
            self.wrapped.cancel()

        def shutdown(self):
            self.wrapped.shutdown()

        def invoke(self, arguments, ctx):
            # Use Omnigent's stdout runner protocol, drained concurrently by
            # communicate(). The stock plain fd pipe is read only after exit
            # and can deadlock on larger reports before reaching its 1 MiB cap.
            state_root = None
            if ctx.workspace is not None:
                state = ctx.workspace / ".tool_state" / ctx.agent_id
                state.mkdir(parents=True, exist_ok=True)
                state_root = str(state)
            request = json.dumps(
                {
                    "module_path": self.wrapped.module_path(),
                    "tool_name": self.name(),
                    "arguments": json.loads(arguments or "{}"),
                    "state_root": state_root,
                }
            ).encode()
            command = self.wrapped._build_command(state_root=state_root)
            raw = self.wrapped._invoke_stdout(command, request, workspace=ctx.workspace)
            try:
                result = json.loads(raw)
            except ValueError:
                return json.dumps(
                    {
                        "error": "Iris tool subprocess failed; inspect host diagnostics",
                        "incomplete": True,
                    }
                )
            if (
                isinstance(result, dict)
                and result.get("artifacts")
                and ctx.conversation_id
            ):
                from omnigent.runtime import get_artifact_store, get_file_store

                if get_artifact_store() is not None and get_file_store() is not None:
                    result["downloads"] = deliver(
                        result["artifacts"], ctx.conversation_id, Config.from_env()
                    )
                    result["artifact_delivery"] = "session-scoped file resources"
                    del result["artifacts"]
            return json.dumps(result)

    tools = load_local_python_tools(spec.local_tools, Path(workdir))
    if {t.name() for t in tools} != IRIS_TOOLS:
        raise RuntimeError(
            "Host tool registry must contain exactly four Iris functions"
        )
    return [DeliveredIrisTool(t) for t in tools]


def deliver(artifacts, session_id, config):
    """Upload only known files from a tenant-bound Iris manifest; no model path input."""
    import hashlib
    from omnigent.tools.builtins.upload_file import _upload

    root = (
        config.output_dir.resolve()
        / hashlib.sha256(config.tenant_id.encode()).hexdigest()
    )
    downloads = []
    for name, value in artifacts.items():
        path = Path(value)
        if (
            name not in {"report.json", "report.md", "proposal.json"}
            or path.name != name
        ):
            raise ValueError("Unexpected Iris artifact")
        if (
            path.is_symlink()
            or path.parent.is_symlink()
            or not path.resolve().is_relative_to(root)
        ):
            raise ValueError("Artifact is outside selected tenant")
        manifest = json.loads((path.parent / "manifest.json").read_text())
        if (
            manifest.get("owner") != "iris-v1"
            or manifest.get("tenantId") != config.tenant_id
            or name not in manifest.get("files", [])
        ):
            raise ValueError("Artifact manifest does not authorize delivery")
        uploaded = json.loads(_upload(path, session_id=session_id))
        if not uploaded.get("file_id"):
            raise RuntimeError("Host did not return an artifact resource")
        downloads.append(uploaded)
    return downloads
