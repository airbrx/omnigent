"""Build a publishable Iris bundle, and refuse to pretend it will run.

Packaging for Omnigent is two questions, and only one of them is about files.

**Will this host run it?** On the build inspected during development the answer
was no, for a reason no amount of packaging fixes: the spec validator accepts
`executor.type: claude_sdk` while the runner's harness registry only registers
`claude-sdk`, so a bundle that passes validation still dies at spawn with
`unknown harness`. `host_report()` reads both lists out of the installed
Omnigent and says whether they actually intersect for this bundle's executor.
That check is the point of this module — a green "bundle built" line while the
host cannot spawn it is exactly the false confidence the build plan warns about.

**Are the files right?** `build_bundle()` renders non-secret host settings into
a copy, folds the bundled skills into the agent instructions, then *parses what
it produced* and asserts the tool surface is exactly the four read-only Iris
functions. It writes a manifest with a SHA-256 per file so what was published
can be identified later.

Nothing here deploys, uploads, or authenticates. It produces a directory and,
optionally, a tarball for a human to publish.

    python -m iris.packaging --check
    python -m iris.packaging --build dist/iris-bundle --tar
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tarfile
from dataclasses import dataclass, field
from pathlib import Path

__all__ = [
    "EXPECTED_TOOLS",
    "HostReport",
    "host_report",
    "render_settings",
    "manifest_for",
    "build_bundle",
    "main",
]

EXPECTED_TOOLS = ("iris_audit", "iris_investigate", "iris_overview", "iris_propose")

# Both spellings denote the same native executor; which one a given Omnigent
# build accepts is exactly what host_report() is for.
SDK_EXECUTOR_ALIASES = ("claude_sdk", "claude-sdk")


@dataclass
class RemoteHost:
    """What the deployment target reports about itself.

    The local install is a stand-in for the host and not the same thing: the
    machine this was built on ran 0.6.0.dev0 while omnigent.airbrx.ai ran
    0.11.0.dev0, a different line entirely. A local green light says the bundle
    would spawn *here*.
    """

    url: str
    reachable: bool = False
    healthy: bool = False
    version: str | None = None
    commit: str | None = None
    problems: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "reachable": self.reachable,
            "healthy": self.healthy,
            "version": self.version,
            "commit": self.commit,
            "problems": list(self.problems),
            "executor_compatibility": "unverified",
        }


def _loads_object(body):
    """Parse a JSON object, or None for anything else. Never raises."""
    import json as _json

    try:
        payload = _json.loads(body)
    except (ValueError, TypeError):
        return None
    return payload if isinstance(payload, dict) else None


def _as_text(value):
    """A string field, or None. A number is not a version and not a commit."""
    return value if isinstance(value, str) and value.strip() else None


def probe_remote(url, timeout=15):
    """Ask a deployed Omnigent what it is. Read-only, unauthenticated."""
    import urllib.error
    import urllib.request

    report = RemoteHost(url=url.rstrip("/"))

    def get(path):
        request = urllib.request.Request(
            report.url + path, headers={"Accept": "application/json"}
        )
        try:
            response = urllib.request.urlopen(request, timeout=timeout)
        except urllib.error.HTTPError as response_error:
            # An HTTP error proves the server answered; it is not a network failure.
            with response_error:
                return response_error.code, response_error.read(4096)
        with response as opened:
            return opened.status, opened.read(4096)

    try:
        status, body = get("/health")
        report.reachable = True
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        report.problems.append(f"unreachable: {type(exc).__name__}")
        return report

    # Structural, not substring. `b'"ok"' in body` passed on any payload that
    # merely contained those bytes — a degraded response naming an "ok" field,
    # or a message quoting the word — so a sick host could read as healthy.
    if status != 200:
        report.problems.append(f"/health returned {status}")
    else:
        payload = _loads_object(body)
        if payload is None:
            report.problems.append("/health did not return a JSON object")
        elif payload.get("status") != "ok":
            report.problems.append(f"/health status is {payload.get('status')!r}, not 'ok'")
        else:
            report.healthy = True

    try:
        status, body = get("/api/version")
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        report.problems.append(f"version unavailable: {type(exc).__name__}")
        return report

    if status != 200:
        report.problems.append(f"/api/version returned {status}")
        return report
    payload = _loads_object(body)
    if payload is None:
        # A list or a bare null used to reach .get and raise AttributeError,
        # which this function does not catch — a probe that crashes instead of
        # reporting is worse than one that reports nothing.
        report.problems.append("/api/version did not return a JSON object")
        return report
    report.version = _as_text(payload.get("version"))
    report.commit = _as_text(payload.get("commit"))
    if report.version is None:
        report.problems.append("/api/version has no string version field")
    return report


@dataclass
class HostReport:
    omnigent_version: str | None = None
    validator_types: tuple[str, ...] = ()
    harness_names: tuple[str, ...] = ()
    executor_type: str | None = None
    validator_accepts: bool = False
    harness_resolves: bool = False
    problems: list[str] = field(default_factory=list)

    @property
    def can_run(self) -> bool:
        return self.validator_accepts and self.harness_resolves and not self.problems

    def to_dict(self) -> dict:
        return {
            "omnigent_version": self.omnigent_version,
            "executor_type": self.executor_type,
            "validator_accepts": self.validator_accepts,
            "harness_resolves": self.harness_resolves,
            "can_run": self.can_run,
            "validator_types": list(self.validator_types),
            "harness_names": list(self.harness_names),
            "problems": list(self.problems),
        }


def _installed_version() -> str | None:
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version("omnigent")
    except PackageNotFoundError:
        return None


def _validator_types() -> tuple[str, ...]:
    """Executor types the spec validator will accept."""
    import re
    from inspect import getsource

    from omnigent.spec import validator

    block = re.search(r"\{([^{}]*?agents_sdk[^{}]*?)\}", getsource(validator), re.S)
    if not block:
        return ()
    return tuple(sorted(set(re.findall(r'"([A-Za-z0-9_.-]+)"', block.group(1)))))


def _harness_names() -> tuple[str, ...]:
    """Harness ids the runner can actually spawn."""
    from omnigent.runtime.harnesses import process_manager

    registry = getattr(process_manager, "_HARNESS_MODULES", None)
    return tuple(sorted(registry)) if registry else ()


def host_report(executor_type: str) -> HostReport:
    """Report whether the installed Omnigent both accepts and can spawn this executor."""
    report = HostReport(executor_type=executor_type)
    try:
        report.omnigent_version = _installed_version()
        report.validator_types = _validator_types()
        report.harness_names = _harness_names()
    except Exception as exc:  # noqa: BLE001 - an uninspectable host is a reportable state
        report.problems.append(f"could not inspect the installed Omnigent: {type(exc).__name__}")
        return report

    if not report.validator_types:
        report.problems.append("could not read the validator's executor list; treating as unknown")
    if not report.harness_names:
        report.problems.append("the runner harness registry is empty or unreadable")

    report.validator_accepts = executor_type in report.validator_types
    report.harness_resolves = executor_type in report.harness_names

    if report.validator_types and report.harness_names and not report.can_run:
        shared = [a for a in SDK_EXECUTOR_ALIASES
                  if a in report.validator_types and a in report.harness_names]
        if shared:
            report.problems.append(
                f"executor.type {executor_type!r} is not the spelling this host runs; "
                f"use {shared[0]!r}, which both the validator and the runner accept"
            )
        elif not report.validator_accepts and not report.harness_resolves:
            report.problems.append(
                f"neither the validator {list(report.validator_types)} nor the runner "
                f"{list(report.harness_names)[:6]}… recognises {executor_type!r}"
            )
        else:
            report.problems.append(
                f"the validator accepts {[a for a in SDK_EXECUTOR_ALIASES if a in report.validator_types]} "
                f"but the runner registers {[a for a in SDK_EXECUTOR_ALIASES if a in report.harness_names]}; "
                "no value satisfies both, so this host cannot spawn the bundle"
            )
    return report


def render_settings(text: str, settings: dict) -> str:
    """Rewrite `key: value` lines by key, at whatever indent they already sit.

    Deliberately not a whole-line literal replace: matching `model:
    claude-sonnet-4-6` means the substitution silently stops happening the day
    the default changes, with nothing reported. Keys are matched instead, and a
    key that never appears is an error rather than a no-op.
    """
    lines = text.split("\n")
    seen = {key: 0 for key in settings}
    for index, line in enumerate(lines):
        stripped = line.lstrip()
        for key, value in settings.items():
            prefix = f"{key}:"
            if stripped.startswith(prefix):
                indent = line[: len(line) - len(stripped)]
                # JSON scalars are valid YAML and avoid interpolating raw strings.
                lines[index] = f"{indent}{key}: {json.dumps(value)}"
                seen[key] += 1
                break
    missing = sorted(k for k, n in seen.items() if n == 0)
    if missing:
        raise ValueError(f"settings keys not present in the config: {missing}")
    return "\n".join(lines)


def manifest_for(root: Path) -> dict:
    """SHA-256 per file, so a published bundle can be identified afterwards."""
    files = {}
    for path in sorted(root.rglob("*")):
        if path.is_dir() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        files[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {"schemaVersion": 1, "files": files}


def _fold_skills(bundle: Path) -> None:
    """Skills are prompt material; fold them into the instructions the host reads."""
    agents = bundle / "AGENTS.md"
    text = agents.read_text()
    for skill in sorted(bundle.glob("skills/*/SKILL.md")):
        body = skill.read_text().split("---", 2)[-1].strip()
        text += "\n\n" + body
    agents.write_text(text)


def build_bundle(source: Path, output: Path, *, settings: dict, tar: bool = False, remote=None) -> dict:
    """Render a publishable copy of the bundle and verify what was produced."""
    source, output = Path(source).resolve(strict=True), Path(output)
    if output.exists():
        raise SystemExit(f"{output} exists; choose a new directory so nothing is overwritten")
    shutil.copytree(source, output, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    config = output / "config.yaml"
    config.write_text(render_settings(config.read_text(), settings))
    _fold_skills(output)

    # Verify the artifact, not the inputs: parse what was written and confirm
    # the executable surface is exactly the four read-only tools.
    from omnigent.spec.parser import parse
    from omnigent.tools.local import load_local_python_tools

    spec = parse(output)
    tools = tuple(sorted(t.name() for t in load_local_python_tools(
        spec.local_tools, output, srt_available=False)))
    if tools != EXPECTED_TOOLS:
        raise SystemExit(f"bundle exposes {list(tools)}, expected {list(EXPECTED_TOOLS)}")

    manifest = manifest_for(output)
    manifest["name"] = spec.name
    manifest["executor_type"] = spec.executor.type
    manifest["model"] = settings.get("model")
    manifest["tools"] = list(tools)
    manifest["host"] = host_report(spec.executor.type).to_dict()
    if remote is not None:
        manifest["remote_host"] = remote.to_dict()
    (output / "bundle-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    if tar:
        archive = output.with_suffix(".tar.gz")
        with tarfile.open(archive, "w:gz") as handle:
            handle.add(output, arcname=output.name)
        manifest["archive"] = str(archive)
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build a publishable Iris bundle.")
    parser.add_argument("--source", type=Path, default=Path.cwd() / "omnigent")
    parser.add_argument("--build", type=Path, default=None, metavar="DIR")
    parser.add_argument("--tar", action="store_true", help="also write DIR.tar.gz")
    parser.add_argument("--check", action="store_true", help="host compatibility only")
    parser.add_argument("--json", action="store_true")
    parser.add_argument(
        "--remote",
        default=os.environ.get("OMNIGENT_HOST_URL"),
        help="also report what the deployment target says about itself",
    )
    args = parser.parse_args(argv)

    from omnigent.spec.parser import parse

    spec = parse(Path(args.source).resolve(strict=True))
    report = host_report(spec.executor.type)

    remote = probe_remote(args.remote) if args.remote else None

    if args.check or not args.build:
        if args.json:
            payload = report.to_dict()
            if remote is not None:
                payload["remote_host"] = remote.to_dict()
            print(json.dumps(payload, indent=2))
        else:
            print(_human(report, remote))
        return 0 if report.can_run else 1

    from iris.config import Config

    config = Config.from_env()
    manifest = build_bundle(
        args.source,
        args.build,
        settings={
            "model": config.model,
            "timeout": config.deadline_seconds,
            "max_iterations": config.max_turns,
            "max_turns": config.max_turns,
        },
        tar=args.tar,
        remote=remote,
    )
    if args.json:
        print(json.dumps(manifest, indent=2))
    else:
        print(f"Built {args.build} — {len(manifest['files'])} files, tools {manifest['tools']}")
        if manifest.get("archive"):
            print(f"Archive {manifest['archive']}")
        print()
        print(_human(report, remote))
    return 0 if report.can_run else 1


def _human(report: HostReport, remote=None) -> str:
    lines = [
        f"Omnigent {report.omnigent_version or 'unknown'}",
        f"  executor.type      {report.executor_type}",
        f"  validator accepts  {report.validator_accepts}  {list(report.validator_types) or '(unreadable)'}",
        f"  runner can spawn   {report.harness_resolves}",
    ]
    if report.can_run:
        lines.append("  -> this host can run the bundle")
    else:
        lines.append("  -> this host CANNOT run the bundle:")
        lines += [f"     {p}" for p in report.problems]
        lines.append("     Packaging succeeded; hosting is not proven. Do not publish on this.")
    if remote is not None:
        lines += [
            "",
            f"Deployment target {remote.url}",
            "  executor compatibility unverified; health/version do not prove session execution",
            f"  reachable          {remote.reachable}   healthy {remote.healthy}",
            f"  reports version    {remote.version or 'unknown'}"
            + (f"  commit {remote.commit[:12]}" if isinstance(remote.commit, str) else ""),
        ]
        if remote.version and remote.version != report.omnigent_version:
            lines.append(
                f"  -> the target runs {remote.version} and this check inspected "
                f"{report.omnigent_version}. The verdict above describes THIS machine. "
                "Re-run where the bundle will actually be hosted, or treat the target as unverified."
            )
        for problem in remote.problems:
            lines.append(f"     {problem}")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
