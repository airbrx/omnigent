"""Operator-side tenant discovery: which tenant id do I bind?

`IRIS_TENANT_ID` must be an explicit, host-authorized tenant, and Iris refuses
to fall back to "the first accessible one". That is the right runtime rule and
it leaves an operator with a question nothing else in the product answers:
*which id?* The adapter's own `list_tenants` cannot answer it — it filters the
manifest down to the tenant already bound, which is correct as a model-facing
isolation control and useless for choosing what to bind in the first place.

The answer matters because the two identifiers look nothing alike and one of
them fails quietly. A tenant is a **UUID**; its gateway hostname is a separate
`primaryFqdn` field. Putting the gateway FQDN in `IRIS_TENANT_ID` passes config
validation and then returns `403 capability` on every read — a configuration
mistake that reads like a permissions problem.

This module is read-only: `list_tenants` and `get_tenant_config`, nothing else.
It prints identity only, never credentials, and is meant to be run by a person
setting up a host — not reachable by the model.

    python -m iris.tenants
    python -m iris.tenants --fqdn wise-salmon-tangent.gateway.airbrx.ai
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from dataclasses import dataclass

__all__ = ["TenantRow", "discover", "lookup", "render", "main"]

# Upstream error *codes* are a closed vocabulary this project defines, so they
# are safe to show. Exception *messages* are not: they can quote a bearer token,
# a URL with embedded credentials, or tenant SQL. Notes are rendered to a
# terminal and may be pasted into a ticket, so only the category travels.
_SAFE_ERROR_CODES = frozenset(
    {
        "authentication",
        "capability",
        "transport",
        "schema",
        "protocol",
        "pagination",
        "budget",
        "deadline",
        "tenant",
        "forbidden",
        "size",
        "shape",
    }
)


def _error_category(exc: BaseException) -> str:
    code = getattr(exc, "code", None)
    return code if isinstance(code, str) and code in _SAFE_ERROR_CODES else "unavailable"


@dataclass(frozen=True)
class TenantRow:
    tenant_id: str
    name: str | None = None
    primary_fqdn: str | None = None
    adapter: str | None = None
    status: str | None = None
    note: str | None = None


def _rows_of(manifest: object) -> list[dict]:
    if isinstance(manifest, list):
        return manifest
    if isinstance(manifest, dict):
        rows = manifest.get("tenants")
        if isinstance(rows, list):
            return rows
    raise ValueError(f"list_tenants returned {type(manifest).__name__}, expected a list of tenants")


async def discover(call, *, with_config: bool = True) -> list[TenantRow]:
    """List tenants visible to the caller's credential.

    `call(name, args)` is the upstream tool seam, so this is testable offline and
    holds no transport of its own. A tenant whose config cannot be read is still
    listed, with the reason attached: a tenant you cannot describe is different
    from a tenant that does not exist, and hiding it would misreport the account.
    """
    rows: list[TenantRow] = []
    for raw in _rows_of(await call("list_tenants", {})):
        if not isinstance(raw, dict):
            raise ValueError(f"tenant entry is {type(raw).__name__}, expected an object")
        tenant_id = raw.get("tenantId") or raw.get("tenantid")
        if not isinstance(tenant_id, str) or not tenant_id.strip():
            raise ValueError(f"tenant entry has no usable id: {sorted(raw)}")
        name = raw.get("tenantName") or raw.get("name")

        if not with_config:
            rows.append(TenantRow(tenant_id=tenant_id, name=name))
            continue

        try:
            config = await call("get_tenant_config", {"tenantid": tenant_id})
        except Exception as exc:  # noqa: BLE001 - category only; see _error_category
            rows.append(
                TenantRow(
                    tenant_id=tenant_id,
                    name=name,
                    note=f"config unavailable ({_error_category(exc)})",
                )
            )
            continue

        adapter = config.get("dataAdapter") if isinstance(config, dict) else None
        rows.append(
            TenantRow(
                tenant_id=tenant_id,
                name=name,
                primary_fqdn=config.get("primaryFqdn") if isinstance(config, dict) else None,
                adapter=adapter.get("type") if isinstance(adapter, dict) else None,
                status=config.get("status") if isinstance(config, dict) else None,
            )
        )
    return rows


def _row_from_config(config: dict, fallback_id: str) -> TenantRow:
    adapter = config.get("dataAdapter") if isinstance(config, dict) else None
    return TenantRow(
        tenant_id=config.get("tenantId") or fallback_id,
        name=config.get("tenantName"),
        primary_fqdn=config.get("primaryFqdn"),
        adapter=adapter.get("type") if isinstance(adapter, dict) else None,
        status=config.get("status"),
    )


async def lookup(call, identifier: str) -> TenantRow | None:
    """Read one tenant directly, bypassing the manifest.

    `list_tenants` is manifest discovery and can list fewer tenants than a
    credential actually reaches, so absence from that list is not proof of no
    access. This asks upstream about one identifier and reports what came back,
    including the canonical id, which may differ from what was passed in.

    Returns None when the tenant cannot be read — unreachable and nonexistent
    are indistinguishable from here, and neither is reported as the other.
    """
    if not isinstance(identifier, str) or not identifier.strip():
        raise ValueError("lookup needs a non-empty tenant identifier")
    try:
        config = await call("get_tenant_config", {"tenantid": identifier.strip()})
    except Exception:  # noqa: BLE001 - the distinction we can draw is reachable / not
        return None
    if not isinstance(config, dict):
        return None
    return _row_from_config(config, identifier.strip())


def render(rows: list[TenantRow], *, fqdn: str | None = None) -> str:
    """A human-readable listing. Identity only; nothing here is secret."""
    if fqdn:
        rows = [r for r in rows if r.primary_fqdn and r.primary_fqdn.lower() == fqdn.lower()]
        if not rows:
            return (
                f"No tenant on this credential has primaryFqdn {fqdn!r}.\n"
                "Either the gateway belongs to another account, or this PAT cannot see it."
            )

    if not rows:
        return "This credential can see no tenants."

    lines = [f"{len(rows)} tenant(s) visible to this credential:", ""]
    for row in rows:
        lines.append(f"  IRIS_TENANT_ID={row.tenant_id}")
        lines.append(f"    name       : {row.name or '(unnamed)'}")
        lines.append(f"    primaryFqdn: {row.primary_fqdn or '(unknown)'}")
        lines.append(f"    adapter    : {row.adapter or '(unknown)'}    status: {row.status or '(unknown)'}")
        if row.note:
            lines.append(f"    note       : {row.note}")
        lines.append("")
    lines.append("Bind exactly one. The id above is the UUID — the gateway hostname is")
    lines.append("primaryFqdn and is not accepted upstream as a tenant id.")
    return "\n".join(lines)


async def _live_call_factory():
    """Bind the real transport. Imported lazily so tests need no network stack."""
    from iris.auth import Auth
    from iris.mcp_client import MCPWire, decode

    api = os.environ.get("AIRBRX_API_BASE_URL", "https://api.airbrx.ai").rstrip("/")
    mcp = os.environ.get("AIRBRX_MCP_URL", "https://mcp.airbrx.ai/mcp")
    pat = os.environ.get("AIRBRX_PAT", "")
    if not pat:
        raise SystemExit("AIRBRX_PAT is not set; discovery needs an authorized PAT.")

    token = await Auth(api, pat).token()
    wire = MCPWire(mcp)

    async def call(name, args):
        return decode(await wire.request(token, name, args))

    return call


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="List Airbrx tenants visible to AIRBRX_PAT, read-only."
    )
    parser.add_argument("--fqdn", default=None, help="show only the tenant with this primaryFqdn")
    parser.add_argument(
        "--lookup",
        default=None,
        metavar="ID_OR_FQDN",
        help="read one tenant directly by identifier, skipping manifest discovery",
    )
    parser.add_argument(
        "--no-config",
        action="store_true",
        help="skip get_tenant_config (ids and names only, one upstream call)",
    )
    args = parser.parse_args(argv)

    async def run():
        call = await _live_call_factory()
        if args.lookup:
            row = await lookup(call, args.lookup)
            return [row] if row else []
        return await discover(call, with_config=not args.no_config)

    rows = asyncio.run(run())
    if args.lookup and not rows:
        print(f"No tenant readable at identifier {args.lookup!r} with this credential.")
        return 1
    print(render(rows, fqdn=args.fqdn))
    return 0


if __name__ == "__main__":
    sys.exit(main())
