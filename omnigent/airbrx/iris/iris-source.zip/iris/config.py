"""Validated host configuration. Secrets never enter model-facing settings."""

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlsplit
import os
import re


@dataclass(frozen=True)
class Config:
    tenant_id: str
    model: str = "claude-sonnet-4-6"
    api_url: str = "https://api.airbrx.ai"
    mcp_url: str = "https://mcp.airbrx.ai/mcp"
    output_dir: Path = Path("./iris-output")
    max_calls: int = 60
    max_log_queries: int = 15
    max_turns: int = 20
    deadline_seconds: int = 300
    fixture: bool = False

    def __post_init__(self):
        if (
            not self.tenant_id
            or len(self.tenant_id) > 200
            or any(ord(c) < 32 for c in self.tenant_id)
        ):
            raise ValueError("Explicit IRIS_TENANT_ID required")
        if not isinstance(self.model, str) or not re.fullmatch(
            r"[A-Za-z0-9_.:/-]+", self.model
        ):
            raise ValueError("IRIS_MODEL must be a nonempty model identifier")
        for value in (
            self.max_calls,
            self.max_log_queries,
            self.max_turns,
            self.deadline_seconds,
        ):
            if type(value) is not int or value <= 0:
                raise ValueError("Budgets must be positive integers")
        for url in (self.api_url, self.mcp_url):
            u = urlsplit(url)
            if (
                u.scheme != "https"
                or not u.hostname
                or u.username
                or u.password
                or u.query
                or u.fragment
            ):
                raise ValueError(
                    "Endpoints must be HTTPS without credentials, query or fragment"
                )
        # Fail closed on environment pairing; custom hosts require an explicit code-reviewed mapping.
        pairs = {("https://api.airbrx.ai", "https://mcp.airbrx.ai/mcp")}
        if (self.api_url, self.mcp_url) not in pairs:
            raise ValueError("Unrecognized or mixed API/MCP environment pair")

    @classmethod
    def from_env(cls):
        return cls(
            tenant_id=os.environ.get("IRIS_TENANT_ID", ""),
            model=os.environ.get("IRIS_MODEL", "claude-sonnet-4-6"),
            api_url=os.environ.get(
                "AIRBRX_API_BASE_URL", "https://api.airbrx.ai"
            ).rstrip("/"),
            mcp_url=os.environ.get("AIRBRX_MCP_URL", "https://mcp.airbrx.ai/mcp"),
            output_dir=Path(os.environ.get("IRIS_OUTPUT_DIR", "./iris-output")),
            max_calls=int(os.environ.get("IRIS_MAX_CALLS", "60")),
            max_log_queries=int(os.environ.get("IRIS_MAX_LOG_QUERIES", "15")),
            max_turns=int(os.environ.get("IRIS_MAX_TURNS", "20")),
            deadline_seconds=int(os.environ.get("IRIS_DEADLINE_SECONDS", "300")),
            fixture=os.environ.get("IRIS_FIXTURE", "0") == "1",
        )


def period(start=None, end=None, *, today=None):
    today = today or datetime.now(timezone.utc).date()
    if (start is None) != (end is None):
        raise ValueError("Provide both start_date and end_date")
    if start is not None and any(
        not re.fullmatch(r"\d{4}-\d{2}-\d{2}", x) for x in (start, end)
    ):
        raise ValueError("Dates must be YYYY-MM-DD")
    a, b = (
        (today - timedelta(days=7), today)
        if start is None
        else (date.fromisoformat(start), date.fromisoformat(end))
    )
    if a >= b or b > today or (b - a).days > 31:
        raise ValueError("Period must contain 1–31 completed UTC days, end exclusive")
    return a, b
