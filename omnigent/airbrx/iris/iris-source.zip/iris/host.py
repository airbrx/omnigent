"""Omnigent subprocess bridge. Host-injected state owns identity and budgets."""

import asyncio
import fcntl
import json
import os
from pathlib import Path
import time
from iris.artifacts import atomic, sanitize
from iris.auth import UpstreamError
from iris.config import Config
from iris.mcp_client import Budget


class PersistentBudget(Budget):
    def __init__(self, config, path):
        super().__init__(
            config.max_calls, config.max_log_queries, config.deadline_seconds
        )
        self.path = path
        if path.exists():
            stored = json.loads(path.read_text())
            if stored["tenant_id"] != config.tenant_id:
                raise ValueError(
                    "Host tenant changed inside a conversation; start a new conversation"
                )
            self.calls, self.logs = stored["calls"], stored["logs"]
            self.started_epoch = stored["started_epoch"]
        else:
            self.started_epoch = time.time()
        self.tenant = config.tenant_id
        self.started = time.monotonic() - max(0, time.time() - self.started_epoch)

    def take(self, name):
        super().take(name)
        # Persist BEFORE I/O so cancellation/restart cannot refund consumed budget.
        atomic(
            self.path,
            json.dumps(
                {
                    "schemaVersion": 1,
                    "tenant_id": self.tenant,
                    "started_epoch": self.started_epoch,
                    "calls": self.calls,
                    "logs": self.logs,
                }
            ),
        )


def invoke(tool_state, workflow, **kwargs):
    from iris.tools import Iris

    config = Config.from_env()
    # Omnigent 0.6.0.dev0 injects a ToolState with this inspected root.
    # Pin/check that contract; never accept a root, tenant, or state from model input.
    root = Path(tool_state._root)
    if any(p.is_symlink() for p in [root, *root.parents]):
        raise ValueError("Host state root cannot contain symlinks")
    root.mkdir(parents=True, mode=0o700, exist_ok=True)
    os.chmod(root, 0o700)
    lock = os.open(root / "iris.lock", os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state_path = root / "iris-state.json"
        state = json.loads(state_path.read_text()) if state_path.exists() else {}
        if state and state["tenant_id"] != config.tenant_id:
            raise ValueError("Host tenant changed inside this conversation")
        budget = PersistentBudget(config, root / "iris-budget.json")

        async def run():
            iris = Iris(
                config,
                findings=state.get("findings", {}),
                evidence=state.get("evidence", []),
            )
            iris.adapter.budget = budget
            try:
                await iris.start()
                result = await getattr(iris, workflow)(**kwargs)
            except UpstreamError as exc:
                result = iris.finish(str(exc), error_code=exc.code, incomplete=True)
            atomic(
                state_path,
                json.dumps(
                    {
                        "schemaVersion": 1,
                        "tenant_id": config.tenant_id,
                        "findings": {
                            key: sanitize(value) for key, value in iris.findings.items()
                        },
                        "evidence": [e.to_dict() for e in iris.collector.evidence],
                        "updated_at": time.time(),
                    }
                ),
            )
            return result

        return asyncio.run(run())
    finally:
        os.close(lock)
