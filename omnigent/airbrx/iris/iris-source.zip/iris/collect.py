"""Summary-first evidence collection and finite, schema-checked query templates."""

from datetime import timedelta
import re
import json
import math
import uuid
from iris.artifacts import now, sanitize
from iris.auth import UpstreamError
from iris.domain.models import Evidence
from iris.domain.metrics import summarize_counts


class Collector:
    def __init__(self, adapter):
        self.adapter = adapter
        self.evidence = []

    async def fetch(self, name, start, end, **arguments):
        limitations = []
        if name in ("get_rule_effectiveness", "get_cache_opportunities"):
            # The annual payload carries cacheHits / cacheMisses / totalQueries —
            # field names identical to the period metrics. A passive "annual
            # context" note was not enough: the model read those counts as the
            # answer and reported a denominator of 2 against a period of 44.
            # Name the authoritative field instead of hinting at it.
            limitations.append(
                "Annual year-to-date scope, not the requested period. These counts are NOT the "
                "period denominator; the period hit rate and its denominator are in "
                "metrics.hit_rate_denominator. Cite this source only as year-to-date context, "
                "and say so when you do."
            )
        try:
            raw = await self.adapter.call(name, **arguments)
            if not isinstance(raw, dict):
                raise UpstreamError("shape", "Expected a structured evidence object")
            status = (
                "partial"
                if isinstance(raw, dict) and raw.get("truncated")
                else "complete"
            )
            if status == "partial":
                limitations.append("Upstream row cap reached; result is incomplete")
        except UpstreamError as exc:
            raw, status = {"error_code": exc.code}, "unavailable"
            limitations.append(str(exc))
        data = sanitize(raw)
        if len(json.dumps(data)) > 64000:
            # Shed the big collections, largest first, and keep the scalars.
            #
            # This used to replace the whole payload with {"omitted": ...} and
            # set status to "partial", which made `summaries` skip the day
            # entirely -- and the days that blow the cap are the BUSY ones, so
            # the filter dropped exactly the evidence that mattered most.
            #
            # Measured on tenant f65d9135 for 2026-09-14..21: 2026-09-17 came
            # back at 998,112 characters, of which 862,926 (86%) was a list of
            # 891 individual `queries`. The counts this collector actually
            # reads -- cacheHits 810, cacheMisses 1094, totalHits 1904 -- are
            # fifteen characters. Dropping that day took the reported week from
            # 810 hits over 1,944 requests down to 0 over 40, because the only
            # surviving day was the quiet one. The report was honest about
            # covering 1 of 7 days and still gave a materially wrong picture.
            #
            # A day's totals are not made partial by discarding a per-query
            # breakdown nobody summed, so status is left alone and the omission
            # is named instead.
            shed = []
            while len(json.dumps(data)) > 64000:
                collections = {
                    k: len(json.dumps(v))
                    for k, v in data.items()
                    if isinstance(v, (list, dict))
                }
                if not collections:
                    break
                biggest = max(collections, key=collections.get)
                shed.append(f"{biggest} ({len(data[biggest])} items)")
                data = {k: v for k, v in data.items() if k != biggest}
            if len(json.dumps(data)) > 64000:
                # Nothing left to shed and still over: the scalars alone are
                # too large, which should not happen. Fail the old way.
                data = {"omitted": "Source response exceeds model evidence limit"}
                status = "partial"
                limitations.append("Evidence data omitted at local size cap")
            else:
                limitations.append(
                    "Omitted at local size cap, counts retained: " + ", ".join(shed)
                )
        evidence = Evidence(
            id=uuid.uuid4().hex,
            tenant_id=self.adapter.tenant,
            start_date=str(start),
            end_date=str(end),
            source_tool=name,
            arguments=sanitize(arguments),
            retrieved_at=now(),
            status=status,
            data=data,
            limitations=limitations,
        )
        self.evidence.append(evidence)
        return evidence, raw

    async def summaries(self, start, end):
        rows, evidence_ids = [], []
        latency_sum, latency_count, latency_known = 0.0, 0, True
        day = start
        while day < end:
            item, raw = await self.fetch(
                "get_summary",
                day,
                day + timedelta(days=1),
                year=f"{day.year:04}",
                month=f"{day.month:02}",
                day=f"{day.day:02}",
            )
            evidence_ids.append(item.id)
            if item.status == "complete" and isinstance(raw, dict):
                row = {
                    "cache_hits": raw.get("cacheHits", raw.get("totalCacheHits")),
                    "cache_misses": raw.get("cacheMisses", raw.get("totalCacheMisses")),
                    "start_date": str(day),
                    "end_date": str(day + timedelta(days=1)),
                }
                if "totalHits" in raw:
                    row["requests"] = raw["totalHits"]
                try:
                    for current, legacy in (("cacheHits", "totalCacheHits"), ("cacheMisses", "totalCacheMisses")):
                        if current in raw and legacy in raw and raw[current] != raw[legacy]:
                            raise ValueError("Conflicting summary count aliases")
                    summarize_counts([row])
                    rows.append(row)
                    for count, field in (
                        (row["cache_hits"], "cacheHitAverageResponseTime"),
                        (row["cache_misses"], "cacheMissAverageResponseTime"),
                    ):
                        average = raw.get(field)
                        if count and (
                            type(average) not in (int, float)
                            or not math.isfinite(average)
                            or average <= 0
                        ):
                            latency_known = False
                        elif count:
                            latency_sum += average * count
                            latency_count += count
                except (ValueError, TypeError):
                    item.status = "partial"
                    item.limitations.append(
                        "Missing, conflicting or inconsistent request/hit/miss counts"
                    )
            if item.data.get("error_code") in ("budget", "deadline"):
                break
            day += timedelta(days=1)
        result = summarize_counts(rows)
        result["covered_days"] = len(rows)
        result["requested_days"] = (end - start).days
        result["evidence_ids"] = evidence_ids
        result["period_complete"] = len(rows) == (end - start).days
        result["latency"] = {
            "response_time_ms": latency_sum / latency_count
            if latency_known and latency_count
            else None,
            "denominator": latency_count if latency_known else None,
            "label": "Request-weighted source response-time average for covered days; end-to-end proxy, not warehouse savings",
            "period_complete": result["period_complete"]
            and latency_known
            and bool(latency_count),
        }
        return result

    async def query(self, kind, start, end):
        schema, raw = await self.fetch("describe_log_schema", start, end)
        if schema.status != "complete":
            return None
        try:
            sql = query_template(kind, raw, start, end)
        except ValueError as exc:
            schema.status = "partial"
            schema.limitations.append(str(exc))
            return None
        item, _ = await self.fetch("query_logs", start, end, sql=sql)
        item.arguments = {
            "template": kind,
            "start_date": str(start),
            "end_date": str(end),
        }
        # An upstream response can omit the grouping keys requested by our SQL.
        # Template intent is not evidence that those keys actually came back.
        interpretation = query_interpretation(item.data, kind)
        item.data["interpretation"] = interpretation
        if not interpretation["grouping_verified"] and item.status == "complete":
            item.status = "partial"
        item.limitations.append(interpretation["note"])
        # SQL is our fixed template. Do not expose source literal SQL in returned cells.
        return item


def query_template(kind, schema, start, end):
    fields = {
        "outcomes": ["cacheStatus"],
        "repeated_misses": ["queryHash", "cacheStatus"],
        "per_rule": ["ruleId", "cacheStatus"],
        "per_user": ["userName", "cacheStatus"],
    }
    if kind not in fields:
        raise ValueError(
            "Unsupported investigation; choose outcomes, repeated_misses, per_rule or per_user"
        )
    columns = schema.get("columns", [])
    names = {c if isinstance(c, str) else c.get("name") for c in columns}
    required = ["day", *fields[kind]]
    if not set(required) <= names:
        raise ValueError("Live schema lacks required case-sensitive template columns")
    if any(not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", col) for col in required):
        raise ValueError("Unsupported log column identifier")
    group = ", ".join('"' + name + '"' for name in fields[kind])
    where = f"\"day\" >= '{start.isoformat()}' AND \"day\" < '{end.isoformat()}'"
    if kind == "repeated_misses":
        where += " AND \"cacheStatus\" = 'MISS'"
    return f"SELECT {group}, COUNT(*) AS executions FROM proxy_logs WHERE {where} GROUP BY {group} ORDER BY executions DESC LIMIT 100"


def query_interpretation(data, kind):
    """Describe what the returned row shape can establish, not what SQL requested."""
    group = {"outcomes": "cacheStatus", "repeated_misses": "queryHash",
             "per_rule": "ruleId", "per_user": "userName"}[kind]
    rows = data.get("rows")
    columns = data.get("columns", [])
    names = [c if isinstance(c, str) else c.get("name") if isinstance(c, dict) else None
             for c in columns] if isinstance(columns, list) else []
    valid = isinstance(rows, list)
    recurrence = False
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, list) and len(row) == len(names) and all(isinstance(n, str) for n in names) and len(set(names)) == len(names):
            row = dict(zip(names, row))
        if not isinstance(row, dict):
            valid = False
            continue
        identity, status, count = row.get(group), row.get("cacheStatus"), row.get("executions")
        if (not isinstance(identity, str) or not identity.strip() or identity in ("[identity]", "[redacted]", "[literal]")
                or not isinstance(status, str) or not status.strip()
                or isinstance(count, bool) or not isinstance(count, int) or count < 0):
            valid = False
            continue
        if kind == "repeated_misses" and status == "MISS" and count >= 2:
            recurrence = True
    supported = kind == "repeated_misses" and valid and recurrence
    return {
        "template": kind,
        "required_grouping": group,
        "grouping_verified": valid,
        "query_recurrence_observed": supported if kind == "repeated_misses" and valid else None,
        "note": (
            "Returned rows contain query identities with at least two MISS executions; recurrence is observed only for those returned query groups. No rule attribution is established."
            if supported else
            "Query recurrence is NOT established by this result. Aggregate misses, a requested repeated_misses template, and equal period hit rates do not prove that any query repeatedly missed. "
            + ("Required grouping identity or execution count is missing/malformed; report this evidence as partial." if not valid else
               "Use only the returned grouping; no repeated-query claim follows from these rows.")
        ),
    }
