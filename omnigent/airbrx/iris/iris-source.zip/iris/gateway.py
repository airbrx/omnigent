"""Gateway coverage assessment; column presence alone cannot establish semantics."""

def assess_gateway_schema(schema):
    columns = schema.get("columns", []) if isinstance(schema, dict) else []
    candidates = [c if isinstance(c, str) else c.get("name")
                  for c in columns if isinstance(c, (str, dict))] if isinstance(columns, list) else []
    names = {name for name in candidates if isinstance(name, str)}
    required = {"day", "timestamp", "statusCode", "userName"}
    return {
        "status": "unknown",
        "available_columns": sorted(required & names),
        "missing_columns": sorted(required - names),
        "query_supported": False,
        "observed_failure_count": None,
        "limitations": [
            "Timestamp units and statusCode failure/refusal semantics have not been verified.",
            "Coverage of pre-authentication failures and malformed protocol requests is unverified.",
            "Column presence or an empty query result cannot establish complete gateway coverage.",
        ],
        "required_upstream_evidence": [
            "Documented timestamp units, timezone and supported hourly query expression",
            "Documented status codes and distinction between gateway and warehouse failures",
            "Confirmation of logged pre-authentication/refusal/protocol events and safe actor identity",
        ],
    }


def unavailable_watch_result(report, *, tenant_id, run_id, start, end):
    """Host adapter for an hourly run blocked on instrumentation, not a scheduler.

    Failure results never authorize a success watermark or model invocation.
    Hosts own persistence, retries, authenticated artifacts and deduplication.
    """
    import hashlib
    import json
    from datetime import datetime, timedelta, timezone

    if not isinstance(run_id, str) or not run_id.strip() or len(run_id) > 200:
        raise ValueError("A bounded host run ID is required")
    if report.get("tenant_id") != tenant_id or not tenant_id:
        raise ValueError("Watch report tenant does not match host tenant")
    a, b = (datetime.fromisoformat(value.replace("Z", "+00:00")) for value in (start, end))
    if (a.utcoffset() != timedelta(0) or b.utcoffset() != timedelta(0)
            or a.minute or a.second or a.microsecond or b - a != timedelta(hours=1)
            or b > datetime.now(timezone.utc)):
        raise ValueError("Watch window must be one completed UTC hour")
    window = {"start": a.isoformat(), "end_exclusive": b.isoformat()}
    coverage = report.get("gateway_coverage")
    if not isinstance(coverage, dict) or coverage.get("query_supported") is not False:
        raise ValueError("Expected an unsupported gateway coverage assessment")
    identity = {"tenant_id": tenant_id, "window": window, "reason": "gateway_coverage_unverified"}
    return {
        "schemaVersion": 1, "tenant_id": tenant_id, "run_id": run_id,
        "window": window, "status": "partial", "coverage": coverage,
        "evidence_ids": [e["id"] for e in report.get("evidence", [])
                         if isinstance(e, dict) and isinstance(e.get("id"), str)],
        "findings": [], "artifacts": report.get("artifacts", {}),
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "dedupe_key": hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest(),
        "advance_success_watermark": False, "invoke_model": False,
        "monitoring_available": False,
    }
