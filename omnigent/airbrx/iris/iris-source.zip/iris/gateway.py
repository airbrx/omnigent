"""Gateway coverage assessment; column presence alone cannot establish semantics.

What this module can and cannot answer is settled by
`docs/build/GATEWAY-EVIDENCE-CONTRACT.md`, which traced the producers rather
than guessing at them. The short version, because every function here depends
on it: `query_logs` can report **recorded SQL-bearing refusals and errors** for
a completed UTC hour, and nothing more. Missing or revoked credentials,
untrusted hosts, unknown tenants and malformed protocol requests never reach
the tenant request logger, and the summary pipeline drops any record without
standardized SQL — so an authentication failure without SQL is not a row that
can be queried. That is why nothing below can return a clean bill of health: an
empty result means no matching rows were observed in the queried store, which is
a different statement from "no gateway failures occurred", and only one of those
is supported by the evidence.
"""

from datetime import datetime, timedelta, timezone

# Both spellings of "this request was refused" and "this request errored" are
# kept apart on purpose. A refusal is policy working; an error is not; an HTTP
# failure with an ordinary cache status is a third thing. Summing them would
# produce a single number that answers no question anyone actually has.
REFUSAL_STATUSES = frozenset({"BLOCKED"})
ERROR_STATUSES = frozenset({"INVALIDATION_ERROR", "AUTH_ERROR", "ERROR"})
_CATEGORY_BY_STATUS = {
    "BLOCKED": "refusals",
    "AUTH_ERROR": "auth_errors",
    "INVALIDATION_ERROR": "invalidation_errors",
    "ERROR": "errors",
}

# Types, not names. The contract is explicit that `timestamp` is epoch
# MILLISECONDS and `day` is a date-shaped VARCHAR partition; a column called
# `timestamp` that is actually a TIMESTAMP, or seconds, silently changes every
# bound in the sweep by three orders of magnitude. Reporting the mismatch is the
# only honest option — guessing units is how a window becomes fiction.
_REQUIRED_TYPES = {
    "day": frozenset({"VARCHAR", "STRING", "TEXT"}),
    "timestamp": frozenset({"BIGINT", "LONG", "INT64"}),
    "cacheStatus": frozenset({"VARCHAR", "STRING", "TEXT"}),
    "statusCode": frozenset({"INTEGER", "INT", "INT32", "BIGINT"}),
}
_OPTIONAL_ACTOR = ("userName", frozenset({"VARCHAR", "STRING", "TEXT"}))

# When these claims were last traced against the producers, and against what.
# Every entry below describes a condition in airbrx/airbrx-gateway and the
# summary pipeline — not in this repository — so nothing here can notice when
# one stops being true. A reader is owed the age of the claim rather than being
# left to assume it is current: a stale honesty annotation is worse than a
# missing one, because it is trusted. Re-trace and move this date, or the flag
# is asserting something nobody has checked.
_COVERAGE_TRACED_AT = "2026-09-14"
_COVERAGE_TRACED_AGAINST = "docs/build/GATEWAY-EVIDENCE-CONTRACT.md §2-§3"

# Why each category's rows are a subset of the events the category names.
# `categories` counts observed rows and is accurate as that; it is also the
# number a reader quotes, and a zero that arrives wearing a correct integer
# needs its caveat attached to it rather than sitting in prose further down.
# Every entry is under-covered, for a different reason, and none of these
# reasons is fixable by sweeping more often — they are all upstream of the
# queryable store. Traced in docs/build/GATEWAY-EVIDENCE-CONTRACT.md §2-§3.
_CATEGORY_COVERAGE = {
    "refusals": (
        "Counts recorded SELECT refusals only. Databricks Thrift, Snowflake and"
        " PostgreSQL denials reach the request logger, but the Databricks JSON"
        " statement path returns its denial before context attachment, so the"
        " formatter drops the entry and that refusal is client-visible with no"
        " row here. A tenant refused entirely over JSON can show zero."
    ),
    "auth_errors": (
        "Counts only authentication errors that carried standardized SQL. The"
        " summary pipeline rejects any record without standardized SQL, and"
        " missing, malformed or revoked credentials are rejected before the"
        " tenant request logger runs at all, so the events this category names"
        " most often cannot produce a row by construction. Zero here is not"
        "'no authentication failures'."
    ),
    "invalidation_errors": (
        "Counts SQL-bearing rows carrying the INVALIDATION_ERROR status. The"
        " flattened schema exposes the enum but not the refusal reason, so the"
        " count cannot be split into fail-closed refusals and genuine failures."
    ),
    "errors": (
        "Counts returned, formatted SQL-bearing errors. Failures raised as outer"
        " exceptions bypass the request logger, and nothing in the flattened row"
        " identifies whether a warehouse was reached, so this is neither a"
        " complete error count nor evidence of origin."
    ),
    "http_failures": (
        "Counts rows whose stored status is 400 or above and whose cache status"
        " is not itself a failure. Stored status codes are synthetic on some"
        " adapter paths — PostgreSQL stores 200 for native errors — and malformed"
        " HTTP framing rejected before request processing never becomes a tenant"
        " event, so this is a floor on HTTP-shaped failures and not a census."
    ),
}

_PARTIAL_LIMITATIONS = (
    "Authentication and malformed-request coverage is incomplete.",
    "Missing or revoked credentials, unknown tenants and protocol errors can fail"
    " before the tenant request logger runs, and records without standardized SQL"
    " are excluded from the queryable store.",
    "Denial reason, native error code and the rule behind a refusal are not exposed"
    " by the flattened schema; no refusal can be attributed to a rule.",
    "An empty or partial result cannot establish complete gateway coverage.",
)

def _columns(schema):
    """Return {name: declared type or None} from a describe_log_schema payload.

    Accepts the two shapes the discovery tool has been seen to return — bare
    names, and dicts carrying a type — because a bare name is exactly the case
    that must NOT be read as a verified type.
    """
    raw = schema.get("columns", []) if isinstance(schema, dict) else []
    found = {}
    for entry in raw if isinstance(raw, list) else []:
        if isinstance(entry, str):
            found[entry] = None
        elif isinstance(entry, dict) and isinstance(entry.get("name"), str):
            declared = entry.get("type")
            found[entry["name"]] = declared.strip().upper() if isinstance(declared, str) else None
    return found


def assess_gateway_schema(schema):
    """Decide whether the bounded hourly sweep may run, and say why not.

    Three outcomes, and the middle one is the one worth keeping: a column can be
    present, absent, or present with a type nobody has verified. The last is not
    support. `describe_log_schema` returning a bare list of names tells us the
    names exist and nothing about milliseconds versus seconds, so it lands in
    `unverified_columns` rather than being counted as satisfied.
    """
    found = _columns(schema)
    missing, unverified, mismatched = [], [], {}
    for name, accepted in _REQUIRED_TYPES.items():
        if name not in found:
            missing.append(name)
        elif found[name] is None:
            unverified.append(name)
        elif found[name] not in accepted:
            mismatched[name] = found[name]
    actor, actor_types = _OPTIONAL_ACTOR
    # Optional by design: losing actor grouping costs one breakdown, not the sweep.
    actor_available = found.get(actor) in actor_types
    supported = not missing and not unverified and not mismatched
    limitations = list(_PARTIAL_LIMITATIONS)
    if not supported:
        limitations.insert(
            0,
            "The queried store's schema does not establish the column types this"
            " investigation requires; no failure query was built.",
        )
    if not actor_available:
        limitations.append(
            "No verified actor column; refusals cannot be grouped by user in this store."
        )
    return {
        # Never "complete". The best available answer is a partial one.
        "status": "partial" if supported else "unknown",
        "available_columns": sorted(set(_REQUIRED_TYPES) - set(missing) - set(unverified)
                                    - set(mismatched)),
        "missing_columns": sorted(missing),
        "unverified_columns": sorted(unverified),
        "type_mismatches": mismatched,
        "query_supported": supported,
        "actor_grouping_available": actor_available,
        "observed_failure_count": None,
        "capability": (
            "Hourly review of recorded SQL refusals and errors; authentication and"
            " malformed-request coverage incomplete."
        ),
        "limitations": limitations,
        "required_upstream_evidence": [
            "A tenant-safe event channel for failures that never reach the request"
            " logger, including unattributable pre-tenant requests",
            "Flattened denial reason, native error code and the rule behind a refusal",
            "An ingestion-complete watermark, so an empty hour can be distinguished"
            " from an unflushed one",
        ],
    }


def _completed_hour(start, end):
    """Parse and check one completed UTC hour, returning both ends.

    Shared by the sweep and the watch result so a window cannot pass one and
    fail the other.
    """
    a, b = (datetime.fromisoformat(value.replace("Z", "+00:00")) for value in (start, end))
    if (a.utcoffset() != timedelta(0) or b.utcoffset() != timedelta(0)
            or a.minute or a.second or a.microsecond or b - a != timedelta(hours=1)
            or b > datetime.now(timezone.utc)):
        raise ValueError("Watch window must be one completed UTC hour")
    return a, b


def previous_completed_hour(now=None):
    """The last UTC hour that is entirely over, as (start, end_exclusive).

    The contract is explicit that the window must be a *completed* hour: the
    current hour is still being written to, and an ingestion pipeline that is
    asynchronous by design has not finished with the one before it either. This
    truncates deliberately rather than rounding — `watch.hour_window` refuses a
    non-boundary start precisely so that a silent round cannot move the window
    out from under the operator who is reading the result.

    It does not make the hour *covered*. Late-arriving rows can change an
    already-completed hour, which is why nothing downstream advances a coverage
    watermark from a sweep of it.
    """
    now = now or datetime.now(timezone.utc)
    end = now.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
    return (end - timedelta(hours=1)).isoformat(), end.isoformat()


def hourly_sweep_sql(*, start, end):
    """Build the bounded failure sweep for one completed UTC hour.

    A template over host-supplied window values, never model-authored text. Two
    bounds do different jobs and both are required: `day` prunes partitions and
    is the only thing the upstream guard checks for, while the millisecond
    `timestamp` range is what actually makes the window an hour. The guard
    seeing a `day` identifier is not proof of finite bounds, so this enforces
    them here rather than relying on it.

    The end is exclusive and the day range covers every partition the window
    intersects — an hour ending at midnight touches two of them, and dropping
    the second silently halves the answer.

    Deliberately absent: SQL text, actor, client address and query hash. The
    cheap sweep counts observations; it does not carry evidence about people.
    """
    a, b = _completed_hour(start, end)
    # `day < ` is exclusive, so the bound is the day after the last one touched.
    # b is exclusive already, but an hour ending exactly at midnight still has
    # its final millisecond inside the previous day; stepping off b's date
    # rather than (b - 1ms)'s keeps the range inclusive of both without a
    # special case.
    first, last = a.date(), (b.date() + timedelta(days=1))
    return (
        'SELECT "cacheStatus", "statusCode", COUNT(*) AS observed_requests\n'
        "FROM proxy_logs\n"
        f"WHERE day >= '{first.isoformat()}' AND day < '{last.isoformat()}'\n"
        f'  AND "timestamp" >= {int(a.timestamp() * 1000)}'
        f' AND "timestamp" < {int(b.timestamp() * 1000)}\n'
        '  AND ("cacheStatus" IN (\'BLOCKED\', \'INVALIDATION_ERROR\', \'AUTH_ERROR\', \'ERROR\')\n'
        '       OR "statusCode" >= 400)\n'
        'GROUP BY "cacheStatus", "statusCode"\n'
        'ORDER BY observed_requests DESC, "cacheStatus", "statusCode"'
    )


def summarize_failure_rows(result, *, window):
    """Fold sweep rows into separate categories, keeping every limit attached.

    Nothing here is a verdict. Counts are observations for review: a repeated
    refusal is policy being applied repeatedly, which is as consistent with one
    misconfigured dashboard as with anything else, and the flattened schema
    cannot say which rule refused or whether the request reached a warehouse.
    """
    rows = result.get("rows") if isinstance(result, dict) else None
    if not isinstance(rows, list):
        raise ValueError("A sweep result must carry rows")
    # The store returns rows either as arrays or as objects keyed by column —
    # `query_interpretation` in the collector already handles both, so reading
    # only arrays here would refuse live data the rest of the codebase accepts.
    # Object rows are resolved through the declared column names rather than by
    # guessing at keys: a renamed column must fail, not silently match nothing.
    columns = result.get("columns") if isinstance(result, dict) else None
    names = [c if isinstance(c, str) else c.get("name") if isinstance(c, dict) else None
             for c in columns] if isinstance(columns, list) else []
    categories = {"refusals": 0, "auth_errors": 0, "invalidation_errors": 0,
                  "errors": 0, "http_failures": 0}
    total = 0
    for row in rows:
        if isinstance(row, dict):
            if len(names) < 3 or not all(isinstance(n, str) for n in names[:3]):
                raise ValueError(
                    "An object-shaped sweep row needs the result's column names")
            if not set(names[:3]) <= set(row):
                raise ValueError("An object-shaped sweep row is missing a declared column")
            row = [row[name] for name in names[:3]]
        if not isinstance(row, (list, tuple)) or len(row) < 3:
            raise ValueError("A sweep row must be cache status, HTTP status and a count")
        status, http, count = row[0], row[1], row[2]
        # Refuse rather than coerce: a count arriving as a string means the
        # transport changed shape, and int("7") would hide that behind a
        # plausible number.
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            raise ValueError("Observed request counts must be non-negative integers")
        # A refusal is a refusal at any HTTP status. Databricks and PostgreSQL
        # deny with 200 and Snowflake with 403, so reading the HTTP code first
        # would count the same event two different ways depending on warehouse.
        category = _CATEGORY_BY_STATUS.get(status if isinstance(status, str) else "")
        if category is None:
            category = "http_failures" if isinstance(http, int) and http >= 400 else None
        if category is None:
            continue
        categories[category] += count
        total += count
    truncated = bool(result.get("truncated"))
    limitations = list(_PARTIAL_LIMITATIONS)
    if truncated:
        limitations.insert(
            0,
            "The store truncated this result; the counts below are a floor, not a total.",
        )
    if not rows:
        limitations.insert(
            0,
            "No matching rows were observed in the queried store; this is not evidence"
            " that no gateway failures occurred.",
        )
    return {
        "window": dict(window),
        "categories": categories,
        # A truncated sweep has no total. Reporting the partial sum under the
        # same key as a complete one is how a floor becomes a fact.
        "observed_requests": None if truncated else total,
        "truncated": truncated,
        # Always: authentication coverage is never complete, so no hour is ever
        # fully covered, and a zero is a zero *among observed rows*.
        "incomplete": True,
        # Additive sibling to `categories`, deliberately not a replacement.
        # Making the counts None would be honest and would break the arithmetic
        # of every downstream consumer to fix what is really a wording problem.
        "coverage_by_category": {
            name: {
                "structurally_under_covered": True,
                "why": why,
                "traced_at": _COVERAGE_TRACED_AT,
                "traced_against": _COVERAGE_TRACED_AGAINST,
            }
            for name, why in _CATEGORY_COVERAGE.items()
        },
        "coverage_note": (
            "Each category's coverage claim was traced against the producers on"
            f" {_COVERAGE_TRACED_AT} ({_COVERAGE_TRACED_AGAINST}). The conditions"
            " described are upstream of this store, so Iris cannot detect it if"
            " one of them is fixed and a claim here silently goes stale."
        ),
        "rule_attribution": None,
        "limitations": limitations,
    }


def _watch_identity(report, *, tenant_id, run_id, start, end):
    """Validate a host run and return (window, dedupe key) for either sibling.

    The key comes from `iris.watch.retry_key` and is not minted here. One hour
    of one tenant has exactly one identity, wherever it is computed from — that
    is the whole value of a dedupe key, and two modules each hashing their own
    idea of it is how a retry silently becomes a second record.

    This matters across the pair: a store whose schema is unverified on one
    attempt and typed on the next must update the record it already has. The
    earlier key hashed a `reason` in alongside the window, so the unsupported
    and supported results of the same hour could never collide, and the retry
    that finally succeeded opened a new row instead of closing the open one.
    """
    from iris import watch

    if not isinstance(run_id, str) or not run_id.strip() or len(run_id) > 200:
        raise ValueError("A bounded host run ID is required")
    if report.get("tenant_id") != tenant_id or not tenant_id:
        raise ValueError("Watch report tenant does not match host tenant")
    a, _ = _completed_hour(start, end)
    window = watch.hour_window(a)
    return window, watch.retry_key(tenant_id, window)


def _evidence_ids(report):
    return [e["id"] for e in report.get("evidence", [])
            if isinstance(e, dict) and isinstance(e.get("id"), str)]


def unavailable_watch_result(report, *, tenant_id, run_id, start, end):
    """Host adapter for an hourly run blocked on instrumentation, not a scheduler.

    Failure results never authorize a success watermark or model invocation.
    Hosts own persistence, retries, authenticated artifacts and deduplication.
    """
    from datetime import datetime, timezone

    window, dedupe_key = _watch_identity(
        report, tenant_id=tenant_id, run_id=run_id, start=start, end=end)
    coverage = report.get("gateway_coverage")
    if not isinstance(coverage, dict) or coverage.get("query_supported") is not False:
        raise ValueError("Expected an unsupported gateway coverage assessment")
    return {
        "schemaVersion": 1, "tenant_id": tenant_id, "run_id": run_id,
        "window": window, "status": "partial", "coverage": coverage,
        "evidence_ids": _evidence_ids(report),
        "findings": [], "artifacts": report.get("artifacts", {}),
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "dedupe_key": dedupe_key,
        "advance_success_watermark": False, "invoke_model": False,
        "monitoring_available": False,
    }


def supported_watch_result(report, *, tenant_id, run_id, start, end):
    """Host adapter for an hourly run whose sweep actually executed.

    The sibling of `unavailable_watch_result`, and deliberately almost as
    cautious. A sweep that ran is still not coverage: authentication and
    malformed-request failures never reached the queryable store, so

    - `status` is `partial`, never `complete`;
    - `advance_success_watermark` is **False unconditionally**, including for a
      sweep that returned cleanly with zero observations. No hour is ever fully
      covered, so there is no hour a watermark may be advanced past. This is the
      field a scheduler would use to decide an hour never needs looking at
      again, and nothing here has earned that;
    - `monitoring_available` stays False. A regular sweep makes the asking
      regular; it does not widen what can be asked.

    `findings` are the report's own — empty unless the sweep observed something
    real — and the model is invoked only when there is something for it to
    explain. An empty hour has nothing to say and does not need a model to say
    it.
    """
    from datetime import datetime, timezone

    window, dedupe_key = _watch_identity(
        report, tenant_id=tenant_id, run_id=run_id, start=start, end=end)
    coverage = report.get("gateway_coverage")
    if not isinstance(coverage, dict) or coverage.get("query_supported") is not True:
        raise ValueError("Expected a supported gateway coverage assessment")
    sweep = report.get("gateway_sweep")
    # A report with no executed sweep is a caller mixing the siblings up.
    # Returning a healthy-looking envelope for it is the dangerous answer.
    if not isinstance(sweep, dict) or not isinstance(sweep.get("summary"), dict):
        raise ValueError("Expected a report carrying an executed gateway sweep")
    findings = [f for f in report.get("findings", []) if isinstance(f, dict)]
    return {
        "schemaVersion": 1, "tenant_id": tenant_id, "run_id": run_id,
        "window": window, "status": "partial", "coverage": coverage,
        "sweep": sweep["summary"],
        "evidence_ids": _evidence_ids(report),
        "findings": findings, "artifacts": report.get("artifacts", {}),
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "dedupe_key": dedupe_key,
        "advance_success_watermark": False,
        "invoke_model": bool(findings),
        "monitoring_available": False,
    }
