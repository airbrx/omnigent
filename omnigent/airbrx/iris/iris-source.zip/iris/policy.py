"""Defense in depth for stock hosts that auto-register unrelated tools."""

IRIS_TOOLS = frozenset(
    {"iris_overview", "iris_investigate", "iris_audit", "iris_propose"}
)


def tool_boundary(event):
    if event.get("type") != "tool_call":
        return {"result": "ALLOW", "reason": "Not a tool execution"}
    name = event.get("target", "")
    if name.startswith("mcp__omnigent__"):
        name = name[len("mcp__omnigent__") :]
    if name in IRIS_TOOLS:
        return {"result": "ALLOW", "reason": "Registered Iris domain tool"}
    return {
        "result": "DENY",
        "reason": "Iris permits only its four read-only domain tools",
    }
