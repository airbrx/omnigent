"""Defense in depth for stock hosts that auto-register unrelated tools."""

IRIS_TOOLS = frozenset(
    {"iris_overview", "iris_investigate", "iris_audit", "iris_propose"}
)

# Discovery, not execution. `ToolSearch` returns tool *references* and runs
# nothing; on a real hosted turn Iris calls it to locate
# `mcp__omnigent__iris_overview` before calling it.
#
# Without this, a boundary that finally starts being enforced would deny the
# call Iris uses to find her own tools — and a guardrail that breaks the agent
# it protects gets switched off, which is worse than one that is slightly wider.
# Observed on production session 35340ac1035047878965bca623fc6797, where
# ToolSearch completed and this policy would have refused it.
#
# Skill / `load_skill` stays DENIED and is deliberately not here: loading a
# skill is execution surface, not discovery, and `tests/test_host.py` has
# asserted that refusal since this policy shipped.
DISCOVERY_TOOLS = frozenset({"ToolSearch"})


def tool_boundary(event):
    if event.get("type") != "tool_call":
        return {"result": "ALLOW", "reason": "Not a tool execution"}
    name = event.get("target", "")
    if name.startswith("mcp__omnigent__"):
        name = name[len("mcp__omnigent__") :]
    if name in IRIS_TOOLS:
        return {"result": "ALLOW", "reason": "Registered Iris domain tool"}
    if name in DISCOVERY_TOOLS:
        return {"result": "ALLOW", "reason": "Read-only tool discovery, executes nothing"}
    return {
        "result": "DENY",
        "reason": "Iris permits only its four read-only domain tools",
    }
