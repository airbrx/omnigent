"""Durable hourly watch bookkeeping: which completed UTC hours a tenant has been
swept for, which are outstanding, and a stable identity for retrying one.

This module has no timer, no scheduler, no daemon, no socket and no dependency.
It is the pure core underneath the opt-in hourly review in
`docs/build/ARTICLE-ALIGNMENT.md`, and it runs only when a host calls it.

**Monitoring is unavailable, and nothing here changes that.** A schedule makes
the asking regular; it does not widen what can be asked. Missing credentials,
unknown tenants and malformed protocol requests fail before the tenant request
logger runs, and records without standardized SQL never reach the queryable
store, so authentication coverage is incomplete no matter how often a host
sweeps. Accordingly:

- A processed-window marker and a coverage guarantee are different things and
  carry different names here. `processed_through` is the former. There is no
  function that advances the latter, and `record` refuses a `"complete"` status
  outright rather than storing one that nothing has earned.
- An empty, failed, cancelled or truncated sweep is recorded as what it was. It
  never becomes a green result, and `outstanding` keeps handing back a window
  whose only attempts failed.
- Nothing here reports monitoring as configured, enabled or active.

**What a host must supply**, none of which lives in this module: the timer
itself (native host scheduling - not a daemon, not a browser timer), tenant-bound
credentials, per-tenant run serialization so two sweeps of one tenant cannot
interleave, the authenticated inbox the findings are published to, and artifact
persistence. The host also owns retention: this file is deleted by the host's
own mechanism, and Iris has no cleanup daemon.

**Persistence.** One plain JSON file under the session's own state root, written
through `iris.artifacts.atomic`. State that scales to zero means a file that
does not exist until there is something to record, so `load` treats an absent
file as an empty history - which is not the same as a tenant with nothing
outstanding, and is not reported as such.

Stored object (`iris-watch.json`, host state root, mode 0600):
`schemaVersion`, `tenant_id`, `revision` - bumped on every write so a run that
writes over a base another run has moved past is refused rather than silently
winning - and `windows`, a mapping of retry key to
`{start, end_exclusive, status, attempts, truncated, coverage, evidence_ids,
run_id, first_attempted_at, last_attempted_at}`.
"""

import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from iris.artifacts import atomic

SCHEMA_VERSION = 1

#: A host that was off for a week must not stampede the upstream on the next
#: tick. `outstanding` returns at most this many windows per call by default,
#: oldest first, and says how many it did not return.
DEFAULT_MAX_BACKLOG = 24

#: Statuses a sweep may be recorded under. `"complete"` is deliberately absent:
#: see the module docstring. `"partial"` is the best available outcome.
RECORDABLE = ("partial", "failed", "cancelled")

_HOUR = timedelta(hours=1)


def _parse(value, field):
    if not isinstance(value, str):
        raise ValueError(f"{field} must be an ISO-8601 string in UTC")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise ValueError(f"{field} is not a parseable ISO-8601 timestamp") from None
    if parsed.utcoffset() != timedelta(0):
        raise ValueError(f"{field} must be UTC")
    return parsed


def hour_window(start):
    """Validate one completed UTC hour and return it as a window.

    Refuses anything that is not an exact hour boundary. A caller that means
    "the hour containing this instant" must truncate deliberately; silently
    rounding a timestamp is how a window becomes a different window than the
    operator believes was swept.
    """
    if isinstance(start, str):
        start = _parse(start, "start")
    if not isinstance(start, datetime) or start.tzinfo is None:
        raise ValueError("start must be a timezone-aware UTC datetime or ISO string")
    start = start.astimezone(timezone.utc)
    if start.minute or start.second or start.microsecond:
        raise ValueError("A watch window must begin on an exact UTC hour boundary")
    return {
        "start": start.isoformat(),
        "end_exclusive": (start + _HOUR).isoformat(),
    }


def retry_key(tenant_id, window):
    """A stable identity for one tenant's one hour.

    The same hour retried produces the same key, so a second attempt updates the
    existing record rather than appending a duplicate, and a late-arriving row
    lands on the record that is already there. The tenant is inside the hash:
    two tenants' identical hours are never the same key.
    """
    if not isinstance(tenant_id, str) or not tenant_id.strip():
        raise ValueError("A tenant ID is required")
    start = _parse(window["start"], "window.start")
    end = _parse(window["end_exclusive"], "window.end_exclusive")
    if end - start != _HOUR:
        raise ValueError("A watch window must be exactly one hour")
    identity = {
        "tenant_id": tenant_id,
        "start": start.isoformat(),
        "end_exclusive": end.isoformat(),
    }
    return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()


def empty(tenant_id):
    """The state of a tenant nothing has been recorded for."""
    if not isinstance(tenant_id, str) or not tenant_id.strip():
        raise ValueError("A tenant ID is required")
    return {"schemaVersion": SCHEMA_VERSION, "tenant_id": tenant_id,
            "revision": 0, "windows": {}}


def load(path, tenant_id):
    """Read a tenant's watch history, or an empty history if the file is absent.

    An absent file is not an error - nothing has been recorded yet. It is also
    not evidence that nothing needs recording; `outstanding` will say what is
    outstanding, and for a first run that is every hour in the bounded backlog.

    A file belonging to another tenant raises. One tenant's window state can
    never be read or advanced by another.
    """
    path = Path(path)
    if not path.exists():
        return empty(tenant_id)
    stored = json.loads(path.read_text())
    if not isinstance(stored, dict):
        raise ValueError("Watch state is not an object")
    if stored.get("schemaVersion") != SCHEMA_VERSION:
        raise ValueError(
            "Unrecognised watch state schemaVersion; refusing to guess its meaning"
        )
    if stored.get("tenant_id") != tenant_id:
        raise ValueError("Watch state belongs to a different tenant")
    windows = stored.get("windows")
    if not isinstance(windows, dict):
        raise ValueError("Watch state windows are missing or malformed")
    for key, entry in windows.items():
        # A half-readable record is refused here rather than surfacing later as a
        # KeyError inside a summary. A file we cannot fully read is not a history
        # of zero sweeps, and must never be reported as one.
        if not isinstance(entry, dict):
            raise ValueError(f"Watch state entry {key} is not an object")
        missing = {
            "start",
            "end_exclusive",
            "status",
            "attempts",
            "truncated",
        } - set(entry)
        if missing:
            raise ValueError(
                f"Watch state entry {key} is missing {sorted(missing)}"
            )
        if entry["status"] not in RECORDABLE:
            raise ValueError(
                f"Watch state entry {key} carries an unrecognised status"
            )
        if not isinstance(entry["attempts"], int) or entry["attempts"] < 1:
            raise ValueError(f"Watch state entry {key} has a malformed attempt count")
        if not isinstance(entry["truncated"], bool):
            raise ValueError(f"Watch state entry {key} has a malformed truncation flag")
    revision = stored.get("revision", 0)
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 0:
        raise ValueError("Watch state revision is malformed")
    return {
        "schemaVersion": SCHEMA_VERSION,
        "tenant_id": tenant_id,
        "revision": revision,
        "windows": windows,
    }


class ConcurrentUpdate(Exception):
    """Another run wrote this tenant's watch state after we read it.

    The host owns per-tenant run serialization; this is not a lock and does not
    provide it. It is a detector, and a narrow one - two writers can still
    interleave between the read below and the replace. What it removes is the
    silent case: without it, the second writer's whole-file replace discards the
    first writer's recorded windows and nothing anywhere says so.
    """


def save(path, state):
    """Write the history atomically, refusing a base another run has moved past.

    Raises :class:`ConcurrentUpdate` when the file on disk carries a revision
    other than the one this state was read at. The caller re-reads, re-applies
    and retries - the retry key makes that idempotent, so a replayed record
    updates its window rather than duplicating it.

    Returns the state as written, advanced revision included, so a caller that
    writes more than once does not have to re-read between writes.
    """
    if state.get("schemaVersion") != SCHEMA_VERSION:
        raise ValueError("Refusing to write watch state with an unknown schemaVersion")
    if not isinstance(state.get("tenant_id"), str) or not state["tenant_id"].strip():
        raise ValueError("Refusing to write watch state without a tenant")
    path = Path(path)
    base = state.get("revision", 0)
    if path.exists():
        current = load(path, state["tenant_id"])["revision"]
        if current != base:
            raise ConcurrentUpdate(
                f"Watch state moved from revision {base} to {current} while this run"
                " held it; re-read and re-apply rather than overwriting"
            )
    written = {**state, "revision": base + 1}
    atomic(path, json.dumps(written, sort_keys=True))
    path.chmod(0o600)
    # Returned so a host loop can keep writing without re-reading: the value it
    # holds is the value on disk, which is the whole point of the check above.
    return written


def record(
    state,
    *,
    tenant_id,
    window,
    status,
    coverage,
    evidence_ids=(),
    run_id=None,
    truncated=False,
    at=None,
):
    """Record one attempt at one window, deduplicated by `retry_key`.

    Returns a new state; the input is not mutated. Retrying a window updates its
    record in place and increments `attempts` - the inbox sees one finding for
    one hour however many times a host retried it.

    `status` must be one of `RECORDABLE`. `"complete"` is refused: authentication
    coverage is incomplete regardless of sweep frequency, so no hour is fully
    covered and nothing here may say otherwise.
    """
    if state.get("tenant_id") != tenant_id:
        raise ValueError("Refusing to record a window against a different tenant")
    if status == "complete":
        raise ValueError(
            "A watch sweep is never complete: authentication and malformed-request"
            " coverage is incomplete regardless of how often a host sweeps"
        )
    if status not in RECORDABLE:
        raise ValueError(f"status must be one of {RECORDABLE}")
    if not isinstance(coverage, dict):
        raise ValueError("A coverage assessment is required, even a negative one")
    if not isinstance(truncated, bool):
        raise ValueError("truncated must be a bool; an unknown sweep extent is not False")
    ids = list(evidence_ids)
    if any(not isinstance(i, str) or not i for i in ids):
        raise ValueError("Evidence IDs must be non-empty strings")
    if run_id is not None and (not isinstance(run_id, str) or not run_id.strip()):
        raise ValueError("A run ID, when given, must be a non-empty string")
    stamp = (at or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()

    key = retry_key(tenant_id, window)
    validated = hour_window(_parse(window["start"], "window.start"))
    if validated["end_exclusive"] != _parse(
        window["end_exclusive"], "window.end_exclusive"
    ).isoformat():
        raise ValueError("A watch window must be exactly one hour")

    previous = state["windows"].get(key)
    entry = {
        **validated,
        "status": status,
        "truncated": truncated,
        "coverage": coverage,
        "evidence_ids": ids,
        "run_id": run_id,
        "attempts": (previous["attempts"] + 1) if previous else 1,
        "first_attempted_at": previous["first_attempted_at"] if previous else stamp,
        "last_attempted_at": stamp,
    }
    return {
        "schemaVersion": SCHEMA_VERSION,
        "tenant_id": tenant_id,
        "revision": state.get("revision", 0),
        "windows": {**state["windows"], key: entry},
    }


def settled(entry):
    """Whether an attempt closed a window, or left it to be tried again.

    Only `partial` settles: it is the best outcome this design admits. A failed
    or cancelled sweep leaves the hour outstanding, because a window that could
    not be swept has not been swept - indeterminate does not pass.
    """
    return entry.get("status") == "partial"


def outstanding(state, *, now, tenant_id, max_backlog=DEFAULT_MAX_BACKLOG):
    """Completed UTC hours this tenant still owes a sweep, oldest first.

    Bounded: at most `max_backlog` windows come back, and the result says how
    many were withheld so a caller can never mistake a truncated list for the
    whole backlog. A host that was off for a week drains it a tick at a time.

    The current, incomplete hour is never returned - a partial hour swept as if
    it were whole reports a count against the wrong denominator.
    """
    if state.get("tenant_id") != tenant_id:
        raise ValueError("Refusing to read another tenant's watch state")
    if not isinstance(max_backlog, int) or max_backlog < 1:
        raise ValueError("max_backlog must be a positive integer")
    now = now.astimezone(timezone.utc)
    latest_start = now.replace(minute=0, second=0, microsecond=0) - _HOUR

    horizon = latest_start - _HOUR * (max_backlog - 1)
    done = {key for key, entry in state["windows"].items() if settled(entry)}

    # An hour we tried and failed is not the same as an hour we never reached.
    # It keeps its place in the queue however old it gets: the horizon bounds
    # how far back we *guess*, not how long we remember a known failure. There
    # is no stampede risk here - this set is bounded by what is already in the
    # file, and the whole result is capped below.
    owed = {
        entry["start"]: {
            "start": entry["start"],
            "end_exclusive": entry["end_exclusive"],
        }
        for entry in state["windows"].values()
        if not settled(entry)
    }

    start = horizon
    while start <= latest_start:
        window = hour_window(start)
        if retry_key(tenant_id, window) not in done:
            owed.setdefault(window["start"], window)
        start += _HOUR

    windows = [owed[key] for key in sorted(owed)]
    return {
        "windows": windows[:max_backlog],
        "considered_hours": max_backlog,
        "withheld": max(0, len(windows) - max_backlog),
        # The horizon is a bound, not a claim that earlier hours were swept.
        "older_than_horizon_unknown": True,
        "horizon": hour_window(horizon)["start"],
    }


def processed_through(state):
    """The newest hour whose sweep settled, or None if no sweep has settled.

    This is a processed-window marker, not a coverage watermark. It says a sweep
    ran and recorded what it could; it does not say the hour is covered, and
    hours before it may still be outstanding - `outstanding` is the answer to
    that question, not this one.
    """
    ends = [
        entry["end_exclusive"] for entry in state["windows"].values() if settled(entry)
    ]
    return max(ends) if ends else None


def status_summary(state, *, now, tenant_id, max_backlog=DEFAULT_MAX_BACKLOG):
    """What a UI may honestly say about this tenant's watch.

    Every count names its denominator, and `monitoring` is `"unavailable"` here
    permanently: this module is bookkeeping, and a host that calls it on a timer
    has regular asking, not monitoring.
    """
    pending = outstanding(
        state, now=now, tenant_id=tenant_id, max_backlog=max_backlog
    )
    attempts = state["windows"].values()
    return {
        "monitoring": "unavailable",
        "coverage_complete": False,
        "processed_through": processed_through(state),
        "recorded_windows": len(state["windows"]),
        "settled_windows": sum(1 for entry in attempts if settled(entry)),
        "failed_or_cancelled_windows": sum(
            1 for entry in attempts if not settled(entry)
        ),
        "truncated_windows": sum(1 for entry in attempts if entry.get("truncated")),
        "outstanding_in_horizon": len(pending["windows"]),
        "horizon_hours": pending["considered_hours"],
        "withheld_beyond_this_tick": pending["withheld"],
        "older_than_horizon_unknown": True,
    }
