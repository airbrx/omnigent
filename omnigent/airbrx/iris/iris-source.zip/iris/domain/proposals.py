"""Full-envelope candidate construction, and the hash that detects drift.

Two supported changes, one at a time: raise or lower the TTL of a rule that
already caches, or add one narrowly scoped SELECT cache rule. Everything else —
deny rules, invalidation rewrites, cache-key reductions, envelope version
changes — is refused rather than approximated, because a static review cannot
prove any of those are safe on live traffic.

The envelope is deep-copied and every unrelated field is carried through
untouched, including fields this code does not recognise. `version` is source
data: the legacy skills assumed a literal `"2.0"`, and forcing that onto a live
cache-bust version would silently invalidate a tenant's whole cache.

A refusal is the product here. `build_candidate` raises `ValueError` on any shape
it cannot construct exactly; it never repairs an input into something adjacent
and returns it as though that had been asked for. It also never marks anything
validated — that requires the server lint in the Codex adapter.
"""

from __future__ import annotations

import copy
import hashlib
import json

__all__ = [
    "build_candidate",
    "baseline_hash",
    "canonical_json",
    "CANON_VERSION",
    "MAX_TTL_SECONDS",
    "CACHE_KEY_ELEMENTS",
]

# The copilot branch's canonical.js normalization contract, preserved: recursive
# object-key sort, array order kept, no whitespace. Same bytes, same digest.
CANON_VERSION = 1

# A day. Above this a cache entry outlives most operators' mental model of
# "fresh", and the preserved eval corpus treats it as a failure, so the domain
# refuses rather than proposing something the gate would reject.
MAX_TTL_SECONDS = 86400

CACHE_KEY_ELEMENTS = (
    "userId",
    "userRole",
    "standardizedSql",
    "statement",
    "catalog",
    "schema",
    "tables",
    "columns",
    "warehouse",
    "tenantId",
)

_TABLE_OPERATORS = ("includes", "includesAny")
_FORBIDDEN_ACTION_KEYS = ("deny", "deleteCache", "invalidateRules", "block", "reject")

# Allowlists, not denylists. An unrecognised key means the caller is asking for
# behaviour this builder has not reasoned about, and the answer to that is no.
_ALLOWED_RULE_KEYS = frozenset(
    {"id", "name", "priority", "mode", "enabled", "description", "tags", "respectSqlHints",
     "conditions", "actions"}
)
_ALLOWED_CONDITION_KEYS = frozenset({"statementType", "tables"})
_ALLOWED_ACTION_KEYS = frozenset({"cache", "cacheKeyElements", "version"})
_ALLOWED_CACHE_KEYS = frozenset({"ttlSeconds", "staleWhileRevalidate"})


def _reject(message: str) -> None:
    raise ValueError(message)


def _require_positive_ttl(ttl_seconds: object) -> int:
    if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int):
        _reject(
            f"ttl_seconds must be an integer, got {ttl_seconds!r} ({type(ttl_seconds).__name__})"
        )
    if ttl_seconds <= 0:
        _reject(
            f"ttl_seconds must be positive, got {ttl_seconds}; turning caching off is a behaviour "
            "change this domain does not propose"
        )
    if ttl_seconds > MAX_TTL_SECONDS:
        _reject(
            f"ttl_seconds {ttl_seconds} exceeds the supported maximum {MAX_TTL_SECONDS}; propose a "
            "shorter lifetime or raise the maximum deliberately"
        )
    return int(ttl_seconds)


def _defaults_of(envelope: dict) -> dict:
    defaults = envelope.get("defaults")
    return defaults if isinstance(defaults, dict) else {}


def _effective_ttl(cache: dict, defaults: dict) -> tuple[int | None, str | None]:
    """Resolve the TTL a rule actually runs with, through envelope defaults."""
    for value, source in ((cache.get("ttlSeconds"), "the rule"), (defaults.get("ttlSeconds"), "envelope defaults")):
        if value is None:
            continue
        if isinstance(value, bool) or not isinstance(value, int):
            _reject(f"ttlSeconds on {source} is not an integer: {value!r}")
        return value, source
    return None, None


def _require_envelope(baseline: object, tenant_id: str) -> dict:
    if not isinstance(baseline, dict):
        _reject(f"baseline must be a rules envelope dict, got {type(baseline).__name__}")
    if not isinstance(tenant_id, str) or not tenant_id.strip():
        _reject("tenant_id must be a non-empty string")
    if baseline.get("tenantId") != tenant_id:
        _reject(
            f"baseline tenantId {baseline.get('tenantId')!r} does not match the bound tenant "
            f"{tenant_id!r}; refusing to build a cross-tenant candidate"
        )
    rules = baseline.get("rules")
    if not isinstance(rules, list):
        _reject("baseline has no 'rules' list; refusing to build on a malformed envelope")
    ids: list[str] = []
    for index, rule in enumerate(rules):
        if not isinstance(rule, dict):
            _reject(f"baseline rule at index {index} is not an object")
        rule_id = rule.get("id")
        if not isinstance(rule_id, str) or not rule_id.strip():
            _reject(f"baseline rule at index {index} has no usable string id")
        ids.append(rule_id)
    duplicates = sorted({rule_id for rule_id in ids if ids.count(rule_id) > 1})
    if duplicates:
        _reject(
            f"baseline contains duplicate rule ids {duplicates}; which rule a change applies to is "
            "ambiguous, so no candidate can be built from it"
        )
    return baseline


def _edit_ttl(candidate: dict, rule_id: str, ttl_seconds: int, defaults: dict) -> None:
    targets = [rule for rule in candidate["rules"] if rule.get("id") == rule_id]
    if not targets:
        _reject(f"no rule with id {rule_id!r} in the baseline; pass new_rule to add one instead")
    rule = targets[0]

    if rule.get("enabled", True) is False:
        _reject(
            f"rule {rule_id!r} is disabled; enabling it is a behaviour change beyond a TTL edit"
        )
    actions = rule.get("actions")
    if not isinstance(actions, dict):
        _reject(f"rule {rule_id!r} has no actions object to edit")
    cache = actions.get("cache")
    if not isinstance(cache, dict):
        _reject(
            f"rule {rule_id!r} has no cache action; creating caching where none existed is an "
            "addition, not a TTL edit"
        )
    if actions.get("deleteCache") or rule.get("invalidateRules") or actions.get("invalidateRules"):
        _reject(
            f"rule {rule_id!r} is an invalidation or cache-bust rule; this domain does not rewrite "
            "invalidation behaviour"
        )
    for key in ("deny", "block", "reject"):
        if actions.get(key):
            _reject(f"rule {rule_id!r} carries a {key!r} action; deny rules are out of scope")
    baseline_ttl, source = _effective_ttl(cache, defaults)
    if baseline_ttl is None:
        _reject(
            f"rule {rule_id!r} has no resolvable current ttlSeconds (neither the rule nor envelope "
            "defaults supply an integer), so there is no TTL to edit"
        )
    if baseline_ttl <= 0:
        _reject(
            f"rule {rule_id!r} currently has an effective ttlSeconds of {baseline_ttl} from "
            f"{source}, which means the cache is bypassed for it. Turning caching on is a "
            "behaviour change, not a TTL edit"
        )
    cache["ttlSeconds"] = ttl_seconds


def _validate_addition(
    new_rule: dict, rule_id: str, ttl_seconds: int, existing_ids: set[str], defaults: dict
) -> dict:
    if not isinstance(new_rule, dict):
        _reject(f"new_rule must be an object, got {type(new_rule).__name__}")
    rule = copy.deepcopy(new_rule)

    unknown = sorted(set(rule) - _ALLOWED_RULE_KEYS)
    if unknown:
        _reject(
            f"new_rule carries unsupported key(s) {unknown}; this builder only constructs rules "
            f"from {sorted(_ALLOWED_RULE_KEYS)} and will not pass through fields it has not "
            "reasoned about"
        )

    if rule.get("id") != rule_id:
        _reject(f"new_rule id {rule.get('id')!r} does not match rule_id {rule_id!r}")
    if rule_id in existing_ids:
        _reject(f"rule id {rule_id!r} already exists in the baseline; ids must be unique")
    if not isinstance(rule.get("priority"), int) or isinstance(rule.get("priority"), bool):
        _reject(f"new_rule priority must be an integer, got {rule.get('priority')!r}")

    mode = rule.get("mode", "all")
    if mode != "all":
        _reject(
            f"new_rule mode {mode!r} is not supported for additions; 'either' ORs the conditions "
            "together and widens the rule beyond the tables it names"
        )
    if rule.get("enabled", True) is not True:
        _reject("new_rule must be enabled; proposing a rule that does nothing is not a change")

    conditions = rule.get("conditions")
    if not isinstance(conditions, dict) or not conditions:
        _reject("new_rule requires explicit conditions; an empty condition set matches everything")
    unknown = sorted(set(conditions) - _ALLOWED_CONDITION_KEYS)
    if unknown:
        _reject(
            f"new_rule conditions carry unsupported key(s) {unknown}; an addition is scoped by "
            f"{sorted(_ALLOWED_CONDITION_KEYS)} only"
        )

    statement = conditions.get("statementType")
    if not isinstance(statement, dict) or list(statement) != ["equals"]:
        _reject(
            "new_rule conditions.statementType must be exactly {'equals': 'SELECT'}; other "
            "operators cannot be statically confirmed to exclude writes"
        )
    if statement["equals"] != "SELECT":
        _reject(
            f"new_rule caches statementType {statement['equals']!r}; only SELECT additions are "
            "supported"
        )

    tables = conditions.get("tables")
    if not isinstance(tables, dict):
        _reject("new_rule conditions.tables must be an operator object naming explicit tables")
    operators = [op for op in tables if op in _TABLE_OPERATORS]
    if list(tables) != operators or len(operators) != 1:
        _reject(
            f"new_rule conditions.tables must use exactly one of {list(_TABLE_OPERATORS)}, got "
            f"{list(tables)}"
        )
    # The two operators take different operand shapes, and accepting either shape
    # for either operator would let a swapped pair through as though it meant
    # what it says: `includes` names one table, `includesAny` lists several.
    operator = operators[0]
    raw = tables[operator]
    if operator == "includes":
        if not isinstance(raw, str):
            _reject(
                f"new_rule conditions.tables.includes must name a single table as a string, got "
                f"{type(raw).__name__}; use includesAny for several"
            )
        names = [raw]
    else:
        if not isinstance(raw, list):
            _reject(
                f"new_rule conditions.tables.includesAny must be a list of table names, got "
                f"{type(raw).__name__}; use includes for a single table"
            )
        names = raw
    if not names:
        _reject("new_rule conditions.tables names no tables")
    for name in names:
        if not isinstance(name, str) or not name.strip():
            _reject(f"new_rule conditions.tables holds a blank or non-string table name: {name!r}")

    if rule.get("invalidateRules"):
        _reject("new_rule may not declare invalidateRules; invalidation authoring is out of scope")

    actions = rule.get("actions")
    if not isinstance(actions, dict):
        _reject(
            "new_rule requires an explicit actions object; this builder does not invent the "
            "actions a caller omitted"
        )
    unknown = sorted(set(actions) - _ALLOWED_ACTION_KEYS)
    if unknown:
        _reject(
            f"new_rule actions carry unsupported key(s) {unknown}; supported action keys are "
            f"{sorted(_ALLOWED_ACTION_KEYS)}"
        )
    for key in _FORBIDDEN_ACTION_KEYS:
        if actions.get(key):
            _reject(f"new_rule actions.{key} is not supported; only cache additions are in scope")

    cache = actions.get("cache")
    if not isinstance(cache, dict):
        _reject("new_rule requires an explicit actions.cache object naming its own ttlSeconds")
    unknown = sorted(set(cache) - _ALLOWED_CACHE_KEYS)
    if unknown:
        _reject(
            f"new_rule actions.cache carries unsupported key(s) {unknown}; supported cache keys "
            f"are {sorted(_ALLOWED_CACHE_KEYS)}"
        )
    declared = cache.get("ttlSeconds")
    if declared is None:
        _reject(
            "new_rule actions.cache must declare ttlSeconds explicitly; a rule whose lifetime was "
            "filled in for it is a rule nobody wrote"
        )
    # Validated before the comparison, not after: `True == 1` in Python, so a
    # boolean TTL would otherwise agree with a requested ttl_seconds of 1.
    _require_positive_ttl(declared)
    if declared != ttl_seconds:
        _reject(
            f"new_rule actions.cache.ttlSeconds is {declared!r} but ttl_seconds is {ttl_seconds}; "
            "the requested change and the rule must agree"
        )

    _require_no_isolation_reduction(actions, defaults)
    return rule


def _require_no_isolation_reduction(actions: dict, defaults: dict) -> None:
    """A rule may add cache-key elements, never drop the ones defaults supply.

    Omitting `cacheKeyElements` inherits the defaults, which is fine. Listing a
    subset of them silently removes isolation the envelope had — the one shape a
    static review must never wave through.
    """
    elements = actions.get("cacheKeyElements")
    if elements is None:
        return
    if not isinstance(elements, list) or not elements:
        _reject("new_rule actions.cacheKeyElements must be a non-empty list when supplied")
    invalid = [e for e in elements if e not in CACHE_KEY_ELEMENTS]
    if invalid:
        _reject(
            f"new_rule actions.cacheKeyElements contains unsupported value(s) {invalid!r}; "
            f"supported values are {list(CACHE_KEY_ELEMENTS)}"
        )
    inherited = defaults.get("cacheKeyElements")
    if not isinstance(inherited, list):
        return
    dropped = [e for e in inherited if e not in elements]
    if dropped:
        _reject(
            f"new_rule actions.cacheKeyElements omits {dropped!r}, which envelope defaults supply. "
            "That removes cache isolation the envelope already had; supplied isolation is preserved, "
            "never inferred away"
        )


def build_candidate(
    baseline: dict,
    *,
    tenant_id: str,
    rule_id: str,
    ttl_seconds: int,
    new_rule: dict | None = None,
) -> dict:
    """Return a complete candidate envelope containing exactly one change.

    With `new_rule` omitted this edits the cache TTL of the existing rule
    `rule_id`. With `new_rule` supplied it appends that rule, which must be a
    narrowly scoped SELECT cache rule whose id is `rule_id`.

    Raises `ValueError` for every unsupported shape. The returned dict carries no
    status, validation or preview: those come from the server, not from here.
    """
    if not isinstance(rule_id, str) or not rule_id.strip():
        _reject("rule_id must be a non-empty string")
    ttl = _require_positive_ttl(ttl_seconds)
    _require_envelope(baseline, tenant_id)

    candidate = copy.deepcopy(baseline)
    if new_rule is None:
        _edit_ttl(candidate, rule_id, ttl, _defaults_of(candidate))
    else:
        existing_ids = {rule["id"] for rule in candidate["rules"]}
        candidate["rules"].append(
            _validate_addition(new_rule, rule_id, ttl, existing_ids, _defaults_of(candidate))
        )
    return candidate


def _assert_json_domain(value: object, path: str = "$") -> None:
    if isinstance(value, bool) or value is None or isinstance(value, str):
        return
    if isinstance(value, int):
        return
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            _reject(f"{path} is {value!r}; a hash input must be finite JSON")
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _assert_json_domain(item, f"{path}[{index}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                _reject(f"{path} has non-string object key {key!r}; JSON objects are string-keyed")
            _assert_json_domain(item, f"{path}.{key}")
        return
    _reject(f"{path} is a {type(value).__name__}, which is not JSON")


def canonical_json(value: dict | list) -> str:
    """Serialize with recursively sorted object keys and array order retained."""
    _assert_json_domain(value)
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    )


def baseline_hash(envelope: dict) -> str:
    """SHA-256 of the canonical serialization, for detecting baseline drift.

    Rule order is part of the hash: priority order is semantically meaningful, so
    a reordering is a change even when every rule object is identical.
    """
    if not isinstance(envelope, dict):
        _reject(f"envelope must be a dict, got {type(envelope).__name__}")
    return hashlib.sha256(canonical_json(envelope).encode("utf-8")).hexdigest()
