"""Typed evidence, finding and proposal records.

Pure Python: stdlib only, no transport, no I/O, no third-party imports. Every
record validates its own enumerations and identifiers at construction time and
raises `ValueError` rather than accepting a value the rest of the system would
have to guess about later. Silent degradation is the failure mode this package
exists to prevent, so nothing here has a "safe" default that hides a missing
input.

Dataclasses are keyword-only so the documented field order on the build board
survives even though some fields are required and some are not.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from datetime import date

__all__ = [
    "EVIDENCE_STATUSES",
    "SEVERITIES",
    "CONFIDENCES",
    "PROPOSAL_STATUSES",
    "Evidence",
    "Finding",
    "Proposal",
]

EVIDENCE_STATUSES = ("complete", "partial", "unavailable")
SEVERITIES = ("info", "warning", "high")
CONFIDENCES = ("low", "medium", "high")
PROPOSAL_STATUSES = ("draft", "invalid", "validated", "stale")


def _require_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a non-empty string, got {value!r}")
    return value


def _require_choice(value: object, allowed: tuple[str, ...], label: str) -> str:
    if value not in allowed:
        raise ValueError(f"{label} must be one of {list(allowed)}, got {value!r}")
    return str(value)


def _require_utc_date(value: object, label: str) -> date:
    """Accept only a real UTC calendar date written as YYYY-MM-DD.

    `date.fromisoformat` in 3.12 also accepts `YYYYMMDD` and week dates, so the
    literal shape is checked first. Triage reproduction 10 recorded the legacy
    Node path accepting `2026-02-31`; this is the control for that gap.
    """
    _require_text(value, label)
    text = str(value)
    if len(text) != 10 or text[4] != "-" or text[7] != "-":
        raise ValueError(f"{label} must be a UTC date formatted YYYY-MM-DD, got {text!r}")
    try:
        return date.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(f"{label} is not a real calendar date: {text!r}") from exc


def _require_str_list(value: object, label: str) -> list[str]:
    if not isinstance(value, list):
        raise ValueError(f"{label} must be a list, got {type(value).__name__}")
    for item in value:
        _require_text(item, f"{label} entry")
    return list(value)


def _require_mapping(value: object, label: str) -> dict:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a dict, got {type(value).__name__}")
    return value


@dataclass(kw_only=True)
class Evidence:
    """One retrieval from one upstream tool, with its coverage stated.

    `status` is required and has no default: a caller that does not know whether
    the retrieval was complete may not claim that it was. `start_date` is
    inclusive and `end_date` is exclusive, both UTC calendar dates.
    """

    id: str
    tenant_id: str
    start_date: str
    end_date: str
    source_tool: str
    arguments: dict = field(default_factory=dict)
    retrieved_at: str
    status: str
    data: dict = field(default_factory=dict)
    limitations: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        _require_text(self.id, "Evidence.id")
        _require_text(self.tenant_id, "Evidence.tenant_id")
        _require_text(self.source_tool, "Evidence.source_tool")
        _require_text(self.retrieved_at, "Evidence.retrieved_at")
        start = _require_utc_date(self.start_date, "Evidence.start_date")
        end = _require_utc_date(self.end_date, "Evidence.end_date")
        if end <= start:
            raise ValueError(
                "Evidence.end_date is exclusive and must be after start_date: "
                f"{self.start_date!r}..{self.end_date!r}"
            )
        self.status = _require_choice(self.status, EVIDENCE_STATUSES, "Evidence.status")
        _require_mapping(self.arguments, "Evidence.arguments")
        _require_mapping(self.data, "Evidence.data")
        _require_str_list(self.limitations, "Evidence.limitations")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "tenant_id": self.tenant_id,
            "start_date": self.start_date,
            "end_date": self.end_date,
            "source_tool": self.source_tool,
            "arguments": copy.deepcopy(self.arguments),
            "retrieved_at": self.retrieved_at,
            "status": self.status,
            "data": copy.deepcopy(self.data),
            "limitations": list(self.limitations),
        }


@dataclass(kw_only=True)
class Finding:
    """A conclusion that names the evidence it rests on.

    `evidence_ids` may not be empty. A finding nobody can trace back to a
    retrieval is an assertion, and this system does not publish assertions.
    """

    id: str
    tenant_id: str
    kind: str
    severity: str
    confidence: str
    evidence_ids: list[str]
    explanation: str
    next_step: str

    def __post_init__(self) -> None:
        _require_text(self.id, "Finding.id")
        _require_text(self.tenant_id, "Finding.tenant_id")
        _require_text(self.kind, "Finding.kind")
        self.severity = _require_choice(self.severity, SEVERITIES, "Finding.severity")
        self.confidence = _require_choice(self.confidence, CONFIDENCES, "Finding.confidence")
        _require_str_list(self.evidence_ids, "Finding.evidence_ids")
        if not self.evidence_ids:
            raise ValueError("Finding.evidence_ids must cite at least one evidence record")
        _require_text(self.explanation, "Finding.explanation")
        _require_text(self.next_step, "Finding.next_step")

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "tenant_id": self.tenant_id,
            "kind": self.kind,
            "severity": self.severity,
            "confidence": self.confidence,
            "evidence_ids": list(self.evidence_ids),
            "explanation": self.explanation,
            "next_step": self.next_step,
        }


@dataclass(kw_only=True)
class Proposal:
    """A candidate envelope that has not been applied.

    `validated` is not a label the domain may apply to itself. It is accepted
    only when a server validation payload is attached and that payload reports
    no errors, so a proposal cannot read as validated on the strength of local
    reasoning alone.
    """

    tenant_id: str
    baseline_hash: str
    candidate: dict
    rule_id: str
    evidence_ids: list[str] = field(default_factory=list)
    status: str = "draft"
    validation: dict | None = None
    preview: dict | None = None
    limitations: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        _require_text(self.tenant_id, "Proposal.tenant_id")
        _require_text(self.baseline_hash, "Proposal.baseline_hash")
        _require_text(self.rule_id, "Proposal.rule_id")
        _require_mapping(self.candidate, "Proposal.candidate")
        _require_str_list(self.evidence_ids, "Proposal.evidence_ids")
        _require_str_list(self.limitations, "Proposal.limitations")
        self.status = _require_choice(self.status, PROPOSAL_STATUSES, "Proposal.status")
        if self.validation is not None:
            _require_mapping(self.validation, "Proposal.validation")
        if self.preview is not None:
            _require_mapping(self.preview, "Proposal.preview")
        if self.status == "validated":
            self._require_clean_server_validation()

    def _require_clean_server_validation(self) -> None:
        if self.validation is None:
            raise ValueError(
                "Proposal.status 'validated' requires a server validation payload; "
                "the domain does not validate a candidate by itself"
            )
        errors = self.validation.get("errors", [])
        if not isinstance(errors, list):
            raise ValueError("Proposal.validation['errors'] must be a list")
        if errors:
            raise ValueError(
                f"Proposal.status 'validated' contradicts {len(errors)} lint error(s)"
            )

    def to_dict(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "baseline_hash": self.baseline_hash,
            "candidate": copy.deepcopy(self.candidate),
            "rule_id": self.rule_id,
            "evidence_ids": list(self.evidence_ids),
            "status": self.status,
            "validation": copy.deepcopy(self.validation),
            "preview": copy.deepcopy(self.preview),
            "limitations": list(self.limitations),
        }
