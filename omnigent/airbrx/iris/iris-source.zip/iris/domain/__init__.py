"""Iris evidence domain: pure Python, stdlib only, no transport.

Everything here is a deterministic function over plain data. Nothing in this
package opens a socket, reads a file, or holds state between calls, so the
adapter can call it with fixtures in a test and with live evidence in
production and get the same answer from the same input.

The consuming adapter is expected to use:

    from iris.domain import (
        Evidence, Finding, Proposal,      # models
        summarize_counts,                 # metrics
        audit_rules,                      # audit
        build_candidate, baseline_hash,   # proposals
    )
"""

from iris.domain.audit import (
    CACHE_KEY_ELEMENTS,
    STATIC_ONLY_NOTE,
    SUPPORTED_MODES,
    SUPPORTED_SET_OPERATORS,
    audit_rules,
)
from iris.domain.metrics import summarize_counts
from iris.domain.models import (
    CONFIDENCES,
    EVIDENCE_STATUSES,
    PROPOSAL_STATUSES,
    SEVERITIES,
    Evidence,
    Finding,
    Proposal,
)
from iris.domain.proposals import (
    CANON_VERSION,
    MAX_TTL_SECONDS,
    baseline_hash,
    build_candidate,
    canonical_json,
)

__all__ = [
    "Evidence",
    "Finding",
    "Proposal",
    "EVIDENCE_STATUSES",
    "SEVERITIES",
    "CONFIDENCES",
    "PROPOSAL_STATUSES",
    "summarize_counts",
    "audit_rules",
    "CACHE_KEY_ELEMENTS",
    "SUPPORTED_SET_OPERATORS",
    "SUPPORTED_MODES",
    "STATIC_ONLY_NOTE",
    "build_candidate",
    "baseline_hash",
    "canonical_json",
    "CANON_VERSION",
    "MAX_TTL_SECONDS",
]
