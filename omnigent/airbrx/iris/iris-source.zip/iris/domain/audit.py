"""Conservative static audit of a rules envelope.

This module reads configuration. It never observes traffic, so it reports
*intent* and the questions that intent raises — never a runtime guarantee. The
distinction matters because the cheapest way to make a security tool useless is
to let it answer "no problem found" when what it means is "I could not tell".

Three rules keep that honest:

1. **Unsupported semantics cannot pass.** A condition operator this checker
   cannot evaluate makes the rule's scope unknown, and an unknown scope is
   reported, not assumed narrow. Triage reproduction 1 recorded the legacy
   scorer clearing rules on exactly this path.
2. **Unknown sensitivity is a question.** A table with no operator-supplied
   classification produces an open question at low confidence. It is never a
   proven leak, and never a pass either.
3. **A disabled rule is not protection.** Disabled rules are reported as
   present and excluded from every other check, so a disabled bypass rule can
   never look like an active control.

`mode: "either"` ORs the conditions together, so a table condition under it
does not scope the rule to that table. That is why either-mode caching rules
are treated as unscoped.

Naming tables does not bound what a matching statement reads either. A rule
scoped `tables.includes PUBLIC.ORDERS` matches a SELECT that joins
PUBLIC.ORDERS to AUTH_TOKENS, and the cached response then contains both. So a
scoped rule is reported as a possible co-table exposure rather than cleared:
the tables a rule names are a membership test, not a closed universe.
"""

from __future__ import annotations

from typing import Any

from iris.domain.models import Finding

__all__ = [
    "audit_rules",
    "CACHE_KEY_ELEMENTS",
    "SUPPORTED_SET_OPERATORS",
    "SUPPORTED_MODES",
    "STATIC_ONLY_NOTE",
]

CACHE_KEY_ELEMENTS = (
    "userId",
    "userRole",
    "standardizedSql",
    "statement",
    "catalog",
    "schema",
    "tables",
    "columns",
    "warehouse",
    "tenantId",
)
SUPPORTED_SET_OPERATORS = ("equals", "in", "includes", "includesAny", "includesAll")

# Operators whose match test is "the request's value is among this set", so a
# larger set is a strictly broader rule. `includesAll` is deliberately absent:
# it is conjunctive, so includesAll[a,b] holds the larger set while matching
# strictly fewer statements than includes[a].
MEMBERSHIP_OPERATORS = ("equals", "in", "includes", "includesAny")
SUPPORTED_MODES = ("all", "either")

STATIC_ONLY_NOTE = (
    "Static configuration review only; this does not observe gateway traffic."
)


class _RuleView:
    """One rule, reduced to the facts the checks need."""

    def __init__(self, index: int, raw: Any, defaults: dict) -> None:
        self.index = index
        self.raw = raw if isinstance(raw, dict) else {}
        self.ok = isinstance(raw, dict)
        self.unsupported: list[str] = []
        if not self.ok:
            self.unsupported.append(f"rule at index {index} is not an object")

        self.id = self.raw.get("id")
        if self.ok and not (isinstance(self.id, str) and self.id.strip()):
            self.unsupported.append(f"rule at index {index} has no usable string id")
            self.id = None
        self.ref = self.id or f"index-{index}"

        self.enabled = self.raw.get("enabled", True) is not False
        self.priority = self.raw.get("priority")
        self.mode = self.raw.get("mode", "all")
        if self.mode not in SUPPORTED_MODES:
            self.unsupported.append(f"unsupported mode {self.mode!r}")

        conditions = self.raw.get("conditions", {})
        self.conditions = conditions if isinstance(conditions, dict) else {}
        if not isinstance(conditions, dict):
            self.unsupported.append("conditions is not an object")
        self.matches_everything = self.ok and not self.conditions

        actions = self.raw.get("actions", {})
        self.actions = actions if isinstance(actions, dict) else {}
        if not isinstance(actions, dict):
            self.unsupported.append("actions is not an object")

        self.delete_cache = bool(self.actions.get("deleteCache"))
        self.invalidate_rules = self.actions.get("invalidateRules") or self.raw.get(
            "invalidateRules"
        ) or []
        if not isinstance(self.invalidate_rules, list):
            self.unsupported.append("invalidateRules is not a list")
            self.invalidate_rules = []

        self.ttl_seconds, self.ttl_source = self._effective_ttl(defaults)
        self.declares_cache = "cache" in self.actions
        self.is_caching = (
            self.declares_cache
            and self.ttl_seconds is not None
            and self.ttl_seconds > 0
            and not self.delete_cache
        )
        self.ttl_indeterminate = self.declares_cache and self.ttl_seconds is None

        self.cache_key_elements = self._effective_key_elements(defaults)
        self.tables, self.tables_evaluable = self._condition_values("tables")
        self.tables_operator = self._sole_operator("tables")
        self.condition_sets = self._all_condition_sets()
        self.unsupported = list(dict.fromkeys(self.unsupported))

    def _effective_ttl(self, defaults: dict) -> tuple[int | None, str | None]:
        cache = self.actions.get("cache")
        if isinstance(cache, dict) and isinstance(cache.get("ttlSeconds"), int) and not isinstance(
            cache.get("ttlSeconds"), bool
        ):
            return cache["ttlSeconds"], "rule"
        if isinstance(cache, dict) and "ttlSeconds" in cache:
            self.unsupported.append(f"actions.cache.ttlSeconds is not an integer: {cache['ttlSeconds']!r}")
            return None, None
        default_ttl = defaults.get("ttlSeconds")
        if isinstance(default_ttl, int) and not isinstance(default_ttl, bool):
            return default_ttl, "defaults"
        return None, None

    def _effective_key_elements(self, defaults: dict) -> list[str] | None:
        elements = self.actions.get("cacheKeyElements", defaults.get("cacheKeyElements"))
        if elements is None:
            return None
        if not isinstance(elements, list):
            self.unsupported.append("cacheKeyElements is not a list")
            return None
        return [str(item) for item in elements]

    def _sole_operator(self, key: str) -> str | None:
        raw = self.conditions.get(key)
        if not isinstance(raw, dict) or len(raw) != 1:
            return None
        operator = next(iter(raw))
        return operator if operator in SUPPORTED_SET_OPERATORS else None

    def _condition_values(self, key: str) -> tuple[set[str] | None, bool]:
        """Return the value set a condition key accepts, or None when unknowable."""
        raw = self.conditions.get(key)
        if raw is None:
            return None, False
        if not isinstance(raw, dict):
            self.unsupported.append(f"conditions.{key} must be an operator object")
            return None, False
        operators = [op for op in raw if op in SUPPORTED_SET_OPERATORS]
        unknown = [op for op in raw if op not in SUPPORTED_SET_OPERATORS]
        if unknown:
            self.unsupported.append(
                f"conditions.{key} uses operator(s) {sorted(unknown)!r} that cannot be "
                "evaluated statically"
            )
        if not operators:
            return None, False
        values: set[str] = set()
        for op in operators:
            value = raw[op]
            items = value if isinstance(value, list) else [value]
            for item in items:
                if not isinstance(item, str) or not item.strip():
                    self.unsupported.append(f"conditions.{key}.{op} holds a non-string value")
                    return None, False
                values.add(item)
        if unknown:
            # A recognised operator alongside an unevaluable one still leaves the
            # effective set unknown; widening is the safe direction.
            return None, False
        return values, True

    def _all_condition_sets(self) -> dict[str, tuple[str, frozenset[str]]] | None:
        """Per condition key, the operator used and the values it names.

        The operator travels with the set because the set alone does not say what
        the rule matches: `equals X`, `includes X` and `includesAll [X, Y]` are
        three different tests. Comparing two rules is only sound when the same
        key uses the same membership-style operator on both sides, so a rule using
        anything else reports no comparable signature at all.
        """
        if self.mode != "all":
            return None
        result: dict[str, tuple[str, frozenset[str]]] = {}
        for key, raw in self.conditions.items():
            if not isinstance(raw, dict) or len(raw) != 1:
                return None
            operator = next(iter(raw))
            if operator not in MEMBERSHIP_OPERATORS:
                return None
            values, evaluable = self._condition_values(key)
            if not evaluable or values is None:
                return None
            result[key] = (operator, frozenset(values))
        return result

    @property
    def scoped_tables(self) -> set[str] | None:
        """Tables this rule is definitely limited to, or None when unscoped."""
        if self.mode != "all":
            return None
        if not self.tables_evaluable:
            return None
        return self.tables


def _finding(
    *,
    tenant_id: str,
    evidence_id: str,
    kind: str,
    ref: str,
    severity: str,
    confidence: str,
    explanation: str,
    next_step: str,
) -> Finding:
    return Finding(
        id=f"{kind}:{ref}",
        tenant_id=tenant_id,
        kind=kind,
        severity=severity,
        confidence=confidence,
        evidence_ids=[evidence_id],
        explanation=explanation,
        next_step=next_step,
    )


def _normalize(name: str) -> str:
    return name.strip().lower()


def audit_rules(
    envelope: dict,
    *,
    tenant_id: str,
    evidence_id: str,
    sensitive_tables: list[str] | None = None,
    never_cache_tables: list[str] | None = None,
) -> list[Finding]:
    """Audit a rules envelope against operator-supplied table classifications.

    Raises ValueError when the envelope is malformed or belongs to a different
    tenant: analysing the wrong tenant's configuration is not a finding, it is a
    mistake that must stop the run.
    """
    if not isinstance(envelope, dict):
        raise ValueError(f"envelope must be a dict, got {type(envelope).__name__}")
    if not isinstance(tenant_id, str) or not tenant_id.strip():
        raise ValueError("tenant_id must be a non-empty string")
    envelope_tenant = envelope.get("tenantId")
    if envelope_tenant != tenant_id:
        raise ValueError(
            f"envelope tenantId {envelope_tenant!r} does not match the bound tenant {tenant_id!r}"
        )
    rules = envelope.get("rules")
    if not isinstance(rules, list):
        raise ValueError("envelope has no 'rules' list; refusing to audit a malformed envelope")

    defaults = envelope.get("defaults")
    defaults = defaults if isinstance(defaults, dict) else {}

    # Comparison is normalized; display keeps the operator's own spelling, so a
    # finding names the table the way the person who classified it wrote it.
    classified_display = sorted({*(sensitive_tables or []), *(never_cache_tables or [])})
    sensitive = {_normalize(t) for t in (sensitive_tables or [])}
    never_cache = {_normalize(t) for t in (never_cache_tables or [])}
    classified = sensitive | never_cache
    has_classifications = bool(classified)

    views = [_RuleView(index, raw, defaults) for index, raw in enumerate(rules)]
    known_ids = {view.id for view in views if view.id}

    findings: list[Finding] = []
    findings.extend(_envelope_findings(tenant_id, evidence_id, defaults, views))

    for view in views:
        findings.extend(
            _rule_findings(
                tenant_id=tenant_id,
                evidence_id=evidence_id,
                view=view,
                known_ids=known_ids,
                sensitive=sensitive,
                never_cache=never_cache,
                classified=classified,
                has_classifications=has_classifications,
                classified_display=classified_display,
            )
        )

    findings.extend(_shadowing_findings(tenant_id, evidence_id, views))
    return _deduplicate_ids(findings)


def _envelope_findings(
    tenant_id: str, evidence_id: str, defaults: dict, views: list[_RuleView]
) -> list[Finding]:
    out: list[Finding] = []
    seen: dict[str, int] = {}
    for view in views:
        if view.id:
            seen[view.id] = seen.get(view.id, 0) + 1
    for rule_id, count in sorted(seen.items()):
        if count > 1:
            out.append(
                _finding(
                    tenant_id=tenant_id,
                    evidence_id=evidence_id,
                    kind="duplicate_rule_id",
                    ref=rule_id,
                    severity="high",
                    confidence="high",
                    explanation=(
                        f"Rule id {rule_id!r} appears {count} times. Which of them applies is "
                        "ambiguous, and a by-id diff cannot describe a change to either."
                    ),
                    next_step="Give each rule a unique id before proposing any change to this envelope.",
                )
            )

    priorities: dict[Any, list[str]] = {}
    for view in views:
        if view.enabled and view.ok and view.priority is not None:
            priorities.setdefault(view.priority, []).append(view.ref)
    for priority, refs in sorted(priorities.items(), key=lambda item: str(item[0])):
        if len(refs) > 1:
            out.append(
                _finding(
                    tenant_id=tenant_id,
                    evidence_id=evidence_id,
                    kind="ambiguous_priority",
                    ref=str(priority),
                    severity="warning",
                    confidence="medium",
                    explanation=(
                        f"Enabled rules {sorted(refs)} share priority {priority}. Precedence "
                        f"between them is not determined by the configuration. {STATIC_ONLY_NOTE}"
                    ),
                    next_step="Renumber so each enabled rule has a distinct priority.",
                )
            )

    default_elements = defaults.get("cacheKeyElements")
    if isinstance(default_elements, list):
        invalid = [e for e in default_elements if e not in CACHE_KEY_ELEMENTS]
        if invalid:
            out.append(
                _finding(
                    tenant_id=tenant_id,
                    evidence_id=evidence_id,
                    kind="invalid_cache_key_element",
                    ref="defaults",
                    severity="high",
                    confidence="high",
                    explanation=(
                        f"envelope defaults.cacheKeyElements contains {invalid!r}, which is outside "
                        f"the ten supported values {list(CACHE_KEY_ELEMENTS)}."
                    ),
                    next_step="Replace the unsupported element(s) with supported ones before any write.",
                )
            )
    return out


def _rule_findings(
    *,
    tenant_id: str,
    evidence_id: str,
    view: _RuleView,
    known_ids: set[str | None],
    sensitive: set[str],
    never_cache: set[str],
    classified: set[str],
    has_classifications: bool,
    classified_display: list[str],
) -> list[Finding]:
    out: list[Finding] = []

    def add(kind, severity, confidence, explanation, next_step, ref=None):
        out.append(
            _finding(
                tenant_id=tenant_id,
                evidence_id=evidence_id,
                kind=kind,
                ref=ref or view.ref,
                severity=severity,
                confidence=confidence,
                explanation=explanation,
                next_step=next_step,
            )
        )

    if view.unsupported:
        add(
            "unsupported_semantics",
            "warning",
            "low",
            f"Rule {view.ref} uses shapes this static checker cannot evaluate: "
            f"{'; '.join(view.unsupported)}. Its effective scope is therefore unknown and it "
            "has not been cleared by any other check here.",
            "Rewrite the rule using supported operators, or review its scope by hand.",
        )

    if not view.ok:
        return out

    if not view.enabled:
        add(
            "disabled_rule",
            "info",
            "high",
            f"Rule {view.ref} is disabled, so it is not in force and is excluded from the "
            "remaining checks. A disabled rule is not an active control.",
            "Enable it or delete it; leaving it disabled makes the intended behaviour unclear.",
        )
        return out

    if view.ttl_indeterminate:
        add(
            "indeterminate_ttl",
            "warning",
            "low",
            f"Rule {view.ref} declares a cache action but neither the rule nor the envelope "
            "defaults supply an integer ttlSeconds, so its effective TTL is unknown.",
            "Set ttlSeconds explicitly on the rule or in envelope defaults.",
        )

    if view.declares_cache and view.ttl_source == "defaults" and view.ttl_seconds is not None:
        severity = "warning" if view.ttl_seconds > 86400 else "info"
        add(
            "inherited_ttl",
            severity,
            "high",
            f"Rule {view.ref} does not set its own ttlSeconds and inherits {view.ttl_seconds} "
            "seconds from envelope defaults. A change to defaults silently changes this rule.",
            "Set ttlSeconds on the rule so its lifetime is visible where the rule is read.",
        )

    if view.cache_key_elements is not None:
        invalid = [e for e in view.cache_key_elements if e not in CACHE_KEY_ELEMENTS]
        if invalid:
            add(
                "invalid_cache_key_element",
                "high",
                "high",
                f"Rule {view.ref} lists cacheKeyElements {invalid!r}, outside the ten supported "
                f"values {list(CACHE_KEY_ELEMENTS)}.",
                "Replace the unsupported element(s); the gateway cannot key on them.",
            )

    dangling = [ref for ref in view.invalidate_rules if ref not in known_ids]
    if dangling:
        add(
            "dangling_invalidation",
            "warning",
            "high",
            f"Rule {view.ref} lists invalidateRules {sorted(dangling)!r}, and no rule in this "
            "envelope has those ids. Those references cannot resolve.",
            "Point the references at existing rule ids, or remove them.",
        )

    if not view.is_caching:
        if view.ttl_seconds == 0 or view.delete_cache or view.invalidate_rules:
            add(
                "invalidation_unverified",
                "info",
                "low",
                f"Rule {view.ref} looks like a cache bypass or invalidation "
                f"(ttlSeconds={view.ttl_seconds}, deleteCache={view.delete_cache}, "
                f"invalidateRules={list(view.invalidate_rules)!r}). Bypassing the cache is not by "
                f"itself evidence that an invalidation occurs. {STATIC_ONLY_NOTE}",
                "Confirm the intended invalidation against runtime evidence before relying on it.",
            )
        return out

    if view.matches_everything:
        add(
            "matches_everything",
            "high",
            "high",
            f"Rule {view.ref} caches with empty conditions, so it matches every statement, "
            "including statements against tables nobody intended to cache.",
            "Add explicit statementType and tables conditions scoping the rule to its intent.",
        )

    tables = view.scoped_tables
    if tables is None:
        if has_classifications:
            add(
                "unscoped_table_exposure",
                "high",
                "low",
                f"Rule {view.ref} caches but its table scope cannot be determined statically "
                f"(mode={view.mode!r}), so the operator-classified tables cannot be ruled out of "
                f"its match set. This is an unresolved question, not an observed leak. {STATIC_ONLY_NOTE}",
                "Scope the rule with an explicit tables condition under mode 'all', then re-audit.",
            )
        else:
            add(
                "unknown_sensitivity",
                "warning",
                "low",
                f"Rule {view.ref} caches but its table scope cannot be determined statically and "
                "no table classifications were supplied, so nothing here can say what it caches.",
                "Supply sensitive_tables / never_cache_tables and scope the rule explicitly.",
            )
        return out

    normalized = {_normalize(t): t for t in tables}

    hit_never = sorted(original for key, original in normalized.items() if key in never_cache)
    if hit_never:
        add(
            "never_cache_violation",
            "high",
            "high",
            f"Rule {view.ref} caches {hit_never!r}, which the operator classified as never-cache. "
            "User isolation does not change that classification.",
            "Remove those tables from the rule's scope, or withdraw the never-cache classification.",
        )

    hit_sensitive = sorted(original for key, original in normalized.items() if key in sensitive)
    if hit_sensitive:
        keys = view.cache_key_elements or []
        if "userId" not in keys:
            add(
                "isolation",
                "high",
                "high",
                f"Rule {view.ref} caches operator-classified sensitive tables {hit_sensitive!r} "
                f"with cacheKeyElements {keys or 'unset (envelope defaults apply)'}, which does "
                "not include userId. As configured, one user's cached response would be reused for "
                f"another user's matching request: a configuration risk. {STATIC_ONLY_NOTE} — "
                "whether it has happened is not established here.",
                "Add userId to cacheKeyElements, or stop caching these tables.",
            )

    if has_classifications and view.tables_operator in ("includes", "includesAny", "includesAll"):
        add(
            "co_table_exposure",
            "warning",
            "low",
            f"Rule {view.ref} is scoped by tables.{view.tables_operator}, which matches any "
            f"statement touching {sorted(tables)!r} — including one that also joins a classified "
            f"table such as {classified_display!r}. The named tables are not the closed set of tables a "
            f"matching statement can read, so the classified ones are not ruled out of the cached "
            f"response. {STATIC_ONLY_NOTE}",
            "Constrain the rule further (for example on columns or standardizedSql), or accept that "
            "matching statements may read classified tables and key the entry per user.",
        )

    unclassified = sorted(original for key, original in normalized.items() if key not in classified)
    if unclassified:
        add(
            "unknown_sensitivity",
            "warning",
            "low",
            f"Rule {view.ref} caches {unclassified!r}, for which no sensitivity classification was "
            "supplied. Whether caching them is safe is an open question here, not a pass.",
            "Classify these tables as sensitive, never-cache, or ordinary, then re-audit.",
        )
    return out


def _shadowing_findings(tenant_id: str, evidence_id: str, views: list[_RuleView]) -> list[Finding]:
    """Report an enabled rule whose match set provably contains a lower-precedence one."""
    out: list[Finding] = []
    active = [v for v in views if v.ok and v.enabled and isinstance(v.priority, int)]
    for broad in active:
        for narrow in active:
            if broad is narrow or broad.priority >= narrow.priority:
                continue
            if broad.condition_sets is None or narrow.condition_sets is None:
                continue
            if not set(broad.condition_sets) <= set(narrow.condition_sets):
                continue
            if not all(
                narrow.condition_sets[key][0] == operator and narrow.condition_sets[key][1] <= values
                for key, (operator, values) in broad.condition_sets.items()
            ):
                continue
            out.append(
                _finding(
                    tenant_id=tenant_id,
                    evidence_id=evidence_id,
                    kind="shadowing",
                    ref=f"{broad.ref}>{narrow.ref}",
                    severity="warning",
                    confidence="medium",
                    explanation=(
                        f"Rule {broad.ref} (priority {broad.priority}) matches everything rule "
                        f"{narrow.ref} (priority {narrow.priority}) matches and takes precedence, "
                        f"so {narrow.ref} may never apply. {STATIC_ONLY_NOTE}"
                    ),
                    next_step=(
                        f"Narrow {broad.ref}, or move {narrow.ref} to a higher precedence "
                        "(lower priority number)."
                    ),
                )
            )
    return out


def _deduplicate_ids(findings: list[Finding]) -> list[Finding]:
    """Keep ids unique without reordering; order is the audit's reading order."""
    seen: dict[str, int] = {}
    for item in findings:
        count = seen.get(item.id, 0)
        seen[item.id] = count + 1
        if count:
            item.id = f"{item.id}#{count + 1}"
    return findings
