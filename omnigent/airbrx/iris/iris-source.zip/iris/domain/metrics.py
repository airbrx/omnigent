"""Exact cache arithmetic over normalized period records.

The model ranks and explains; this module calculates. Two properties are
load-bearing and easy to lose by accident:

**The hit rate is request-weighted.** It is total hits over total hits plus
misses across the whole period, never the mean of per-day percentages. A day
with two requests and a day with a thousand do not get equal say.

**An unknown stays unknown.** A zero denominator produces `None` and an entry in
`unknowns`, never `0.0`. A field absent from any single period makes the total
for that field unknown rather than a sum of the periods that happened to report
it. Nothing here produces dollars: there is no cost basis in this input, so a
record carrying one is rejected rather than carried along where a caller might
later multiply by it.

An empty input is the sharpest version of that rule: zero records means nothing was measured, so every total comes back `None` and unknown rather than a confident zero.

Input contract: a list of dicts, one per **disjoint** period, each with
`cache_hits`, `cache_misses` and optionally `executions`, `warehouse_time_ms`,
`start_date`/`end_date` (UTC, end exclusive) and `requests`. Counts are
non-negative integers; `bool` is not an integer for this purpose. Overlapping
periods are rejected, because adding two overlapping summaries double-counts
the intersection. When periods carry no dates, disjointness cannot be checked
and that inability is reported in `limitations` instead of assumed away.
"""

from __future__ import annotations

from datetime import date

__all__ = ["summarize_counts", "REQUIRED_COUNT_KEYS", "OPTIONAL_COUNT_KEYS"]

REQUIRED_COUNT_KEYS = ("cache_hits", "cache_misses")
OPTIONAL_COUNT_KEYS = ("executions", "warehouse_time_ms")

_FORBIDDEN_KEY_MARKERS = ("cost", "dollar", "usd", "saving", "price", "spend")

_WAREHOUSE_NOTE = (
    "warehouse_time_ms is summed from source-reported values only; it is not a "
    "dollar figure, not a savings estimate, and not a measured warehouse saving "
    "unless the source field itself measures warehouse time."
)
_NO_RECORDS_NOTE = (
    "No period records were supplied, so nothing was measured; every total is "
    "unknown rather than zero."
)
_DISJOINT_NOTE = (
    "Period records carried no start_date/end_date, so disjointness could not be "
    "verified; totals assume the caller supplied non-overlapping periods."
)


def _require_count(value: object, label: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{label} must be an integer count, got a bool")
    if isinstance(value, float):
        if not value.is_integer():
            raise ValueError(f"{label} must be a whole count, got {value!r}")
        value = int(value)
    if not isinstance(value, int):
        raise ValueError(f"{label} must be an integer count, got {type(value).__name__}")
    if value < 0:
        raise ValueError(f"{label} must not be negative, got {value}")
    return value


def _require_utc_date(value: object, label: str) -> date:
    if not isinstance(value, str) or len(value) != 10 or value[4] != "-" or value[7] != "-":
        raise ValueError(f"{label} must be a UTC date formatted YYYY-MM-DD, got {value!r}")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"{label} is not a real calendar date: {value!r}") from exc


def _period_of(record: dict, index: int) -> tuple[date, date] | None:
    start = record.get("start_date")
    end = record.get("end_date")
    if start is None and end is None:
        return None
    if start is None or end is None:
        raise ValueError(
            f"record[{index}] supplies only one of start_date/end_date; a period needs both"
        )
    start_date = _require_utc_date(start, f"record[{index}].start_date")
    end_date = _require_utc_date(end, f"record[{index}].end_date")
    if end_date <= start_date:
        raise ValueError(
            f"record[{index}] end_date is exclusive and must be after start_date: {start!r}..{end!r}"
        )
    return start_date, end_date


def _reject_forbidden_keys(record: dict, index: int) -> None:
    for key in record:
        if not isinstance(key, str):
            raise ValueError(f"record[{index}] has a non-string key {key!r}")
        lowered = key.lower()
        if any(marker in lowered for marker in _FORBIDDEN_KEY_MARKERS):
            raise ValueError(
                f"record[{index}] carries cost-bearing field {key!r}; this module never "
                "produces dollars and will not pass a cost basis through"
            )
        if lowered in ("hit_rate", "hitrate", "cache_hit_rate"):
            raise ValueError(
                f"record[{index}] supplies a precomputed {key!r}; rates are calculated from "
                "counts here, never averaged from per-period percentages"
            )


def _assert_disjoint(periods: list[tuple[int, date, date]]) -> None:
    ordered = sorted(periods, key=lambda item: (item[1], item[2]))
    for (left_index, _, left_end), (right_index, right_start, _) in zip(ordered, ordered[1:]):
        if right_start < left_end:
            raise ValueError(
                f"record[{left_index}] and record[{right_index}] cover overlapping periods; "
                "overlapping summaries must not be added together"
            )


def summarize_counts(records: list[dict]) -> dict:
    """Total a list of per-period count records into one honest summary."""
    if not isinstance(records, list):
        raise ValueError(f"records must be a list of period dicts, got {type(records).__name__}")

    cache_hits = 0
    cache_misses = 0
    executions: int | None = 0
    warehouse_time_ms: int | None = 0
    unknowns: list[str] = []
    periods: list[tuple[int, date, date]] = []
    undated = 0

    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ValueError(f"record[{index}] must be a dict, got {type(record).__name__}")
        _reject_forbidden_keys(record, index)

        for key in REQUIRED_COUNT_KEYS:
            if key not in record:
                raise ValueError(f"record[{index}] is missing required count {key!r}")

        hits = _require_count(record["cache_hits"], f"record[{index}].cache_hits")
        misses = _require_count(record["cache_misses"], f"record[{index}].cache_misses")
        cache_hits += hits
        cache_misses += misses

        if "requests" in record:
            stated = _require_count(record["requests"], f"record[{index}].requests")
            if stated != hits + misses:
                raise ValueError(
                    f"record[{index}].requests is {stated} but cache_hits + cache_misses is "
                    f"{hits + misses}; the record is internally inconsistent"
                )

        if "executions" in record:
            value = _require_count(record["executions"], f"record[{index}].executions")
            if executions is not None:
                executions += value
        else:
            executions = None

        if "warehouse_time_ms" in record:
            value = _require_count(record["warehouse_time_ms"], f"record[{index}].warehouse_time_ms")
            if warehouse_time_ms is not None:
                warehouse_time_ms += value
        else:
            warehouse_time_ms = None

        period = _period_of(record, index)
        if period is None:
            undated += 1
        else:
            periods.append((index, period[0], period[1]))

    _assert_disjoint(periods)

    limitations: list[str] = []
    if undated:
        limitations.append(_DISJOINT_NOTE)

    if not records:
        # Nothing was measured. A measured zero and an absent measurement are
        # different answers, so no total may be reported as zero here.
        return {
            "periods": 0,
            "start_date": None,
            "end_date": None,
            "requests": None,
            "cache_hits": None,
            "cache_misses": None,
            "hit_rate": None,
            "hit_rate_denominator": None,
            "executions": None,
            "warehouse_time_ms": None,
            "unknowns": [
                "requests",
                "cache_hits",
                "cache_misses",
                "hit_rate",
                "hit_rate_denominator",
                "executions",
                "warehouse_time_ms",
            ],
            "limitations": [_NO_RECORDS_NOTE],
        }

    requests = cache_hits + cache_misses
    if requests:
        hit_rate: float | None = cache_hits / requests
    else:
        hit_rate = None
        unknowns.append("hit_rate")

    if executions is None:
        unknowns.append("executions")
    if warehouse_time_ms is None:
        unknowns.append("warehouse_time_ms")
    else:
        limitations.append(_WAREHOUSE_NOTE)

    return {
        "periods": len(records),
        "start_date": min(item[1] for item in periods).isoformat() if periods else None,
        "end_date": max(item[2] for item in periods).isoformat() if periods else None,
        "requests": requests,
        "cache_hits": cache_hits,
        "cache_misses": cache_misses,
        "hit_rate": hit_rate,
        "hit_rate_denominator": requests,
        "executions": executions,
        "warehouse_time_ms": warehouse_time_ms,
        "unknowns": unknowns,
        "limitations": limitations,
    }
