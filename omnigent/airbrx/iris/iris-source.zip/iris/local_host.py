"""A conversational Iris you can run on this machine, today.

`omnigent run` cannot host this bundle on the installed build. The spec
validator accepts only `claude_sdk` (underscore) while the runner's harness
registry registers only `claude-sdk` (hyphen), so no value satisfies both and
the server path fails with `harness_spawn_failed`. That is a host defect, not
something Iris can configure around, and the build plan is explicit that we
identify the required host upgrade rather than quietly switch architecture.

The native executor itself is fine. This module drives `ClaudeSDKExecutor`
directly — the same class the Omnigent host would use, with the same four tools,
the same policy boundary and the same read-only evidence path — and gives you a
prompt. What it skips is Omnigent's session lifecycle, artifact delivery and
hosted UI, so it proves the agent works and proves nothing about hosting.

    python -m iris.local_host                     # interactive
    python -m iris.local_host -p "How is this tenant doing?"

Run it with the interpreter that has Omnigent installed, and with `PYTHONPATH`
pointing at the checkout so the tool subprocesses can import Iris:

    export PYTHONPATH="$PWD"
    HOST=~/.local/share/uv/tools/omnigent/bin/python
    "$HOST" -m iris.local_host
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import shutil
import sys
import time
from pathlib import Path
from types import SimpleNamespace

__all__ = ["converse", "main"]

BANNER = """\
Iris — local conversational host (direct native executor)
  tenant : {tenant}
  mode   : {mode}
  model  : {model}
  tools  : {tools}

Read-only. No writes, no deployment, no upstream changes. Type a question, or
'exit' to quit.
"""


def _build(bundle: Path, work: Path):
    """Wire the native executor to exactly the bundle's four Iris tools."""
    from omnigent.inner.claude_sdk_executor import ClaudeSDKExecutor
    from omnigent.spec.parser import parse
    from omnigent.tools.base import ToolContext
    from omnigent.tools.local import load_local_python_tools

    from iris.model_auth import resolve as resolve_model_auth

    spec = parse(bundle)
    tools = load_local_python_tools(spec.local_tools, bundle, srt_available=False)
    registry = {tool.name(): tool for tool in tools}

    model_auth = resolve_model_auth(os.environ)
    os.environ.update(model_auth.passthrough_env())
    for name in model_auth.unset_env():
        os.environ.pop(name, None)

    model = os.environ.get("IRIS_MODEL") or spec.executor.model
    executor = ClaudeSDKExecutor(
        cwd=str(work),
        model=model,
        skills_filter="none",
        **model_auth.executor_kwargs(),
    )

    context = ToolContext(
        task_id="iris-local",
        agent_id="iris",
        workspace=work,
        conversation_id="iris-local",
    )

    async def dispatch(name, args):
        # The registry is the boundary: a tool the bundle did not declare is
        # refused here even if the model asks for it by name.
        if name not in registry:
            return {"error": "Forbidden tool"}
        return json.loads(
            await asyncio.to_thread(registry[name].invoke, json.dumps(args), context)
        )

    async def policy(phase, payload):
        allowed = phase != "PHASE_TOOL_CALL" or payload.get("name") in registry
        return SimpleNamespace(
            action="POLICY_ACTION_ALLOW" if allowed else "POLICY_ACTION_DENY",
            reason="Iris tool boundary",
        )

    executor._tool_executor = dispatch
    executor._policy_evaluator = policy
    return spec, executor, tools, registry, model, model_auth


async def converse(prompts, *, bundle: Path, deadline: float = 300.0) -> int:
    """Run one turn per prompt, printing the model's text as it arrives.

    `prompts` is an iterable of strings; an interactive session passes a
    generator that blocks on input. History is carried between turns so this is
    a conversation, not a series of unrelated questions.
    """
    from omnigent.inner.executor import ExecutorConfig

    # Two constraints shape this path, and both are load-bearing.
    #
    # No symlinks: the host state-root guard rejects any component that is one,
    # and on macOS the default temp directory lives under /var/folders, reached
    # through a /var -> /private/var symlink. A directory beside the bundle
    # resolves cleanly on every platform.
    #
    # Fresh per run: Iris persists budget reservations and findings under the
    # state root, and they are scoped to a conversation. One process is one
    # conversation, so reusing a previous run's state root carries a spent
    # budget into a new session, where it surfaces as an opaque tool failure
    # rather than "budget exhausted".
    root = (bundle.parent / ".iris-local").resolve()
    root.mkdir(mode=0o700, exist_ok=True)
    _prune(root)
    work = root / f"run-{os.getpid()}-{int(time.time())}"
    work.mkdir(mode=0o700)
    spec, executor, tools, registry, model, model_auth = _build(bundle, work)

    print(
        BANNER.format(
            tenant=os.environ.get("IRIS_TENANT_ID", "(unset)"),
            mode="synthetic fixture" if os.environ.get("IRIS_FIXTURE") == "1" else "live read-only",
            model=model,
            tools=", ".join(sorted(registry)),
        ),
        file=sys.stderr,
    )
    for note in model_auth.notes:
        print("  note: " + note, file=sys.stderr)

    schemas = [tool.get_schema()["function"] for tool in tools]
    instructions = spec.instructions or "Read-only Airbrx operations agent."
    history: list[dict] = []
    failures = 0

    for prompt in prompts:
        prompt = prompt.strip()
        if not prompt:
            continue
        history.append({"role": "user", "content": prompt})
        said = []
        used = []
        try:
            async with asyncio.timeout(deadline):
                async for event in executor.run_turn(
                    history, schemas, instructions, ExecutorConfig(model=model)
                ):
                    kind = type(event).__name__
                    if kind == "TextChunk":
                        text = getattr(event, "text", "") or ""
                        said.append(text)
                        print(text, end="", flush=True)
                    elif kind == "ToolCallRequest":
                        name = getattr(event, "name", "?")
                        used.append(name)
                        print(f"\n  · calling {name} …", file=sys.stderr, flush=True)
                    elif kind == "ExecutorError":
                        # Never print the raw SDK error: it can carry source
                        # text and credential-shaped strings.
                        print("\n  · executor error; turn did not complete", file=sys.stderr)
                        failures += 1
        except TimeoutError:
            print(f"\n  · deadline of {deadline:.0f}s reached; answer incomplete", file=sys.stderr)
            failures += 1

        answer = "".join(said)
        if answer:
            history.append({"role": "assistant", "content": answer})
        print("\n", file=sys.stderr)
        if used:
            print(f"  · tools used: {', '.join(used)}\n", file=sys.stderr)

    return 1 if failures else 0


def _prune(root: Path, keep: int = 5) -> None:
    """Keep the last few run directories; they hold reports worth re-reading."""
    runs = sorted((p for p in root.glob("run-*") if p.is_dir()), key=lambda p: p.name)
    for stale in runs[:-keep] if len(runs) > keep else []:
        shutil.rmtree(stale, ignore_errors=True)


def _interactive():
    while True:
        try:
            line = input("iris> ")
        except (EOFError, KeyboardInterrupt):
            print(file=sys.stderr)
            return
        if line.strip().lower() in {"exit", "quit", ":q"}:
            return
        yield line


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Conversational Iris, run locally.")
    parser.add_argument("-p", "--prompt", action="append", default=None,
                        help="run one prompt and exit; repeatable")
    parser.add_argument("--bundle", type=Path, default=None,
                        help="Omnigent bundle directory (default: ./omnigent)")
    parser.add_argument("--deadline", type=float, default=300.0,
                        help="per-turn deadline in seconds (default 300)")
    args = parser.parse_args(argv)

    bundle = (args.bundle or Path.cwd() / "omnigent").resolve()
    if not bundle.is_dir():
        raise SystemExit(f"No bundle at {bundle}. Pass --bundle.")

    prompts = args.prompt if args.prompt else _interactive()
    try:
        return asyncio.run(converse(prompts, bundle=bundle, deadline=args.deadline))
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
