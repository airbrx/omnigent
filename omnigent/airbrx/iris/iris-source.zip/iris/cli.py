"""Offline-first command-line smoke entry point."""

import argparse
import asyncio
import json
from iris.config import Config


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "workflow", choices=["overview", "investigate", "audit", "demo"]
    )
    args = parser.parse_args()

    async def run():
        from iris.tools import Iris

        iris = await Iris(Config.from_env()).start()
        if args.workflow == "demo":
            overview = await iris.overview()
            investigation = await iris.investigate("outcomes")
            audit = await iris.audit()
            finding = next(iter(iris.findings))
            proposal = await iris.propose(
                finding, '{"ttl_seconds":120}', "report-cache"
            )
            return {
                "overview": overview,
                "investigation": investigation,
                "audit": audit,
                "proposal": proposal,
            }
        if args.workflow == "investigate":
            return await iris.investigate("outcomes")
        return await getattr(iris, args.workflow)()

    print(json.dumps(asyncio.run(run()), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
