"""Offline-first command-line smoke entry point."""

import argparse
import asyncio
import json
from iris.config import Config


def _cleanup(days, root):
    """Run the documented 30-day retention and say what it actually did.

    `SCHEMAS.md` and `RUNBOOK.md` both tell an operator to schedule
    `iris.artifacts.cleanup` from the host's retention job, but a retention job
    is a launchd or cron entry and there was no command for one to run. This is
    that command. It changes no deletion logic - `iris.artifacts.cleanup` decides
    what goes, exactly as before.

    The count of directories still present is reported beside the count removed,
    because "removed 3" without a denominator is the shape this codebase refuses
    everywhere else. `remaining` counts run directories that still look like Iris
    runs by name; it is not a claim that each carries a valid manifest, and a
    directory `cleanup` skipped as malformed is counted there too.
    """
    from iris.artifacts import cleanup
    from pathlib import Path

    if days < 1:
        raise SystemExit("--days must be at least 1; 0 would expire everything written before now")
    target = Path(root) if root else Config.from_env().output_dir
    if not target.exists():
        raise SystemExit(f"retention root does not exist: {target}")
    removed = cleanup(target, days=days)
    remaining = [
        run.name
        for tenant in target.glob("*") if not tenant.is_symlink()
        for run in tenant.glob("*") if not run.is_symlink()
    ]
    return {
        "root": str(target),
        "retention_days": days,
        "removed": removed,
        "removed_count": len(removed),
        "remaining_count": len(remaining),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "workflow", choices=["overview", "investigate", "audit", "demo", "cleanup"]
    )
    parser.add_argument(
        "--days", type=int, default=30,
        help="cleanup: delete Iris run directories older than this (default 30)",
    )
    parser.add_argument(
        "--root", default=None,
        help="cleanup: retention root (default: IRIS_OUTPUT_DIR)",
    )
    args = parser.parse_args()

    if args.workflow == "cleanup":
        print(json.dumps(_cleanup(args.days, args.root), indent=2, allow_nan=False))
        return

    async def run():
        from iris.tools import Iris

        iris = await Iris(Config.from_env()).start()
        if args.workflow == "demo":
            overview = await iris.overview()
            investigation = await iris.investigate("outcomes")
            audit = await iris.audit()
            finding = next(iter(iris.findings))
            proposal = await iris.propose(
                finding, '{"ttl_seconds":120}', "report-cache"
            )
            return {
                "overview": overview,
                "investigation": investigation,
                "audit": audit,
                "proposal": proposal,
            }
        if args.workflow == "investigate":
            return await iris.investigate("outcomes")
        return await getattr(iris, args.workflow)()

    print(json.dumps(asyncio.run(run()), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
