"""Readable Markdown view of already-sanitized evidence; JSON stays authoritative."""

import html
import re


def plain(value):
    text = html.escape(str(value)).replace("\n", " ").replace("\r", " ")
    return re.sub(r"([\\`*_{}\[\]()#+.!|>~-])", r"\\\1", text)


def render_report(report):
    lines = ["# Iris report", "", plain(report.get("message", "Read-only evidence.")), "",
             f"Tenant: {plain(report.get('tenant_id', 'unknown'))}", "",
             f"Mode: {plain(report.get('mode', 'unknown'))}", "",
             "Coverage: " + ("incomplete" if report.get("incomplete") else "complete for the collected sources"), ""]
    for key, title in [("metrics", "Metrics"), ("current", "Current period"), ("previous", "Previous period")]:
        metrics = report.get(key)
        if not isinstance(metrics, dict):
            continue
        lines.extend([f"## {title}", "", "| Measure | Value |", "|---|---|"])
        for field, label in [("start_date", "Start UTC (inclusive)"), ("end_date", "End UTC (exclusive)"),
                             ("cache_hits", "Cache hits"), ("cache_misses", "Cache misses"),
                             ("hit_rate_denominator", "Hit-rate denominator"), ("hit_rate", "Request hit rate"),
                             ("executions", "Executions"), ("warehouse_time_ms", "Warehouse time (ms)")]:
            value = metrics.get(field)
            if value is None:
                value = "Unavailable"
            elif field == "hit_rate":
                value = f"{value:.2%}"
            lines.append(f"| {label} | {plain(value)} |")
        lines.append("")
        for limitation in metrics.get("limitations", []):
            lines.extend([plain(limitation), ""])
    if "proposal_status" in report:
        lines.extend(["## Proposal", "", f"Status: {plain(report['proposal_status'])}. No changes applied.", "",
                      "Preview compares configuration; historical impact has not been simulated.", "",
                      "The complete candidate, validation, preview and diff are in report.json and proposal.json when exported.", ""])
    lines.extend(["## Findings", ""])
    for finding in report.get("findings", []):
        lines.extend([f"### {plain(finding.get('kind', 'Finding'))}", "",
                      f"Severity: {plain(finding.get('severity'))}; confidence: {plain(finding.get('confidence'))}.", "",
                      plain(finding.get("explanation", "")), "",
                      "Next step: " + plain(finding.get("next_step", "")), "",
                      "Evidence IDs: " + ", ".join(plain(x) for x in finding.get("evidence_ids", [])), ""])
    if not report.get("findings"):
        lines.extend(["No findings recorded; this is not proof of runtime safety.", ""])
    lines.extend(["## Source coverage", "", "| Evidence ID | Source | UTC period | Status |", "|---|---|---|---|"])
    for evidence in report.get("evidence", []):
        period = f"{evidence.get('start_date', 'unknown')} to {evidence.get('end_date', 'unknown')}"
        lines.append("| " + " | ".join(plain(x) for x in [evidence.get("id"), evidence.get("source_tool"), period, evidence.get("status")]) + " |")
        for limitation in evidence.get("limitations", []):
            lines.append("| " + plain(evidence.get("id")) + " | Limitation | " + plain(limitation) + " | |")
    lines.extend(["", "## Limitations", ""])
    lines.extend("- " + plain(x) for x in report.get("limitations", []))
    lines.extend(["", "Full sanitized source data and exact numeric values are retained in report.json.", ""])
    return "\n".join(lines)
