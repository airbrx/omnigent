"""Account triage: rank the tenants a caller can see, quarantine the rest.

Pure and offline, in the shape `tenants.py` and `watch.py` use: no I/O, no
clock of its own, no model. The caller supplies the tenants it is authorised
for and each one's newest overview capture; this returns ranked rows and
quarantined rows, and nothing else.

Two rules from the design spec are enforced here rather than trusted:

- **Summary rows only.** A row carries figures that rank and reasons that
  quarantine. A report body, evidence, findings or rules never pass through
  — a row is built field by field from a closed list, and
  `FORBIDDEN_ROW_KEYS` names what a test walks the output for.
- **A capture is refused before it is ranked.** The consistency guards
  `ui/app.js` `normalize()` applies at ingest (Q19) apply here too, so a
  capture whose own figures disagree is quarantined as `metrics_disagree`
  instead of being shown as a confident number.

Staleness never quarantines. `age_seconds` is on every ranked row and there
is no threshold: any constant would be an assertion the product has not
earned, the same reasoning that keeps `requests > 0` out of `normalize()`.
"""

from __future__ import annotations

__all__ = ["FORBIDDEN_ROW_KEYS", "QUARANTINE_REASONS", "RANK_FIELDS", "rank"]

#: Keys that must never appear anywhere in the emitted structure. A test walks
#: the output for these; they are the shape of "a report body leaked".
FORBIDDEN_ROW_KEYS = frozenset(
    {
        "evidence",
        "findings",
        "rules",
        "report",
        "overview",
        "audit",
        "message",
        "limitations",
        "budget",
        "proposal",
    }
)

#: In precedence order: when more than one applies, the first wins.
QUARANTINE_REASONS = (
    "tenant_mismatch",
    "unreadable_config",
    "metrics_disagree",
    "incomplete_period",
    "never_collected",
)

#: The figures a ranked row needs as whole counts.
RANK_FIELDS = ("requests", "cache_misses", "hit_rate_denominator", "covered_days", "requested_days")


def _field(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _count(value):
    """A non-negative whole number, or None. `bool` is not a count."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return value if isinstance(value, int) and value >= 0 else None


def _disagreement(metrics) -> str | None:
    """The first guard a capture fails, in normalize()'s own words; None if it passes."""
    if not isinstance(metrics, dict):
        return "the capture has no metrics"
    counts = {key: _count(metrics.get(key)) for key in RANK_FIELDS}
    missing = [key for key, value in counts.items() if value is None]
    if missing:
        return "not a whole count: " + ", ".join(missing)
    hits = _count(metrics.get("cache_hits"))
    rate = metrics.get("hit_rate")
    if rate is not None and (
        isinstance(rate, bool) or not isinstance(rate, (int, float)) or not 0 <= rate <= 1
    ):
        return "the hit rate is not a fraction between 0 and 1"
    if hits is not None and hits > counts["requests"]:
        return "more hits than requests"
    if counts["hit_rate_denominator"] != counts["requests"]:
        return "the hit-rate denominator is not the request count"
    if metrics.get("period_complete") is True and counts["covered_days"] != counts["requested_days"]:
        return "the period is marked complete but not every requested day is covered"
    if (
        rate is not None
        and hits is not None
        and counts["hit_rate_denominator"] > 0
        and abs(rate - hits / counts["hit_rate_denominator"]) > 0.0005
    ):
        return "the stated hit rate is not its own hits over its own denominator"
    return None


def _quarantine(tenant_id, name, reason, detail=None, **extra):
    return {"tenant_id": tenant_id, "name": name, "reason": reason, "detail": detail, **extra}


def _classify(tenant_id, name, note, capture, now):
    """One row for one tenant. Returns ("ranked" | "quarantined", row)."""
    if capture is not None and not isinstance(capture, dict):
        raise ValueError(f"capture for {tenant_id!r} must be a dict or None")
    if capture and "error" not in capture and capture.get("tenant_id") != tenant_id:
        # The Q18/Q21 class. The capture is discarded, not rendered, and the
        # reason names what happened rather than hiding it as "never collected".
        return "quarantined", _quarantine(
            tenant_id,
            name,
            "tenant_mismatch",
            "the newest capture found for this tenant names a different tenant; it was discarded",
        )
    if note:
        return "quarantined", _quarantine(tenant_id, name, "unreadable_config", str(note))
    if capture and "error" in capture:
        return "quarantined", _quarantine(tenant_id, name, "unreadable_config", str(capture["error"]))
    if capture is None:
        return "quarantined", _quarantine(tenant_id, name, "never_collected")
    captured_at = capture.get("captured_at")
    if isinstance(captured_at, bool) or not isinstance(captured_at, (int, float)):
        return "quarantined", _quarantine(tenant_id, name, "unreadable_config", "the capture has no timestamp")
    metrics = capture.get("metrics")
    problem = _disagreement(metrics)
    if problem:
        return "quarantined", _quarantine(
            tenant_id, name, "metrics_disagree", problem, captured_at=captured_at
        )
    if metrics.get("period_complete") is not True:
        return "quarantined", _quarantine(
            tenant_id,
            name,
            "incomplete_period",
            None,
            covered_days=metrics["covered_days"],
            requested_days=metrics["requested_days"],
            captured_at=captured_at,
        )
    return "ranked", {
        "tenant_id": tenant_id,
        "name": name,
        "hit_rate": metrics.get("hit_rate"),
        "hit_rate_denominator": metrics["hit_rate_denominator"],
        "requests": metrics["requests"],
        "cache_misses": metrics["cache_misses"],
        "covered_days": metrics["covered_days"],
        "requested_days": metrics["requested_days"],
        "captured_at": captured_at,
        "age_seconds": max(0, int(now - captured_at)),
    }


def _order(row):
    # Largest opportunity first; among equals, the worse rate first; then a
    # stable name order so two runs over the same data agree. A None rate is
    # a measured zero-traffic window: nothing to gain, so it sorts last.
    rate = row["hit_rate"]
    return (-row["cache_misses"], 1.0 if rate is None else rate, row["tenant_id"])


def rank(tenants, captures, *, now):
    """Rank what can be ranked; quarantine the rest with a reason.

    `tenants` are dicts or objects carrying `tenant_id`, `name` and `note`
    (`iris.tenants.TenantRow` qualifies). `captures` maps a tenant id to the
    newest capture found *for that tenant* — a dict with `tenant_id`, `metrics`
    and `captured_at` — or `{"error": ...}` when it could not be read, or None.
    `now` is epoch seconds; this module keeps no clock.

    Every tenant appears in exactly one of the two lists, exactly once.
    """
    if not isinstance(captures, dict):
        raise ValueError("captures must be a dict keyed by tenant_id")
    ranked, quarantined, seen = [], [], set()
    for tenant in tenants:
        tenant_id = _field(tenant, "tenant_id")
        if not isinstance(tenant_id, str) or not tenant_id.strip():
            raise ValueError("every tenant needs a non-empty tenant_id")
        if tenant_id in seen:
            raise ValueError(f"tenant {tenant_id!r} was listed twice")
        seen.add(tenant_id)
        kind, row = _classify(
            tenant_id,
            _field(tenant, "name"),
            _field(tenant, "note"),
            captures.get(tenant_id),
            now,
        )
        (ranked if kind == "ranked" else quarantined).append(row)
    ranked.sort(key=_order)
    return {"ranked": ranked, "quarantined": quarantined}
