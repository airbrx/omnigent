"""Iris v1: bounded read-only analysis and configuration proposals."""

__version__ = "0.1.0"
